﻿Imports System.IO
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json
Imports System.Collections.ObjectModel
Imports System.Text
Public Class ReadRFIDSetting
    Dim path As String
    Dim append As Boolean
    Dim nameList3 As New List(Of RFIDmyName)
    Dim RFIDname As New RFIDmyName()
    Public Class RFIDmyName
        Public Property index() As String
            Get
                Return m_index
            End Get
            Set(ByVal value As String)
                m_index = value
            End Set
        End Property
        Private m_index As String
        Public Property Name() As String
            Get
                Return m_name
            End Get
            Set(ByVal value As String)
                m_name = value
            End Set
        End Property
        Private m_name As String
        Public Property PX() As String
            Get
                Return m_PX
            End Get
            Set(ByVal value As String)
                m_PX = value
            End Set
        End Property
        Private m_PX As String
        Public Property PY() As String
            Get
                Return m_PY
            End Get
            Set(ByVal value As String)
                m_PY = value
            End Set
        End Property
        Private m_PY As String
        Public Property side() As String
            Get
                Return m_side
            End Get
            Set(ByVal value As String)
                m_side = value
            End Set
        End Property
        Private m_side As String
    End Class
    Public Sub New(ByVal path As String, ByVal append As Boolean)
        Me.path = path
        Me.append = append
    End Sub

    Public Sub insert(ByVal tindex As String, ByVal tname As String, ByVal tpx As String, ByVal tpy As String, ByVal tside As String)
        RFIDname.index = tindex
        RFIDname.Name = tname
        RFIDname.index = tpx
        RFIDname.Name = tpy
        RFIDname.index = tside

        nameList3.Add(RFIDname)
    End Sub
    Public Sub Save()
        Dim str As New MemoryStream()
        Dim ser As New DataContractJsonSerializer(nameList3.GetType())
        ser.WriteObject(str, nameList3)

        str.Position = 0
        Dim sr As New StreamReader(str)

        Dim sw As StreamWriter = File.AppendText(path & ".json")
        WriteText(sr.ReadToEnd(), sw)
        sw.Close()
    End Sub


    Public Sub WriteText(ByVal message As String, ByVal tw As TextWriter)
        tw.WriteLine(message)
    End Sub
#Region "Read File Json"
    Public Class readmyName
        Public Property index() As String
            Get
                Return m_index
            End Get
            Set(ByVal value As String)
                m_index = value
            End Set
        End Property
        Private m_index As String
        Public Property Name() As String
            Get
                Return m_Name
            End Get
            Set(ByVal value As String)
                m_Name = value
            End Set
        End Property
        Private m_Name As String
        Public Property PX() As String
            Get
                Return m_PX
            End Get
            Set(ByVal value As String)
                m_PX = value
            End Set
        End Property
        Private m_PX As String
        Public Property PY() As String
            Get
                Return m_PY
            End Get
            Set(ByVal value As String)
                m_PY = value
            End Set
        End Property
        Private m_PY As String
        Public Property side() As String
            Get
                Return m_side
            End Get
            Set(ByVal value As String)
                m_side = value
            End Set
        End Property
        Private m_side As String
    End Class
    Public Sub read(ByRef Tindex As String(), ByRef Tname As String(), ByRef TPX As String(), ByRef TPY As String(), ByRef TSide As String())
        Dim strJSON As String = File.ReadAllText(path)
        Dim ms As New MemoryStream(Encoding.UTF8.GetBytes(strJSON))
        Dim list2 As New ObservableCollection(Of readmyName)
        Dim serializer As New DataContractJsonSerializer(GetType(ObservableCollection(Of readmyName)))
        list2 = DirectCast(serializer.ReadObject(ms), ObservableCollection(Of readmyName))
        Static countIndex As Integer = 0
        ReDim Tindex(list2.Count - 1)
        ReDim Tname(list2.Count - 1)
        ReDim TPX(list2.Count - 1)
        ReDim TPY(list2.Count - 1)
        ReDim TSide(list2.Count - 1)
        For Each RFIDname As readmyName In list2
            Tindex(countIndex) = RFIDname.index.ToString()
            Tname(countIndex) = RFIDname.Name.ToString()
            TPX(countIndex) = RFIDname.PX.ToString()
            TPY(countIndex) = RFIDname.PY.ToString()
            TSide(countIndex) = RFIDname.side.ToString()
            countIndex = countIndex + 1
        Next
    End Sub

#End Region

End Class
