﻿Imports System.IO
Imports System.String
Imports System.Net
Imports System.Data.OleDb
Imports Microsoft.VisualBasic.FileIO
Public Class ReadStartRecord
    Public AutostartRecord As New DataTable("AutostartRecord")
    Private Sub ReadStartRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AutostartRecord = GetCsvData("D:\IprojectDB\Record Start" & "\", "AutostartRecord" & (Date.Now.ToShortDateString().Replace("/", "-")) & ".csv")
        'AutostartRecord = GetCsvData("D:\IprojectDB\Record Start" & "\", "AutostartRecord7-25-2017.csv")

        Bind_Grid_CustomerInfo(AutostartRecord)


    End Sub
    Public Sub Bind_Grid_CustomerInfo(ByVal DT As DataTable)
        Try
            DGCustomerInfo.DataSource = DT
            DGCustomerInfo.Refresh()
        Catch ex As Exception
        End Try
    End Sub
    Public Function GetCsvData(ByVal strFolderPath As String, ByVal strFileName As String) As DataTable
        Try
            'CharacterSet=65001 will needed for UTF-8 settings
            Dim strConnString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strFolderPath & ";Extended Properties='text;HDR=Yes;FMT=Delimited;CharacterSet=65001;'"
            Dim conn As New OleDbConnection(strConnString)
            Try
                conn.Open()
                Dim cmd As New OleDbCommand("SELECT * FROM [" & strFileName & "]", conn)
                Dim da As New OleDbDataAdapter()

                da.SelectCommand = cmd
                Dim ds As New DataSet()

                da.Fill(ds)
                da.Dispose()
                Return ds.Tables(0)
            Catch
                Return Nothing
            Finally
                conn.Close()
            End Try
        Catch ex As Exception
        End Try
    End Function
    Private Sub Btnback_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        Me.Dispose()
        '  Create.Show()
    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs)
        AutostartRecord = GetCsvData(Application.StartupPath, "AutostartRecord.csv")
        Bind_Grid_CustomerInfo(AutostartRecord)
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        AutostartRecord = GetCsvData("D:\IprojectDB\Record Start" & "\", "AutostartRecord" & (DateTime.Now.ToShortDateString().Replace("/", "-")) & ".csv")
        Bind_Grid_CustomerInfo(CType(AutostartRecord, DataTable))
    End Sub
End Class