﻿
Imports System.Globalization
Public Class ToBinary
    Shared Function Tobinary(dec As Integer) As String
        Dim bin As Integer

        Dim output As String = ""
        While dec <> 0
            If dec Mod 2 = 0 Then
                bin = 0
            Else
                bin = 1
            End If
            dec = dec \ 2
            output = Convert.ToString(bin) & output
        End While
        If output Is Nothing Then
            Return CType(0, String)
        Else
            Return output
        End If
    End Function
    Shared Function HexStringToBinary(ByVal hexString As String) As String
        Dim num As Integer = Integer.Parse(hexString, NumberStyles.HexNumber)
        Return Convert.ToString(num, 2).ToString.PadLeft(5, "0"c)
    End Function
End Class
