﻿Module isvalue
    Public logReadAGVSetting As ReadAGVSetting = New ReadAGVSetting("D:\\IprojectDB\Setting\AGV_Setting.json", True)
    Public logReadResSeting As ReadResSeting = New ReadResSeting("D:\\IprojectDB\Setting\Response_Setting.json", True)
    Public logReadRFIDSetting As ReadRFIDSetting = New ReadRFIDSetting("D:\\IprojectDB\Setting\RFID_Detail.json", True)
    Public logReadCox_ADD As ReadboxAdd = New ReadboxAdd("D:\\IprojectDB\Setting\Box_Control_Setting.json", True)
    Public AGVindex, AGVaddress, AGVname, AGVline As String()
    Public IDB, BoxADD As String()
    Public ID, Responsename As String()
    Public Cardindex, CardName, PX, PY, Side As String()
    Public BinaryDigit As Char()
    Public Master_binarydigit As Char()
    Public binarydigitCell1()() As Char = New Char(3)() {}
    Public binarydigitCell2 As Char()
    Public binarydigitCell3 As Char()
    ' Public WithEvents test As Interface1

End Module
