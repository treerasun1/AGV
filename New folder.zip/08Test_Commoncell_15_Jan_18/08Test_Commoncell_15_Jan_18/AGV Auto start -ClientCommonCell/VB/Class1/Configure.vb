﻿Imports System.IO

Public Class Configure
    Public version As Integer = 2
    Public serverIP As String = "127.0.0.1"
    Public port As Integer = 2055
    Public serverControlIP As String = "127.0.0.1"
    Public port2 As Integer = 2056
    Public debug As Integer = 0
    Public filter As Integer = 2
    Public allow As String = "all"
    Public packageLog As Integer = 1

    Private file_name As String = "d:\settings_agv_client.conf"

    Public Sub New()
        ReadConfig()
    End Sub

    Private Sub CreateConfig()
        Dim file As StreamWriter = New StreamWriter(file_name)

        file.WriteLine("File Version=" & version)
        file.WriteLine("Server IP=" & serverIP)       
        file.WriteLine("Port=" & port)
        file.WriteLine("Server Control IP=" & serverControlIP)
        file.WriteLine("Port2=" & port2)
        file.WriteLine("Debug=" & debug)
        file.WriteLine("Data filter=" & filter)
        file.WriteLine("Allow=" & allow)
        file.WriteLine("Package log=" & packageLog)

        file.Close()
    End Sub

    Private Sub ReadConfig()
        'Dim File As StreamReader
        'Dim line As String

        Try

            For Each line As String In File.ReadLines(file_name)

                Dim s() As String = line.Split("="c)

                If s(0) = "Server IP" Then
                    serverIP = s(1)
                ElseIf s(0) = "Server Control IP" Then
                    serverControlIP = s(1)
                ElseIf s(0) = "Port" Then
                    port = CType(s(1), Integer)
                ElseIf s(0) = "File Version" Then
                    version = CType(s(1), Integer)
                ElseIf s(0) = "Port2" Then
                    port2 = CType(s(1), Integer)
                ElseIf s(0) = "Debug" Then
                    debug = CType(s(1), Integer)
                ElseIf s(0) = "Data filter" Then
                    filter = CType(s(1), Integer)
                ElseIf s(0) = "Allow" Then
                    allow = s(1)
                ElseIf s(0) = "Package log" Then
                    packageLog = CType(s(1), Integer)
                End If

            Next line

        Catch e As FileNotFoundException
            CreateConfig()
            '//Console.WriteLine("Error: File not found.");

        Finally

        End Try
    End Sub
End Class
