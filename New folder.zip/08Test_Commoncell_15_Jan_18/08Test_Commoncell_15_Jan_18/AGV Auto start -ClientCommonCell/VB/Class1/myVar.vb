﻿Public Class myVar
    Private mValue As String
    Public Shared Event VariableChanged(ByVal mvalue As String)
    Public Property Variable() As String
        Get
            Variable = mValue
        End Get
        Set(ByVal value As String)
            mValue = value
            RaiseEvent VariableChanged(mValue)
        End Set
    End Property


End Class
