﻿Public Class exportToCSV
    Shared Sub export(ByVal dgv As DataGridView)
        Try
            Dim StrExport As String = ""
            For Each C As DataGridViewColumn In dgv.Columns
                StrExport &= """" & C.HeaderText & ""","
            Next
            StrExport = StrExport.Substring(0, StrExport.Length - 1)
            StrExport &= Environment.NewLine

            For Each R As DataGridViewRow In dgv.Rows
                For Each C As DataGridViewCell In R.Cells
                    If Not C.Value Is Nothing Then
                        StrExport &= """" & C.Value.ToString & ""","
                    Else
                        StrExport &= """" & "" & ""","
                    End If
                Next
                StrExport = StrExport.Substring(0, StrExport.Length - 1)
                StrExport &= Environment.NewLine
            Next
            Dim tw As IO.TextWriter = New IO.StreamWriter("D:\IprojectDB\Start Record\" & (DateTime.Now.ToShortDateString().Replace("/", "-")) & ".csv")
            tw.Write(StrExport)
            tw.Close()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub
    Shared Sub CreateCSVfile(ByVal _strCustomerCSVPath As String, ByVal Cell As String, ByVal AGVAdd As String, ByVal AGVname As String, ByVal timewaitkitting As String, ByVal timewaitAGV As String, ByVal TimeSendSignal As String)
        Try
            Dim stLine As String = ""
            Dim stLine2 As String = ""
            Dim objWriter As IO.StreamWriter '= IO.File.AppendText(_strCustomerCSVPath)

            If System.IO.File.Exists(_strCustomerCSVPath) = True Then
                objWriter = IO.File.AppendText(_strCustomerCSVPath)
                objWriter.Write(DateTime.Now.ToShortDateString() & ",") 'stamp date
                objWriter.Write(DateTime.Now.ToShortTimeString() & ",") 'stamp time
                objWriter.Write(Cell & ",")
                objWriter.Write(AGVAdd & ",")
                objWriter.Write(AGVname & ",")
                objWriter.Write(timewaitkitting & ",")
                objWriter.Write(timewaitAGV & ",")

                'If value contains comma in the value then you have to perform this opertions
                Dim append = If(TimeSendSignal.Contains(","), String.Format("""{0}""", TimeSendSignal), TimeSendSignal)
                stLine = String.Format("{0}{1}", stLine, append)
                objWriter.Write(stLine)

                'objWriter.Write(_Phone)
                objWriter.Write(Environment.NewLine)
                objWriter.Close()
            Else
                If IO.File.Exists(_strCustomerCSVPath) = False Then
                    objWriter = IO.File.AppendText(_strCustomerCSVPath)

                    objWriter.Write("Date" & ",") 'stamp date
                    objWriter.Write("Time" & ",") 'stamp time
                    objWriter.Write("Cell_No" & ",")
                    objWriter.Write("AGV_Name" & ",")
                    objWriter.Write("AGV_Address" & ",")
                    objWriter.Write("Time_Wait_Kitting" & ",")
                    objWriter.Write("Time_Wait_AGV" & ",")

                    'If value contains comma in the value then you have to perform this opertions
                    Dim append = If("Time_Send_Start".Contains(","), String.Format("""{0}""", "Time_Send_Start"), "Time_Send_Start")
                    stLine = String.Format("{0}{1}", stLine, append)
                    objWriter.Write(stLine)

                    'objWriter.Write(_Phone)
                    objWriter.Write(Environment.NewLine)

                    ' objWriter = IO.File.AppendText(_strCustomerCSVPath)
                    objWriter.Write(DateTime.Now.ToShortDateString() & ",") 'stamp date
                    objWriter.Write(DateTime.Now.ToShortTimeString() & ",") 'stamp time
                    objWriter.Write(Cell & ",")
                    objWriter.Write(AGVAdd & ",")
                    objWriter.Write(AGVname & ",")
                    objWriter.Write(timewaitkitting & ",")
                    objWriter.Write(timewaitAGV & ",")

                    'If value contains comma in the value then you have to perform this opertions
                    Dim append2 = If(TimeSendSignal.Contains(","), String.Format("""{0}""", TimeSendSignal), TimeSendSignal)
                    stLine2 = String.Format("{0}{1}", stLine2, append2)
                    objWriter.Write(stLine2)

                    'objWriter.Write(_Phone)
                    objWriter.Write(Environment.NewLine)
                    objWriter.Close()
                End If

            End If

            '  ClearTextbox()
        Catch ex As Exception
        End Try

    End Sub

End Class
