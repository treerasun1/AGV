﻿Option Strict On
Option Infer On
Imports System.ComponentModel
Imports System.IO
Imports System.IO.Ports
Imports System.Text
Imports System.Threading
Imports System.Net
Imports System.Net.Sockets
Imports System.Net.NetworkInformation
Imports System.Reflection.TargetInvocationException
Imports System.Reflection

''' <remarks>update 2012-06-27</remarks>
Public Class frmMain2
    Dim ADDGo() As Byte
    Dim strbGo As String = Nothing
    Dim strbGo2 As String = Nothing
    Dim getaddgo As String = Nothing
    Private WithEvents _rs232 As New RS232
    Private charsInline As Integer = 80  ' def n start
    Private isConnected As Boolean
    Private RXcount, TXcount As Integer
    Private comparams() As String = RS232.DefaultParams
    Private buffer() As Byte

    Private WithEvents _rs232Send As New RS232
    Private charsInlineSend As Integer = 80  ' def n start
    Private isConnectedSend As Boolean
    Private RXcountSend, TXcountSend As Integer
    Private comparamsSend() As String = RS232.DefaultParams
    Private bufferSend() As Byte

    Private WithEvents _rs232IO As New RS232
    Private charsInlineIO As Integer = 63  ' def n start
    Private isConnectedIO As Boolean
    Private RXcountIO, TXcountIO As Integer
    Private comparamsIO() As String = RS232.DefaultParams
    Private bufferIO() As Byte

    Public Shared socketAGVControl As New AGVTcpControl()
    ' Public Shared Master_cell, Master_process, Master_circleTime As String
    Dim logE As LogFile = New LogFile("D:/IprojectDB/AGV_Monitor_Log/Err_log", True)
    '  Dim ascT1 As New Thread(New ThreadStart(AddressOf TCPAutoStartControlTimer))
    Public Shared FlagTCP As Integer

    Dim cell, Temp_224, Temp_217 As String
    Dim status217 As Boolean
    Dim statusbox, boxstatus, strtemp, show_ADD, show_result, receiveadd As String
    Dim responsefromAGV, responsefromAGV0401, straddcheck, memmopoint As String
    Dim totaltime_wait_AGV, totaltime_wait_Kitting, totaltime_Send_AGV, totaltime_check_daisha, time_check_daisha2 As String
    Dim timelasecheck, timestart2 As Date
    Dim totaltimecheckdaisha2 As TimeSpan

    Dim strname, stradd, stradd9, TempIOCheck As String

    Dim AGVindex, AGVaddress, AGVline, AGVname As String()
    Dim SSS As Integer
    Dim SSS_bg6 As Integer
    Dim cycletime As Integer = 60
    Dim DelayFinal As Integer = 2
    Dim DelayBefore As Integer = 5
    Dim TimeCheckDaisha As Integer
    Dim TempA, Ssecand As Integer
    Dim flagtempfirthsend As Boolean

    Dim colorFrm As Color
    Dim colorlabel As Color
    Dim colorFore As Color
    Dim flagcancel, flagRCVsignal, flagreset, flagNowStart, flaglooptime, flagcheckio, flagcheckio2 As Boolean
    Dim flagcancel2 As Boolean = False
    Shared Comconfig As ComConfigure = New ComConfigure()
    'queue
    Dim Queue_signal As Integer
    Public obj As Queue(Of String) = New Queue(Of String)()
    Public obj2 As Queue(Of String) = New Queue(Of String)()
    Public obj3 As Queue(Of String) = New Queue(Of String)()
    Private ReadAGVSetting2 As ReadAGVSetting = New ReadAGVSetting("D:\\IprojectDB\Setting\AGV_Setting.json", True)
    Private ReadPCsetting2 As ReadPCsetting = New ReadPCsetting("D:\\IprojectDB\Setting\PC_Setting.json", True)
    'dictionary
    Dim DicQueueRequest As Dictionary(Of String, String) = New Dictionary(Of String, String)
    'TCP Chat
    Private WithEvents myChat As New TCPChat
    Private myAdapterName, myPhysicalAddress, myGateway, myDNS, strHostName As String
    Private addr() As IPAddress
    Dim IPCommon As String
    Dim PortCommon, getcell, getadd, getstatus, getResultdelay, MessageKEY, getcell2, getadd2, getstatus2 As String
    Dim Requestsendline As Byte
    Dim countsen0d401 As Byte = CByte(Comconfig.SendCount)
    Dim DelayFlag As Byte = &H1
    Dim LineCycletime As String
    Dim ResultDelay As String
    Dim P() As Process
    'test change value 
    Private WithEvents IOChange As New myVar

#Region "load and init form"
    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            '   main1()
            CheckProcess()
            ReadAGVSetting2.read()
            ReadPCsetting2.read()
            ' Put keys into List Of String.
            ' Loop over each string.
            Dim str As String
            'For Each str In list
            '    ' Print string and also Item(string), which is the value.
            '    Console.WriteLine("{0}, {1}", str, ReadAGVSetting2.dicname.Item(str))
            'Next
            Me.Text &= String.Format(" Version {0}.{1:00}", My.Application.Info.Version.Major, My.Application.Info.Version.Minor)
            Update_label("none", Me.status0, Color.Red, Color.Black)
            Getcmbport()
            ' InputBox for start program''''''''''''''''''''
            Dim message, title, defautValue As String
            Dim myValue As Object
            message = "Enter a value cell No."
            title = "Set up cell use"
            defautValue = "C3-0"
            myValue = InputBox(message, title, defautValue, 500, 350)
            Comconfig.CellNo = myValue.ToString
            Update_label(myValue.ToString, TstrCell, Color.Thistle, colorFore)
            If myValue Is "" Then myValue = defautValue
            Update_label("", Label41, Color.Transparent, Color.Black)
            Update_label("", Label42, Color.Transparent, Color.Black)
            '*'''''''''''''''''''''''''''''''''''''''''''''
            ' Read setup file ''''''''''''''''''''
            Comconfig.ReadConfig(Comconfig.path & Comconfig.CellNo & ".conf")
            Update_label(Comconfig.CardNo, tstrCard, Color.Thistle, Nothing)
            colorlabel = DirectCast(New ColorConverter().ConvertFromString(Comconfig.colorLabel), Color)
            colorFrm = DirectCast(New ColorConverter().ConvertFromString(Comconfig.colorFrm), Color)
            Me.BackColor = colorFrm
            colorFore = DirectCast(New ColorConverter().ConvertFromString(Comconfig.ColorFront), Color)
            TimeCheckDaisha = CInt(Comconfig.TimeCheckDaisha)
            If _rs232.IsCheckConnect = False Then
                Me.comparams(RS232.cP.cPort) = Comconfig.cPortRcv
                Me.comparams(RS232.cP.cBaud) = Comconfig.cBaudRcv
                Me.comparams(RS232.cP.cData) = Comconfig.cDataRcv
                Me.comparams(RS232.cP.cParity) = Comconfig.cParityRcv
                Me.comparams(RS232.cP.cStop) = Comconfig.cStopRcv
                Me.comparams(RS232.cP.cDelay) = Comconfig.cDelayRcv
                Me.comparams(RS232.cP.cThreshold) = Comconfig.cThresholdRcv
                _rs232.connect(comparams)
            End If
            If _rs232Send.IsCheckConnect = False Then
                Me.comparamsSend(RS232.cP.cPort) = Comconfig.cPortSend
                Me.comparamsSend(RS232.cP.cBaud) = Comconfig.cBaudSend
                Me.comparamsSend(RS232.cP.cData) = Comconfig.cDataSend
                Me.comparamsSend(RS232.cP.cParity) = Comconfig.cParitySend
                Me.comparamsSend(RS232.cP.cStop) = Comconfig.cStopSend
                Me.comparamsSend(RS232.cP.cDelay) = Comconfig.cDelaySend
                Me.comparamsSend(RS232.cP.cThreshold) = Comconfig.cThresholdSend
                _rs232Send.connect(comparamsSend)
            End If
            If _rs232IO.IsCheckConnect = False Then
                Me.comparamsIO(RS232.cP.cPort) = Comconfig.cPortIO
                Me.comparamsIO(RS232.cP.cBaud) = Comconfig.cBaudIO
                Me.comparamsIO(RS232.cP.cData) = Comconfig.cDataIO
                Me.comparamsIO(RS232.cP.cParity) = Comconfig.cParityIO
                Me.comparamsIO(RS232.cP.cStop) = Comconfig.cStopIO
                Me.comparamsIO(RS232.cP.cDelay) = Comconfig.cDelayIO
                Me.comparamsIO(RS232.cP.cThreshold) = Comconfig.cThresholdIO
                _rs232IO.connect(comparamsIO)
            End If
            ' Check data from TCP/IP ''''''''''''''''''''
            ''If BackgroundWorker5.IsBusy <> True Then
            ''    BackgroundWorker5.RunWorkerAsync()
            ''End If
            'InitialAGVStartControlThread()
            ' '''''''''''''''''''''''''''''''''''''''''''
            ' TCP Chat ''''''''''''''''''''''''''''''''''
            strHostName = Dns.GetHostName()
            Dim ipEntry As IPHostEntry = Dns.GetHostEntry(strHostName)
            addr = ipEntry.AddressList
            Dim i As Integer
            For i = 0 To addr.Length - 1
                If addr(i).AddressFamily = AddressFamily.InterNetwork Then
                    Update_ToolstripStaLabel("host " & strHostName & String.Format(" IP: {0}", addr(i).ToString), lblCommontext, Color.Transparent)
                    Exit For
                End If
            Next
            myChat.connect(Comconfig.IPCommon, CInt(Comconfig.PortCommon)) 'connect Host 
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
#End Region

#Region "Common Check"

#End Region
#Region "check process AGV TCP CONTROL running"
    Private Sub CheckProcess()
        P = Process.GetProcessesByName("AGVControlServerConsole")
        If P.Count > 0 Then
            Exit Sub
        Else
            Process.Start("D:\IprojectDB\Setting\AGVControlServerConsole")
        End If
        'D:\IprojectDB\Setting\AGVControlServerConsole
    End Sub
#End Region
#Region "Tcp AGV control"
    Public Sub New()
        ' This call is required by the designer.
        InitializeComponent()
        ' Add any initialization after the InitializeComponent() call.
        'AddHandler BackgroundWorker1.DoWork, AddressOf BackgroundWorker1_DoWork
        'AddHanv  dler BackgroundWorker1.ProgressChanged, AddressOf BackgroundWorker1_ProgressChanged
        'AddHandler BackgroundWorker1.RunWorkerCompleted, AddressOf BackgroundWorker1_RunWorkerCompleted
        BackgroundWorker1.WorkerReportsProgress = True
        BackgroundWorker1.WorkerSupportsCancellation = True
        BackgroundWorker2.WorkerReportsProgress = True
        BackgroundWorker2.WorkerSupportsCancellation = True
        BackgroundWorker4.WorkerReportsProgress = True
        BackgroundWorker4.WorkerSupportsCancellation = False
        BackgroundWorker5.WorkerReportsProgress = True
        BackgroundWorker5.WorkerSupportsCancellation = False
        BackgroundWorker6.WorkerReportsProgress = True
        BackgroundWorker6.WorkerSupportsCancellation = False
        BackgroundWorker7.WorkerReportsProgress = True
        BackgroundWorker7.WorkerSupportsCancellation = False
    End Sub
    Public Sub InitialAGVStartControlThread()
        If Not socketAGVControl.isTryConnecting Then
            socketAGVControl.isTryConnecting = True
            If BackgroundWorker4.IsBusy <> True Then
                BackgroundWorker4.RunWorkerAsync()
            End If
        End If
    End Sub
    Dim log1 As LogFile = New LogFile("D:/IprojectDB/log_start_control", True)
    Private Sub TCPAVGAutoStartControl()
        Try
            Update_ToolstripStaLabel("[AGV auto start: Connecting to " & socketAGVControl.config.serverControlIP & ":" &
                          socketAGVControl.config.port2 & "...]", TstaTCPSignal, Color.LightCyan)
            If socketAGVControl.Connect() Then

                Update_ToolstripStaLabel("[AGV auto start: Connected to " &
                    socketAGVControl.config.serverControlIP & ":" & socketAGVControl.config.port2 & "]", TstaTCPSignal, Color.LightCyan)
                While True
                    Dim s As String = socketAGVControl.sr.ReadLine()
                    If s <> "200" Then
                        Try
                            Dim delimiter() As String = {"|"}
                            Dim resArray() As String = s.Split(delimiter, StringSplitOptions.None)
                            If resArray.Length = 3 Then
                                socketAGVControl.received = socketAGVControl.received + 1
                                AGVTcpControl.Master_cell = resArray(0)
                                AGVTcpControl.Master_process = resArray(1)
                                AGVTcpControl.Master_circleTime = resArray(2)
                                LineCycletime = resArray(2)
                                'test.Variable = AGVTcpControl.Master_cell
                                Update_ToolstripStaLabel(socketAGVControl.received & ": " & s, TstaTCPSignal, Color.LightCyan)
                                ' timesignal = Now
                                If flaglooptime = False Or CheckBox1.Checked = False Then
                                    check_XBADD_inBuffer()
                                End If
                            End If
                        Catch e As NullReferenceException
                            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 1111")
                            Me.Refresh()
                        End Try
                    End If
                End While
            End If
            socketAGVControl.isTryConnecting = False
        Catch e As InvalidOperationException
            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 2222")
            Me.Refresh()
        Catch e As IOException
            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 3333")
            Me.Refresh()
        End Try
    End Sub

    Public Sub TCPAutoStartControlTimer()
        Try
            While True
                Thread.Sleep(5000)
                If Not socketAGVControl.Ping() Then
                    InitialAGVStartControlThread()
                End If
                If FlagTCP = 1 Then
                    FlagTCP = 0
                    socketAGVControl.isTryConnecting = False
                End If
            End While
        Catch e As InvalidOperationException
            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: TCPAutoStartControlTimer")
        End Try

    End Sub

    Public Sub TcpAGVAutoStartReceive()
        While True
            Try
                Dim s As String = socketAGVControl.sr.ReadLine()
                ' ToolStripStatusLabel1.Text = s
                Update_ToolstripStaLabel(s, TstaTCPSignal, Color.LightCyan)
            Catch e As InvalidOperationException
                log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: TcpAGVAutoStartReceive")
            End Try


        End While
    End Sub
    Private Sub BackgroundWorker4_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker4.DoWork

        TCPAutoStartControlTimer()

    End Sub
    Private Sub BackgroundWorker5_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker5.DoWork
        TCPAVGAutoStartControl()
    End Sub

#End Region

#Region "form events Receive Port"

    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click

        Try

            If CType(sender, Button).Text = "*connect*" Then

                Me.comparams(RS232.cP.cPort) = Comconfig.cPortRcv
                Me.comparams(RS232.cP.cBaud) = Comconfig.cBaudRcv
                Me.comparams(RS232.cP.cData) = Comconfig.cDataRcv
                Me.comparams(RS232.cP.cParity) = Comconfig.cParityRcv
                Me.comparams(RS232.cP.cStop) = Comconfig.cStopRcv
                Me.comparams(RS232.cP.cDelay) = Comconfig.cDelayRcv
                Me.comparams(RS232.cP.cThreshold) = Comconfig.cThresholdRcv
                _rs232.connect(comparams)
            Else
                _rs232.disconnect()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
    Private count As Integer


    'Private Sub cboEnterMessage_TextUpdate(ByVal sender As System.Object,
    '                                       ByVal e As System.EventArgs)

    '    '  If Not Me.chkTxEnterHex.Checked Then Exit Sub
    '    Dim cb As ToolStripComboBox = CType(sender, ToolStripComboBox)
    '    Dim s As String = cb.Text
    '    count += 1
    '    If count = 2 Then
    '        cb.Text &= " "
    '        count = 0
    '    End If
    '    cb.SelectionStart = cb.Text.Length

    'End Sub

    Private Sub sendToCom() 'Handles cbxsendToCom.KeyDown

        Dim data() As Byte = Nothing

        'With Me.cboEnterMessage
        '    If .Text.Length > 0 Then

        '        If Not Me.chkTxEnterHex.Checked Then
        '            If Me.chkAddCR.Checked Then .Text &= ControlChars.Cr
        '            If Me.chkAddLF.Checked Then .Text &= ControlChars.Lf
        '   data = Encoding.ASCII.GetBytes(.Text)
        'Else
        '     data = reconvert(.Text)
        'End If

        'send data:
        _rs232.SendData(data)

        'tx counter:
        Me.TXcount += data.Length
        '   Me.lblTxCnt.Text = String.Format("{0:D6}", TXcount)
        '   Update_ToolstripLabel(String.Format("{0:D6}", TXcount), lblTxCnt, Nothing, Nothing)
        'Me.statusTX.Image = My.Resources.ledGray
        '   .Text = String.Empty

        'End If
        '   End With

    End Sub
    ''' <summary>
    ''' view hex in rx box
    ''' </summary>
    Private Sub RxShowHex_CheckedChanged(ByVal sender As System.Object,
                                         ByVal e As System.EventArgs)
        '   Me.charsInline = setRuler(Me.rtbRX, Me.chkRxShowHex.Checked)
    End Sub
    ''' <summary>
    ''' view hex in tx box
    ''' </summary>
    Private Sub chkTxShowHex_CheckedChanged(ByVal sender As System.Object,
                                         ByVal e As System.EventArgs)
        '    Me.charsInline = setRuler(Me.rtbTX, Me.chkTxShowHex.Checked)
    End Sub

    'Private Sub btnSaveFileFromRxBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    SaveFileDialog1.DefaultExt = "*.TXT"
    '    SaveFileDialog1.Filter = "txt Files | *.TXT"
    '    If SaveFileDialog1.ShowDialog() = DialogResult.OK Then

    '        Dim fullpath As String = SaveFileDialog1.FileName()
    '        '  Me.rtbRX.SaveFile(fullpath, RichTextBoxStreamType.PlainText)
    '        MessageBox.Show(IO.Path.GetFileName(fullpath) & " written")
    '    Else
    '        MessageBox.Show("no data choosen")
    '    End If
    'End Sub


    'Private Sub TxbtnFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    OpenFileDialog1.DefaultExt = "*.TXT"
    '    OpenFileDialog1.Filter = "txt Files | *.TXT"
    '    If OpenFileDialog1.ShowDialog() = DialogResult.OK Then

    '        Dim fullpath As String = OpenFileDialog1.FileName()
    '        '  Me.rtbTX.Clear()
    '        '  Me.rtbTX.LoadFile(fullpath, RichTextBoxStreamType.PlainText)
    '    Else
    '        MessageBox.Show("no data choosen")
    '    End If
    'End Sub

    ''' <summary>
    ''' load config
    ''' </summary>
    Private Sub LoadC(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadConfig.Click
        'Dim fname As String = "D:\IprojectDB\Setting\comterm.ini"
        'Try
        '    Dim sr As New StreamReader(fname)
        '    Me.cboComPort.Text = sr.ReadLine()
        '    Me.cboBaudrate.Text = sr.ReadLine()
        '    Me.cboDataBits.Text = sr.ReadLine()
        '    Me.cboParity.Text = sr.ReadLine()
        '    Me.cboStopbits.Text = sr.ReadLine()
        '    Me.cboThreshold.Text = sr.ReadLine
        '    Me.cboDelay.Text = sr.ReadLine
        '    sr.Close()
        '    If sender IsNot Nothing Then MessageBox.Show(fname & " read")
        'Catch ex As IOException
        '    MessageBox.Show(fname & " error: " & ex.Message)
        'End Try

    End Sub

    ''' <summary>
    ''' save comparms
    ''' </summary>
    Private Sub SaveConfig_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveConfig.Click

    End Sub
    ''' <summary>
    '''  exit
    ''' </summary>
    Private Sub ExitTool_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitTool.Click
        Me.Close()
    End Sub

    ''' <summary>
    '''  form resize
    ''' </summary>
    Private Sub frmMain_ResizeEnd(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.ResizeEnd
        'Me.charsInline = setRuler(rtbRX, chkRxShowHex.Checked)
        'Me.charsInline = setRuler(rtbTX, chkTxShowHex.Checked)
    End Sub
#End Region
#Region "Com Port class events Receive Port"
    ''' <summary>
    '''  update boxes
    ''' </summary>
    ''' <param name="buffer">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdate(ByVal buffer() As Byte) Handles _rs232.Datareceived
        Me.RXcount += buffer.Length
        Update_label(String.Format("{0:D3}", RXcount), lblRxCnt, Nothing, Nothing)
        Dim s As String = Encoding.ASCII.GetString(buffer, 0, buffer.Length)
        appendBytes(buffer, Me.charsInline, False)
    End Sub

    ''' <summary>
    ''' 
    ''' 
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendata(ByVal sendStatus As Boolean) Handles _rs232.sendOK
        If sendStatus Then
            '  Me.statusTX.Image = My.Resources.ledGreen
            '  Update_bitmap(statusTX, My.Resources.ledGreen)
        Else
            '   Me.statusTX.Image = My.Resources.ledRed
            '   Update_bitmap(statusTX, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    ''' receive successfull
    ''' </summary>
    Private Sub rdata(ByVal receiveStatus As Boolean) Handles _rs232.recOK
        If receiveStatus Then
            ' Me.statusRX.Image = My.Resources.ledGreen
            '  Update_bitmap(statusRX, My.Resources.ledGreen)
        Else
            ' Me.statusRX.Image = My.Resources.ledRed
            ' Update_bitmap(statusRX, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connection(ByVal status As Boolean) Handles _rs232.connection
        'If status Then
        '    Me.cboParity.Enabled = False
        '    Me.cboStopbits.Enabled = False
        '    Me.cboComPort.Enabled = False
        '    Me.cboBaudrate.Enabled = False
        '    Me.cboDataBits.Enabled = False
        '    Me.cboDelay.Enabled = False
        '    Me.cboThreshold.Enabled = False
        '    Me.sLabel(comparams)
        '    Me.isConnected = True
        '    Update_button("disconnect", btnConnect, Color.Transparent, Color.Black)
        '    Update_label("Connect", status0, Color.ForestGreen, Color.WhiteSmoke)
        '    Update_label(Comconfig.cPortRcv, lblGetport, Color.Transparent, Color.WhiteSmoke)
        'Else
        '    Me.cboParity.Enabled = True
        '    Me.cboStopbits.Enabled = True
        '    Me.cboComPort.Enabled = True
        '    Me.cboBaudrate.Enabled = True
        '    Me.cboDataBits.Enabled = True
        '    Me.cboDelay.Enabled = True
        '    Me.cboThreshold.Enabled = True
        '    Me.isConnected = False
        '    Update_button("*connect*", btnConnect, Color.Transparent, Color.Black)
        '    Update_label("none", status0, Color.Red, Color.WhiteSmoke)
        '    Update_label(Comconfig.cPortRcv, lblGetport, Color.Transparent, Color.WhiteSmoke)
        'End If
        If status Then
            Me.cboParity.Enabled = False
            Me.cboStopbits.Enabled = False
            Me.cboComPort.Enabled = False
            Me.cboBaudrate.Enabled = False
            Me.cboDataBits.Enabled = False
            Me.cboDelay.Enabled = False
            Me.cboThreshold.Enabled = False
            Me.btnConnect.Text = "disconnect"
            '  Me.statusC.Image = My.Resources.ledGreen
            ' Me.statusRX.Image = My.Resources.ledOrange
            '  Me.statusTX.Image = My.Resources.ledOrange
            Me.sLabel(comparams)
            Me.isConnected = True
            Me.status0.BackColor = Color.Green
            Me.status0.ForeColor = Color.Blue
        Else
            Me.cboParity.Enabled = True
            Me.cboStopbits.Enabled = True
            Me.cboComPort.Enabled = True
            Me.cboBaudrate.Enabled = True
            Me.cboDataBits.Enabled = True
            Me.cboDelay.Enabled = True
            Me.cboThreshold.Enabled = True
            Me.btnConnect.Text = "*connect*"
            '  Me.statusC.Image = My.Resources.ledRed
            '  Me.statusRX.Image = My.Resources.ledGray
            '  Me.statusTX.Image = My.Resources.ledGray
            Me.status0.Text = " Terminal connect: none"
            Me.isConnected = False
            Me.status0.BackColor = Color.Red
        End If
    End Sub

    ''' <summary>
    ''' exception message
    ''' </summary>
    Private Sub getmessage(ByVal msg As String) Handles _rs232.errormsg
        'Me.status0.Text = msg
        MsgBox(msg)
    End Sub

#End Region
#Region "utilities  Receive Port"
    ''' <param name="data">data frame</param>
    ''' <param name="currentLenght">possible chars in box</param>
    ''' <param name="showHexAndAscii">determines whether also displaying Hex True</param>
    ''' <remarks></remarks>
    Private Sub appendBytes(ByRef data() As Byte, ByRef currentLenght As Integer, ByVal showHexAndAscii As Boolean)
        Try


            Dim HexString As String = strtemp & StringUltilities.ByteArrayToHexString(data)
            Dim CharString As String = String.Empty
            Dim s() As String = HexString.Split(New String() {" 7E"}, StringSplitOptions.RemoveEmptyEntries)
            ' Static A As Integer
            Dim objmember As Object() = Nothing
            For i = 0 To s.Length - 1
                Update_ToolstripStaLabel(s(i).ToString, TstaTCPSignal, Color.MistyRose)
                Dim data_S() As Byte
                Dim ADD() As Byte
                Dim Respond As Byte
                Dim card() As Byte
                Dim strb As String = Nothing
                Dim strb2 As String = Nothing
                Dim line As String
                Dim name As String
                Dim index As String
                data_S = Reconvert.convert(s(i), " ")
                If data_S.Length = 20 Then
                    strtemp = ""
                    ADDGo = {data_S(7), data_S(8), data_S(9), data_S(10)}
                    strbGo = Hex(data_S(7)).PadLeft(2, "0"c) & " " & Hex(data_S(8)).PadLeft(2, "0"c) & " " & Hex(data_S(9)).PadLeft(2, "0"c) & " " & Hex(data_S(10)).PadLeft(2, "0"c)
                    strb2 = Hex(data_S(7)).PadLeft(2, "0"c) & Hex(data_S(8)).PadLeft(2, "0"c) & Hex(data_S(9)).PadLeft(2, "0"c) & Hex(data_S(10)).PadLeft(2, "0"c)
                    show_ADD = strb2
                    Respond = data_S(16)
                    card = {data_S(18), data_S(17), &H0, &H0}
                    Dim result As Long = BitConverter.ToUInt32(card, 0)
                    show_result = result.ToString

                    receiveadd = strbGo
                    If ReadAGVSetting2.dicLine.ContainsKey(strb2) Then
                        line = ReadAGVSetting2.dicLine.Item(strb2)
                    End If
                    If ReadAGVSetting2.dicname.ContainsKey(strb2) Then
                        name = ReadAGVSetting2.dicname.Item(strb2)
                    End If
                    If ReadAGVSetting2.dicindex.ContainsKey(strb2) Then
                        index = ReadAGVSetting2.dicindex.Item(strb2)
                    End If
                    SendTCP("AGV" & "|" & strbGo & "|" & Comconfig.CellNo & "|" & result.ToString)

                    Select Case result
                        Case CInt(Comconfig.CardNo) 'cell 3-3 
                            '     TCPChat_Sender(Comconfig.CellNo & "|" & strb & "|" & "IN") 'SEND DATA TO COMMON


                            'If strb <> straddcheck Then
                            '    straddcheck = strb

                            '    If obj.Count < 2 Then 'check add in queue >=2
                            '        QueueManage.Enqueue_AGV(obj, ListInQueue1, strb)
                            '        updateAGVQ(obj, ListInQueue1)
                            '        Send_Packet_to_AGV(_rs232Send, ADD, &H4F, &H4B)

                            '    ElseIf obj.Count >= 2 Then
                            '        obj.Clear()
                            '        QueueManage.Enqueue_AGV(obj, ListInQueue1, strb)
                            '        updateAGVQ(obj, ListInQueue1)
                            '    End If
                            '    show_detailAGV()
                            'ElseIf strb = straddcheck Then
                            '    Send_Packet_to_AGV(_rs232Send, ADD, &H4F, &H4B)
                            'End If
                        Case 19279 'KO

                            If BackgroundWorker6.IsBusy = True Then
                                responsefromAGV = "OK" '"KO"=19279
                            End If
                        Case 20299 'OK

                            If BackgroundWorker6.IsBusy = True Then
                                responsefromAGV = "OK"
                            End If
                        Case 20993 'R1
                            If BackgroundWorker6.IsBusy = True Then
                                responsefromAGV = "Route1"
                            End If
                        Case 20994 'R2
                            If BackgroundWorker6.IsBusy = True Then
                                responsefromAGV = "Route2"
                            End If
                        Case 20995 'R3
                            If BackgroundWorker6.IsBusy = True Then
                                responsefromAGV = "Route3"
                            End If
                        Case 16690 'A2
                            If BackgroundWorker6.IsBusy = True Then
                                responsefromAGV = "ADD"
                            End If
                        Case CInt(Comconfig.CardNoCancel) 'card 217
                            flagcancel2 = True
                            If CheckBox4.Checked = True Then
                                If obj3.Count > 0 Then
                                    '  flagcancel2 = True
                                    MessageKEY = obj3.Peek()
                                End If
                                If MessageKEY <> "" Then
                                    Dim delimiter() As String = {"|"}
                                    Dim resArray() As String = MessageKEY.Split(delimiter, StringSplitOptions.None)
                                    If resArray.Length = 3 Then
                                        getcell2 = resArray(0)
                                        getadd2 = resArray(1)
                                        getstatus2 = resArray(2)
                                        If getadd2 = strbGo And DicQueueRequest.ContainsKey(MessageKEY) Then
                                            SendTCP("CLRKEY" & "|" & getadd2 & "|" & Comconfig.CellNo & "|" & result.ToString)
                                            DicQueueRequest.Remove(MessageKEY)
                                            MessageKEY = ""
                                        End If
                                        If BackgroundWorker6.IsBusy = False Then
                                            SendTCP("CLRAGV" & "|" & getadd2 & "|" & Comconfig.CellNo & "|" & result.ToString)
                                        End If
                                    End If
                                End If
                                Send_Packet_to_AGV(_rs232Send, ADDGo, &H4F, &H4B)
                            ElseIf BackgroundWorker6.IsBusy = False Then
                                Send_Packet_to_AGV(_rs232Send, ADDGo, &H4F, &H4B)
                            End If
                        '    '  straddcheck_217 = strb
                        '    Dim Pac(20) As Byte
                        '    Dim addT(7) As Byte
                        '    Dim Card2(3) As Byte
                        '    Dim res As Byte
                        '    Dim strdata2 As String = Nothing

                        '    If flagNowStart = True Then
                        '        If BackgroundWorker1.IsBusy = True Then
                        '            status217 = True
                        '            'flagcancel = True
                        '            '* flagNowStart = CBool(0)
                        '        End If
                        '    End If

                        '    If obj.Count <> 0 Then
                        '        QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
                        '        If strdata2 = receiveadd Then
                        '            If Temp_217 <> receiveadd Then
                        '                Temp_217 = receiveadd
                        '                Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                        '                QueueManage.deDequeue_AGV(obj, ListInQueue1)
                        '                updateAGVQ(obj, ListInQueue1)
                        '                show_detailAGV()
                        '                SSS = 0
                        '                '  strdata2 = ""
                        '            End If
                        '        End If
                        '    End If
                        '    If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                        '        SSS = 0
                        '        BackgroundWorker2.RunWorkerAsync()
                        '    End If
                        Case CInt(Comconfig.CardNoCancelSignal) 'card 224
                            'Dim Pac(20) As Byte
                            'Dim addT(7) As Byte
                            'Dim Card2(3) As Byte
                            'Dim res As Byte
                            'Dim strdata2 As String = Nothing
                            ''     TCPChat_Sender(Comconfig.CellNo & "|" & strb & "|" & "OUT") 'SEND DATA TO COMMON
                            ''  If AGVTcpControl.Master_cell <> "" And Temp_224 <> receiveadd Then
                            'If Temp_224 <> receiveadd Then
                            '    Temp_224 = receiveadd

                            '    Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                            '    If BackgroundWorker1.IsBusy = True Then
                            '        SSS = 0
                            '        flagcancel = True
                            '        ' flagNowStart = CBool(0)
                            '    End If
                            '    Send_Packet_to_AGV(_rs232Send, ADD, &H4F, &H4B)
                            'ElseIf Temp_224 = receiveadd Then
                            '    Send_Packet_to_AGV(_rs232Send, ADD, &H4F, &H4B)
                            'End If


                            'If Temp_224 = receiveadd And BackgroundWorker1.IsBusy = False And obj.Count <> 0 Then
                            '    QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
                            '    If strdata2 = receiveadd Then
                            '        QueueManage.deDequeue_AGV(obj, ListInQueue1)
                            '        updateAGVQ(obj, ListInQueue1)
                            '        show_detailAGV()
                            '    End If
                            'End If
                    End Select
                    result = 0
                    card = {&H0, &H0, &H0, &H0}
                Else
                    strtemp = s(s.Length - 1)
                End If
            Next
            HexString = String.Empty
        Catch ex As Exception
            Update_Log(ex.ToString())
        Catch ex2 As TargetInvocationException
            Update_Log(ex2.ToString())
        End Try
    End Sub

    ''' <summary>
    ''' show status of connection
    ''' </summary>
    Private Sub sLabel(ByVal comparams() As String)
        Update_label(Comconfig.cPortRcv, lblGetport, Color.Transparent, Color.Black)

    End Sub

#End Region
    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        Dim fname As String = "D:\IprojectDB\Setting\comterm.ini"
        If Tcboselect.Text = "Receive Comport" Then
            fname = "D:\IprojectDB\Setting\comtermPortReceive.ini"
        ElseIf Tcboselect.Text = "Send Comport" Then
            fname = "D:\IprojectDB\Setting\comtermPortSend.ini"
        End If
        Dim sw As New StreamWriter(fname)
        sw.WriteLine(Me.cboComPort.Text)
        sw.WriteLine(Me.cboBaudrate.Text)
        sw.WriteLine(Me.cboDataBits.Text)
        sw.WriteLine(Me.cboParity.Text)
        sw.WriteLine(Me.cboStopbits.Text)
        sw.WriteLine(Me.cboThreshold.Text)
        sw.WriteLine(Me.cboDelay.Text)
        sw.Close()
        MessageBox.Show(fname & " written")
    End Sub
    'End Serialport receive code
#Region "form events Send Port"


    Private countsend As Integer


    Private Sub sendToComSend() 'Handles cbxsendToCom.KeyDown

        Dim dataSend() As Byte = Nothing
        Me.TXcountSend += dataSend.Length
        '   Me.lblTxCntsend.Text = String.Format("{0:D6}", TXcountSend)
        Update_label(String.Format("{0:D6}", TXcountSend), lblTxCntSend, Nothing, Nothing)

    End Sub



#End Region
#Region "Com Port class events send Port"
    ''' <summary>
    '''  update boxes
    ''' </summary>
    ''' <param name="bufferSend">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdateSend(ByVal bufferSend() As Byte) Handles _rs232Send.Datareceived

        Me.RXcountSend += bufferSend.Length
        '  Me.lblRxCntSend.Text = String.Format("count: {0:D3}", RXcountSend)
        Update_label(String.Format("count: {0:D3}", RXcountSend), lblTxCntSend, Nothing, Nothing)
        Dim sSend As String = Encoding.ASCII.GetString(bufferSend, 0, bufferSend.Length)
        ' Me.rtbRX.ScrollToCaret()
        'TODO
        '  Me.rtbRX.AppendText(s) ' & vbCr)
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendataSend(ByVal sendStatusSend As Boolean) Handles _rs232Send.sendOK
        If sendStatusSend Then
            ' Me.statusTXsend.Image = My.Resources.ledGreen
            '  Update_bitmap(statusTXsend, My.Resources.ledGreen)
        Else
            ' Me.statusTXsend.Image = My.Resources.ledRed
            '  Update_bitmap(statusTXsend, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    ''' receive successfull
    ''' </summary>
    Private Sub rdataSend(ByVal receiveStatusSend As Boolean) Handles _rs232Send.recOK
        If receiveStatusSend Then
            '  Update_bitmap(statusRXSend, My.Resources.ledGreen)
            ' Me.statusRXSend.Image = My.Resources.ledGreen
        Else
            '   Me.statusRXSend.Image = My.Resources.ledRed
            '  Update_bitmap(statusRXSend, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connectionSend(ByVal statusSend As Boolean) Handles _rs232Send.connection
        Try
            If statusSend Then
                Me.cboParity.Enabled = False
                Me.cboStopbits.Enabled = False
                Me.cboComPort.Enabled = False
                Me.cboBaudrate.Enabled = False
                Me.cboDataBits.Enabled = False
                Me.cboDelay.Enabled = False
                Me.cboThreshold.Enabled = False
                Me.sLabelSend(comparamsSend)
                Me.isConnectedSend = True
                Update_button("disconnect", btnConnectSend, Color.Transparent, Color.Black)
                Update_label("Connect", txtstatus1, Color.ForestGreen, Color.WhiteSmoke)
                Update_label(Comconfig.cPortRcv, lblGetportSend, Color.Transparent, Color.Black)
            Else
                Me.cboParity.Enabled = True
                Me.cboStopbits.Enabled = True
                Me.cboComPort.Enabled = True
                Me.cboBaudrate.Enabled = True
                Me.cboDataBits.Enabled = True
                Me.cboDelay.Enabled = True
                Me.cboThreshold.Enabled = True
                Me.isConnectedSend = False
                Update_button("*connect*", btnConnectSend, Color.Transparent, Color.Black)
                Update_label("none", txtstatus1, Color.Red, Color.WhiteSmoke)
                Update_label(Comconfig.cPortRcv, lblGetportSend, Color.Transparent, Color.Black)


            End If
        Catch e As InvalidOperationException
            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: connectionSend")
        End Try
    End Sub

    ''' <summary>
    ''' exception message
    ''' </summary>
    Private Sub getmessageSend(ByVal msgSend As String) Handles _rs232Send.errormsg
        'Me.status0.Text = msg
        MsgBox(msgSend)
    End Sub

#End Region
#Region "utilities  Send Port"

    Private Sub appendBytesSend(ByVal rb As RichTextBox, ByRef dataSend() As Byte, ByRef currentLenghtSend As Integer, ByVal showHexAndAsciiSend As Boolean)
        Dim HexStringSend As String = String.Empty
        Dim CharStringSend As String = String.Empty
        Dim count As Integer = 0

        For i As Integer = 0 To dataSend.Length - 1
            HexStringSend &= String.Format(" {0:X2}", dataSend(i))
            If dataSend(i) > 31 Then
                CharStringSend &= String.Format("  {0}", Chr(dataSend(i)))
            Else
                CharStringSend &= "  ."
            End If
            count += 3

            'start a new line
            'If count >= currentLenghtSend Then
            '    rbSend.ScrollToCaret()
            '    rbSend.AppendText(HexStringSend & vbCr)
            '    If showHexAndAsciiSend Then
            '        rb.ScrollToCaret()
            '        rb.AppendText(CharStringSend & vbCr)
            '    End If
            '    HexString = String.Empty
            '    CharString = String.Empty
            '    count = 0
            'End If

        Next

        'rb.ScrollToCaret()
        'rb.AppendText(HexString & vbCr)
        'If showHexAndAscii Then
        '    rb.ScrollToCaret()
        '    rb.AppendText(CharString & vbCr)
        'End If
    End Sub


    ''' <summary>
    ''' show status of connection
    ''' </summary>
    Private Sub sLabelSend(ByVal comparamsSend() As String)
        Update_label(Comconfig.cPortSend, lblGetportSend, Color.Transparent, Color.Black)
        '   For Each s As String In comparamsSend
        'Me.lblGetport.Text &= "-" & s
        '  Next
        '  Me.lblGetport.BackColor = Color.Green
    End Sub

    Private Sub SplitContainer1_Panel1_Paint(sender As Object, e As PaintEventArgs) Handles SplitContainer1.Panel1.Paint
    End Sub

#End Region
    Private Sub btnConnectSend_Click(sender As Object, e As EventArgs) Handles btnConnectSend.Click
        Try

            If CType(sender, Button).Text = "*connect*" Then
                Me.comparams(RS232.cP.cPort) = Comconfig.cPortSend
                Me.comparams(RS232.cP.cBaud) = Comconfig.cBaudSend
                Me.comparams(RS232.cP.cData) = Comconfig.cDataSend
                Me.comparams(RS232.cP.cParity) = Comconfig.cParitySend
                Me.comparams(RS232.cP.cStop) = Comconfig.cStopSend
                Me.comparams(RS232.cP.cDelay) = Comconfig.cDelaySend
                Me.comparams(RS232.cP.cThreshold) = Comconfig.cThresholdSend
                _rs232Send.connect(comparamsSend)
            Else
                _rs232Send.disconnect()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
    'End Serialport send code
#Region "form events IO Port"
    ''' <summary>
    ''' clear rx box
    ''' </summary>
    Private Sub btnClearReceiveBoxr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Me.RXcountIO = 0
        'Me.lblRxCntIO.Text = String.Format("{0:D6}", Me.RXcountIO)
        'Me.statusRXSend.Image = If(Me.isConnectedSend, My.Resources.ledOrange, My.Resources.ledGray)
    End Sub

    ''' <summary>
    ''' clear tx box
    ''' </summary>
    Private Sub btnClearTxBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Me.rtbTX.Clear()
        'Me.rtbTX.Text = "1"
        'Me.charsInline = setRuler(rtbTX, chkTxShowHex.Checked)
        Me.TXcountIO = 0
        '  Me.lblTxCntIO.Text = String.Format("count: {0:D3}", Me.TXcountIO)
        '    Update_ToolstripLabel(String.Format("count: {0:D3}", Me.TXcountIO), lblTxCntIO, Nothing, Nothing)
        '  Me.statusTXsend.Image = If(Me.isConnectedSend, My.Resources.ledOrange, My.Resources.ledGray)
    End Sub

    Private countIO As Integer

    'Private Sub cboEnterMessage_TextUpdate(ByVal sender As System.Object,
    '                                       ByVal e As System.EventArgs)


    '    '  If Not Me.chkTxEnterHex.Checked Then Exit Sub
    '    Dim cb As ToolStripComboBox = CType(sender, ToolStripComboBox)
    '    Dim s As String = cb.Text
    '    countsend += 1
    '    If countsend = 2 Then
    '        cb.Text &= " "
    '        countsend = 0
    '    End If
    '    cb.SelectionStart = cb.Text.Length

    'End Sub

    Private Sub sendToComIO() 'Handles cbxsendToCom.KeyDown

        Dim dataIO() As Byte = Nothing

        'With Me.cboEnterMessage
        '    If .Text.Length > 0 Then

        '        If Not Me.chkTxEnterHex.Checked Then
        '            If Me.chkAddCR.Checked Then .Text &= ControlChars.Cr
        '            If Me.chkAddLF.Checked Then .Text &= ControlChars.Lf
        '   data = Encoding.ASCII.GetBytes(.Text)
        'Else
        '     data = reconvert(.Text)
        'End If

        'send data:
        _rs232IO.SendData(dataIO)

        'tx counter:
        Me.TXcountIO += dataIO.Length
        '   Me.lblTxCntIO.Text = String.Format("{0:D6}", TXcountIO)
        '    Update_label(String.Format("{0:D6}", TXcountIO), lblTxCntIO, Nothing, Nothing)
        'Me.statusTXsend.Image = My.Resources.ledGray
        '   .Text = String.Empty

        'End If
        '   End With

    End Sub

    '''' <summary>
    '''' save rx box to file
    '''' </summary>
    'Private Sub btnSaveFileFromRxBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    SaveFileDialog1.DefaultExt = "*.TXT"
    '    SaveFileDialog1.Filter = "txt Files | *.TXT"
    '    If SaveFileDialog1.ShowDialog() = DialogResult.OK Then

    '        Dim fullpath As String = SaveFileDialog1.FileName()
    '        '  Me.rtbRX.SaveFile(fullpath, RichTextBoxStreamType.PlainText)
    '        MessageBox.Show(IO.Path.GetFileName(fullpath) & " written")
    '    Else
    '        MessageBox.Show("no data choosen")
    '    End If
    'End Sub

    '''' <summary>
    '''' load file into tx box
    '''' </summary>
    'Private Sub TxbtnFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    OpenFileDialog1.DefaultExt = "*.TXT"
    '    OpenFileDialog1.Filter = "txt Files | *.TXT"
    '    If OpenFileDialog1.ShowDialog() = DialogResult.OK Then

    '        Dim fullpath As String = OpenFileDialog1.FileName()
    '        '  Me.rtbTX.Clear()
    '        '  Me.rtbTX.LoadFile(fullpath, RichTextBoxStreamType.PlainText)
    '    Else
    '        MessageBox.Show("no data choosen")
    '    End If
    'End Sub

    '''' <summary>
    '''' load config
    '''' </summary>
    'Private Sub LoadC(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadConfig.Click
    '    Dim fname As String = "D:\IprojectDB\Setting\comterm.ini"
    '    Try
    '        Dim sr As New StreamReader(fname)
    '        Me.cboComPort.Text = sr.ReadLine()
    '        Me.cboBaudrate.Text = sr.ReadLine()
    '        Me.cboDataBits.Text = sr.ReadLine()
    '        Me.cboParity.Text = sr.ReadLine()
    '        Me.cboStopbits.Text = sr.ReadLine()
    '        Me.cboThreshold.Text = sr.ReadLine
    '        Me.cboDelay.Text = sr.ReadLine
    '        sr.Close()
    '        If sender IsNot Nothing Then MessageBox.Show(fname & " read")
    '    Catch ex As IOException
    '        MessageBox.Show(fname & " error: " & ex.Message)
    '    End Try

    'End Sub


#End Region
#Region "Com Port class events IO Port"
    ''' <summary>
    '''  update boxes
    ''' </summary>
    ''' <param name="bufferIO">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdateIO(ByVal bufferIO() As Byte) Handles _rs232IO.Datareceived
        Me.RXcountIO += bufferIO.Length
        Update_label(String.Format("{0:D3}", RXcountIO), lblRxCntIO, Nothing, Nothing)
        Dim sIO As String = Encoding.ASCII.GetString(bufferIO, 0, bufferIO.Length)
        appendBytesIO(bufferIO, Me.charsInlineIO, False)
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendataIO(ByVal sendStatusIO As Boolean) Handles _rs232IO.sendOK
        If sendStatusIO Then
            ' Me.statusTXsend.Image = My.Resources.ledGreen
            '  Update_bitmap(statusTXsend, My.Resources.ledGreen)
        Else
            ' Me.statusTXsend.Image = My.Resources.ledRed
            '  Update_bitmap(statusTXsend, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    ''' receive successfull
    ''' </summary>
    Private Sub rdataIO(ByVal receiveStatusIO As Boolean) Handles _rs232IO.recOK
        If receiveStatusIO Then
            '  Update_bitmap(statusRXSend, My.Resources.ledGreen)
            ' Me.statusRXSend.Image = My.Resources.ledGreen
        Else
            '   Me.statusRXSend.Image = My.Resources.ledRed
            '  Update_bitmap(statusRXSend, My.Resources.ledRed)
        End If
    End Sub
    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connectionIO(ByVal statusIO As Boolean) Handles _rs232IO.connection
        If statusIO Then
            Me.cboParity.Enabled = False
            Me.cboStopbits.Enabled = False
            Me.cboComPort.Enabled = False
            Me.cboBaudrate.Enabled = False
            Me.cboDataBits.Enabled = False
            Me.cboDelay.Enabled = False
            Me.cboThreshold.Enabled = False
            Me.sLabelIO(comparamsIO)
            Me.isConnectedIO = True
            Update_button("disconnect", btnConnectIO, Color.Transparent, Color.Black)
            Update_label("Connect", txtstatus2, Color.ForestGreen, Color.WhiteSmoke)
        Else
            Me.cboParity.Enabled = True
            Me.cboStopbits.Enabled = True
            Me.cboComPort.Enabled = True
            Me.cboBaudrate.Enabled = True
            Me.cboDataBits.Enabled = True
            Me.cboDelay.Enabled = True
            Me.cboThreshold.Enabled = True
            Me.isConnectedIO = False
            Update_button("*connect*", btnConnectIO, Color.Transparent, Color.Black)
            Update_label("none", txtstatus2, Color.Red, Color.WhiteSmoke)
            Update_label(Comconfig.cPortRcv, lblGetportIO, Color.Transparent, Color.WhiteSmoke)
        End If
    End Sub

    ''' <summary>
    ''' exception message
    ''' </summary>
    Private Sub getmessageIO(ByVal msgIO As String) Handles _rs232IO.errormsg
        'Me.status0.Text = msg
        MsgBox(msgIO)
    End Sub

#End Region

#Region "utilities IO Port"
    Dim strtempIO As String = ""
    Private Sub appendBytesIO(ByRef dataIO() As Byte, ByRef currentLenghtIO As Integer, ByVal showHexAndAsciiIO As Boolean)
        Dim HexStringIO As String = String.Empty
        Dim CharStringIO As String = String.Empty
        Dim countIO As Integer = 0
        Try
            Dim HexString As String = strtempIO & StringUltilities.ByteArrayToHexString(dataIO)
            Dim CharString As String = String.Empty
            Dim s() As String = HexString.Split(New String() {" 7E"}, StringSplitOptions.RemoveEmptyEntries)
            For i = 0 To s.Length - 1
                Dim data_S2() As Byte
                Dim ADD() As Byte
                Dim strb As String = Nothing
                Dim tempalldata As String = ""
                If s(i).Length = 63 Then
                    data_S2 = Reconvert.convert(s(i), " ")
                    strtempIO = ""
                    If tempalldata <> s(i) Then
                        tempalldata = s(i)
                        ADD = {data_S2(7), data_S2(8), data_S2(9), data_S2(10)}
                        Dim binaryDigits = ToBinary.HexStringToBinary(Hex(data_S2(19))).ToCharArray
                        '  Label1.Text = binaryDigits
                        System.Threading.Thread.Sleep(100)
                        IOChange.Variable = binaryDigits(2) & binaryDigits(3)
                        System.Threading.Thread.Sleep(100)
                        Update_label(binaryDigits, LblStaIO, Color.LightGray, colorFore)
                        If flagcheckio = True Then
                            statusbox = binaryDigits(2) & binaryDigits(3)
                        End If
                        If binaryDigits(1) = "1" Then
                            Update_label("Rst", lblIO03, Color.LightGray, colorFore)
                        Else
                            Update_label("Rst", lblIO03, Color.OrangeRed, colorFore)
                            If Queue_signal > 0 Then
                                Queue_signal = Queue_signal - 1
                                Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                            End If
                            If BackgroundWorker1.IsBusy = True Then
                                flagcancel = True
                                If Queue_signal > 0 Then
                                    Queue_signal = Queue_signal - 1
                                    Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                                End If
                                flagreset = True
                                SSS = 0
                            End If

                            If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                                BackgroundWorker2.RunWorkerAsync()
                            End If


                        End If
                        If binaryDigits(2) = "1" Then
                            Update_label("S2", lblIO02, Color.LightGray, colorFore)
                        Else
                            Update_label("S2", lblIO02, colorlabel, colorFore)
                        End If
                        If binaryDigits(3) = "1" Then
                            Update_label("S1", lblIO01, Color.LightGray, colorFore)
                        Else
                            Update_label("S1", lblIO01, colorlabel, colorFore)
                        End If
                        If binaryDigits(2) & binaryDigits(3) = Comconfig.IOValue Then
                            '    boxstatus = "OK"
                            Update_label("Kitting Daisha", Label7, colorlabel, colorFore)
                            Exit Sub
                        Else
                            Update_label("Kitting Daisha", Label7, Color.LightGray, colorFore)
                        End If

                    End If
                Else
                    strtempIO = s(s.Length - 1)
                End If

            Next
            HexString = String.Empty
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        straddcheck = ""
    End Sub

    ''' <summary>
    ''' show status of connection
    ''' </summary>
    Private Sub sLabelIO(ByVal comparamsIO() As String)
        Update_label(Comconfig.cPortIO, lblGetportIO, Color.Transparent, Color.Black)
        'Me.txtstatus2.Text = "IO:"
        'For Each s As String In comparamsIO
        '    Me.txtstatus2.Text &= "-" & s
        'Next
        'Me.txtstatus2.BackColor = Color.ForestGreen
    End Sub

    Private Sub btnConnectIO_Click(sender As Object, e As EventArgs) Handles btnConnectIO.Click
        Try

            If CType(sender, Button).Text = "*connect*" Then
                Me.comparams(RS232.cP.cPort) = Comconfig.cPortIO
                Me.comparams(RS232.cP.cBaud) = Comconfig.cBaudIO
                Me.comparams(RS232.cP.cData) = Comconfig.cDataIO
                Me.comparams(RS232.cP.cParity) = Comconfig.cParityIO
                Me.comparams(RS232.cP.cStop) = Comconfig.cStopIO
                Me.comparams(RS232.cP.cDelay) = Comconfig.cDelayIO
                Me.comparams(RS232.cP.cThreshold) = Comconfig.cThresholdIO
                _rs232IO.connect(comparamsIO)
            Else
                _rs232IO.disconnect()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
#End Region
#Region "Create function"
    Private Sub VariableChanged(ByVal NewValue As String) Handles IOChange.VariableChanged
        Try
            ' MessageBox.Show(NewValue)
            If TempIOCheck <> NewValue Then
                TempIOCheck = NewValue
                If NewValue = Comconfig.IOValue Then
                    SendTCP("IO" & "|" & Comconfig.CellNo & "|" & "KITTING OK" & "|" & DateAndTime.TimeString)
                Else
                    SendTCP("IO" & "|" & Comconfig.CellNo & "|" & "WAIT KITTING" & "|" & DateAndTime.TimeString)
                End If
            End If
        Catch ex2 As TargetInvocationException
            Update_Log(ex2.ToString())
        End Try
    End Sub
    Private Sub Getcmbport()
        Dim Portnames As String() = SerialPort.GetPortNames
        If Portnames.Length > 0 Then
            Me.cboComPort.Text = Portnames(0)
        Else
            Me.status0.Text = "no ports detected"
            Exit Sub
        End If
        Me.cboComPort.Items.Clear()
        Me.cboComPort.Items.AddRange(Portnames)
    End Sub

    Public Sub check_XBADD_inBuffer()
        Dim Pac(20) As Byte
        Dim addT(3) As Byte
        Dim Card(3) As Byte
        ' Dim res As Byte
        Dim strdata As String = Nothing
        '  Dim Stradd As String
        Try
            If AGVTcpControl.Master_cell = Comconfig.CellNo Then
                '  Queue_signal = Queue_signal + 1
                SSS = 0
                Temp_224 = ""
                Temp_217 = ""
                flagRCVsignal = True
                Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                    '   FlagRCVsignal = False
                    BackgroundWorker2.RunWorkerAsync()
                End If
                Delay(0.2)
                Update_button("Start" & AGVTcpControl.Master_cell, Button2, colorlabel, colorFore)
                SendTCP("CELL" & "|" & Comconfig.CellNo.ToString & "|" & DateAndTime.TimeString & "|" & LineCycletime)

                If BackgroundWorker1.IsBusy <> True And CheckBox3.Checked = False Then
                    If flagtempfirthsend = False Then
                        AGVTcpControl.Master_cell = "firstsend"
                    End If
                    Delay(0.5)
                    BackgroundWorker1.RunWorkerAsync()

                    'ElseIf BackgroundWorker6.IsBusy <> True And CheckBox3.Checked = True Then
                    If flagtempfirthsend = False Then
                        AGVTcpControl.Master_cell = "firstsend"
                    End If
                    '    Update_button("Start" & AGVTcpControl.Master_cell, Button2, colorlabel, colorFore)
                    '    Delay(0.5)
                    '    BackgroundWorker6.RunWorkerAsync()

                End If
            End If
            'Else
            '    Exit Sub
            'End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            QueueManage.deDequeue_AGV(obj, ListInQueue1)
            updateAGVQ(obj, ListInQueue1)
            show_detailAGV()
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    Public Sub Send_Packet_to_AGV(ByRef SerialS As RS232, ByRef addT As Byte(), ByVal CMD1 As Byte, ByVal CMD2 As Byte)
        Try
            '  Dim result As Long = BitConverter.ToUInt32(ArrCard, 0)
            '7E 00 10 10 00 00 13 A2 00 40 EA 52 B7 FF FE 00 00 01 00 09
            Dim FSUM As Integer
            '   FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + addT(4) + addT(5) + addT(6) + addT(7) + &HFF + &HFE + CMD1 + CMD2)
            FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + &H0 + &H13 + &HA2 + &H0 + &HFF + &HFE + CMD1 + CMD2)
            Dim byteArray As Byte() = BitConverter.GetBytes(FSUM)
            Dim h As Integer
            h = byteArray(0)

            Dim Packet() As Byte = {&H7E, &H0, &H10, &H10, &H0, &H0, &H13, &HA2, &H0, addT(0), addT(1), addT(2), addT(3), &HFF, &HFE, &H0, &H0, CMD1, CMD2, CByte(h)}
            If SerialS.IsCheckConnect() = True Then
                SerialS.SendData(Packet)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Public Sub Send_cmd_tOagv(ByRef SerialS As RS232, ByRef addT As Byte(), ByVal CMD1 As Byte, ByVal CMD2 As Byte, ByVal Value As Byte)
        Try
            '7E 00 10 10 00 00 13 A2 00 40 EA 52 B7 FF FE 00 00 03 52 01 09 
            Dim FSUM As Integer
            FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + &H0 + &H13 + &HA2 + &H0 + &HFF + &HFE + CMD1 + CMD2 + Value)
            Dim byteArray As Byte() = BitConverter.GetBytes(FSUM)
            Dim h As Integer
            h = byteArray(0)
            Dim Packet() As Byte = {&H7E, &H0, &H11, &H10, &H0, &H0, &H13, &HA2, &H0, addT(0), addT(1), addT(2), addT(3), &HFF, &HFE, &H0, &H0, CMD1, CMD2, Value, CByte(h)}
            If SerialS.IsCheckConnect() = True Then
                SerialS.SendData(Packet)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Public Sub Send_cmd_04(ByRef SerialS As RS232, ByRef addT As Byte(), ByVal CMD1 As Byte, ByRef addTSet As Byte()) 'Send_cmd_04(_rs232send,add(),02,addtset())
        '7E 00 14 10 00 00 13 A2 00 40 D5 1A 36 FF FE 00 00 04 02 FF FF FF FF D6
        Try
            Dim FSUM As Integer
            FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + &H0 + &H13 + &HA2 + &H0 + &HFF + &HFE + &H4 + CMD1 + addTSet(0) + addTSet(1) + addTSet(2) + addTSet(3))
            Dim byteArray As Byte() = BitConverter.GetBytes(FSUM)
            Dim h As Integer
            h = byteArray(0)

            Dim Packet() As Byte = {&H7E, &H0, &H14, &H10, &H0, &H0, &H13, &HA2, &H0, addT(0), addT(1), addT(2), addT(3), &HFF, &HFE, &H0, &H0, &H4, CMD1, addTSet(0), addTSet(1), addTSet(2), addTSet(3), CByte(h)}
            If SerialS.IsCheckConnect() = True Then
                SerialS.SendData(Packet)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Public Sub Send_cmd_04_01(ByRef SerialS As RS232, ByRef addT As Byte(), ByRef addTSet As Byte(), ByRef addUpTimm As Byte(), ByVal countsend As Byte, ByVal Delay_Flag As Byte) 'Send_cmd_04(_rs232send,add(),02,addtset())
        Try
            '7E 00 14 10 00 00 13 A2 00 40 D5 1A 36 FF FE 00 00 04 02 FF FF FF FF D6

            Dim FSUM As Integer
            FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + &H0 + &H13 + &HA2 + &H0 + &HFF + &HFE + &H4 + &H1 + addTSet(0) + addTSet(1) + addTSet(2) + addTSet(3) + addUpTimm(0) + addUpTimm(1) + addUpTimm(2) + addUpTimm(3) + countsend + Delay_Flag)
            Dim byteArray As Byte() = BitConverter.GetBytes(FSUM)
            Dim h As Integer
            h = byteArray(0)

            Dim Packet() As Byte = {&H7E, &H0, &H1A, &H10, &H0, &H0, &H13, &HA2, &H0, addT(0), addT(1), addT(2), addT(3), &HFF, &HFE, &H0, &H0, &H4, &H1, addTSet(0), addTSet(1), addTSet(2), addTSet(3), addUpTimm(0), addUpTimm(1), addUpTimm(2), addUpTimm(3), countsend, Delay_Flag, CByte(h)}
            If SerialS.IsCheckConnect() = True Then
                SerialS.SendData(Packet)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Sub show_detailAGV()
        Try
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim Card2(3) As Byte
            Dim res As Byte
            Dim strdata2 As String = Nothing
            Dim strb3 As String = Nothing
            Dim AGVName As String = Nothing
            If obj.Count <> 0 Then
                QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
                strb3 = Hex(addT(0)).PadLeft(2, "0"c) & Hex(addT(1)).PadLeft(2, "0"c) & Hex(addT(2)).PadLeft(2, "0"c) & Hex(addT(3)).PadLeft(2, "0"c)
                If ReadAGVSetting2.dicname.ContainsKey(strb3) Then
                    AGVName = ReadAGVSetting2.dicname.Item(strb3)
                End If
                Update_label("NO:" & AGVName, Label19, colorlabel, colorFore)
            Else
                Update_label("Wait AGV", Label19, Color.Gray, colorFore)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Sub btnSettime_Click(sender As Object, e As EventArgs) Handles btnSettime.Click
        Try
            Dim myValue As Object
            myValue = InputBox("Enter a value ", "Set up Time (sec)", "60", 500, 350)
            ' Update_label(myValue.ToString(), lblcycletime, Color.SeaShell, Nothing)
            cycletime = CInt(myValue.ToString())
            '  Update_label("Set Time:", Label10, Nothing, Nothing)
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub

    Private Sub ToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem4.Click
        cycletime = CInt(AGVTcpControl.Master_circleTime)
        '   Update_label(AGVTcpControl.Master_circleTime, lblcycletime, Color.SeaShell, Nothing)
        ' Update_label("Cycle Time:", Label10, Nothing, Nothing)
    End Sub

#End Region
#Region "Safety up date UI form"

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Try
            If Queue_signal > 0 Then
                Queue_signal = Queue_signal - 1
                ' Update_label(Queue_signal.ToString, Label8, Color.Gray, Color.Blue)
                Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
            End If
            If BackgroundWorker1.IsBusy = True Then
                flagcancel = True
                '   flagreset = True
                '   BackgroundWorker1.CancelAsync()
                SSS = 0
            End If
            If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                BackgroundWorker2.RunWorkerAsync()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub

    Private Sub ResetTimeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetTimeToolStripMenuItem.Click
        SSS = 0
    End Sub

    Private Sub ResetValueToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetValueToolStripMenuItem.Click
        Try
            Comconfig.ReadConfig(Comconfig.path & Comconfig.CellNo & ".conf")
            colorlabel = DirectCast(New ColorConverter().ConvertFromString(Comconfig.colorLabel), Color)
            colorFrm = DirectCast(New ColorConverter().ConvertFromString(Comconfig.colorFrm), Color)
            Me.BackColor = colorFrm
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub



    Private Sub DelayBeforeResendToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DelayBeforeResendToolStripMenuItem.Click
        Try
            Dim myValue3 As Object
            myValue3 = InputBox("Enter a value ", "Set Delay Before resend (sec)", "5", 500, 350)
            DelayBefore = CInt(myValue3.ToString())
            Update_ToolstripLabel(DelayBefore.ToString, T2, Nothing, colorFore)
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub

    Private Sub ResetDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetDataToolStripMenuItem.Click
        ReadAGVSetting2.read()
    End Sub

    Private Sub SetAGVNOToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SetAGVNOToolStripMenuItem.Click
        ' InputBox for Send CMD Set Up AGV''''''''''''''''''''
        Dim message, title, defautValue As String
        Dim myValue4 As Object
        message = "Enter a value"
        title = "Set up for AGV No."
        defautValue = "0"
        myValue4 = InputBox(message, title, defautValue, 350, 350)
        Update_label(myValue4.ToString, lblA7, Color.Orange, Color.Blue)
        Dim list As New List(Of String)(ReadAGVSetting2.dicname.Keys)
        Dim AAA As String
        If lblA7.Text <> "0" And lblA7.Text <> "" Then
            AAA = list.Item(CInt(lblA7.Text) - 1)
            Update_label(AAA, lblA8, Color.Orange, Color.Blue)
        End If
        Update_label(myValue4.ToString, TstrCell, Color.Thistle, colorFore)
        If myValue4 Is "" Then myValue4 = defautValue
        Update_label(myValue4.ToString, lblA7, Color.Orange, Color.Blue)
        '*'''''''''''''''''''''''''''''''''''''''''''''
        ' InputBox for Send CMD Set Route''''''''''''''''''''
        Dim message2, title2, defautValue2 As String
        Dim myValue5 As Object
        message2 = "Enter Route"
        title2 = "Set up route"
        defautValue2 = "0"
        myValue5 = InputBox(message2, title2, defautValue2, 350, 350)
        Update_label(myValue5.ToString, lblA9, Color.Orange, Color.Blue)

    End Sub

    Private Sub SetUp0401ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SetUp0401ToolStripMenuItem.Click
        Try
            Dim addfixuptime As Byte()
            Dim addFixsend As Byte()
            Dim addT As Byte()

            Dim message, title, defautValue As String
            Dim myValue5 As Object
            message = "Enter Delay Flag Setting" & vbCrLf & "[Value0=Safety Delay,Value1=Cancel Delay]"
            title = "Set up Delay Flag "
            defautValue = "0"
            myValue5 = InputBox(message, title, defautValue, 350, 350)
            Dim list As New List(Of String)(ReadAGVSetting2.dicname.Keys)
            Dim AGVADD2 As String
            'addT=Send to AddT
            Dim addT1 As String = list(CInt(lblA7.Text) - 1)
            Dim addT2 As String
            addT2 = Reconvert.FormatAdd("## ## ## ##", addT1)
            addT = Reconvert.convert(addT2, " ")
            'Set Add Up Time 
            Dim fixaddUpTime1 As String = ReadPCsetting2.dicaddRCV.Item("99")
            Dim fixaddUpTime2 As String
            fixaddUpTime2 = Reconvert.FormatAdd("## ## ## ##", fixaddUpTime1)
            addfixuptime = Reconvert.convert(fixaddUpTime2, " ")
            'Set Add Receive
            Dim fixaddsend As String = ReadPCsetting2.dicaddRCV.Item(lblA9.Text)
            Dim fixaddsend2 As String
            fixaddsend2 = Reconvert.FormatAdd("## ## ## ##", fixaddsend)
            addFixsend = Reconvert.convert(fixaddsend2, " ")
            Send_cmd_04_01(_rs232Send, addT, addfixuptime, addFixsend, countsen0d401, CByte(myValue5))
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub


    Private Sub SetUp0402ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SetUp0402ToolStripMenuItem.Click
        Try
            Dim addT As Byte()
            Dim addFixsend As Byte()
            Dim message, title, defautValue As String
            Dim myValue5 As Object
            message = "Enter Line No"
            title = "Set up to lint No.[Value= 1,2,3]"
            defautValue = "0"
            myValue5 = InputBox(message, title, defautValue, 350, 350)
            Update_label(myValue5.ToString, lblA9, Color.Orange, Color.Blue)

            Dim list As New List(Of String)(ReadAGVSetting2.dicname.Keys)
            Dim AGVADD2 As String
            'addT=Send to AddT
            Dim addT1 As String = list(CInt(lblA7.Text) - 1)
            Dim addT2 As String
            addT2 = Reconvert.FormatAdd("## ## ## ##", addT1)
            addT = Reconvert.convert(addT2, " ")
            'Set Add Receive
            Dim fixaddsend As String = ReadPCsetting2.dicaddRCV.Item(myValue5.ToString)
            Dim fixaddsend2 As String
            fixaddsend2 = Reconvert.FormatAdd("## ## ## ##", fixaddsend)
            addFixsend = Reconvert.convert(fixaddsend2, " ")

            Send_cmd_04(_rs232Send, addT, &H2, addFixsend)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub SetUp03ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SetUp03ToolStripMenuItem.Click
        Try
            Dim addT As Byte()
            'Dim message, title, defautValue As String
            'Dim myValue5 As Object
            'message = "Enter Route"
            'title = "Set up route"
            'defautValue = "0"
            'myValue5 = InputBox(message, title, defautValue, 350, 350)
            'Update_label(myValue5.ToString, Label10, Color.Orange, Color.Blue)

            Dim list As New List(Of String)(ReadAGVSetting2.dicname.Keys)
            'addT=Send to AddT
            Dim addT1 As String = list(CInt(lblA7.Text) - 1)
            Dim addT2 As String
            addT2 = Reconvert.FormatAdd("## ## ## ##", addT1)
            addT = Reconvert.convert(addT2, " ")

            Send_cmd_tOagv(_rs232Send, addT, &H3, &H52, CByte(lblA9.Text))
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub StartCMD01ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StartCMD01ToolStripMenuItem.Click
        Try
            Dim addT As Byte()
            Dim list As New List(Of String)(ReadAGVSetting2.dicname.Keys)
            'addT=Send to AddT
            Dim addT1 As String = list(CInt(lblA7.Text) - 1)
            Dim addT2 As String
            addT2 = Reconvert.FormatAdd("## ## ## ##", addT1)
            addT = Reconvert.convert(addT2, " ")
            Send_cmd_tOagv(_rs232Send, addT, &H1, &H0, &H0)

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub StopCMD02ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StopCMD02ToolStripMenuItem.Click
        Try
            Dim addT As Byte()
            Dim list As New List(Of String)(ReadAGVSetting2.dicname.Keys)
            'addT=Send to AddT
            Dim addT1 As String = list(CInt(lblA7.Text) - 1)
            Dim addT2 As String
            addT2 = Reconvert.FormatAdd("## ## ## ##", addT1)
            addT = Reconvert.convert(addT2, " ")
            Send_cmd_tOagv(_rs232Send, addT, &H2, &H0, &H0)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Timer1_Tick_1(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try
            If btnConnect.Text = "disconnect" Then
                If _rs232.IsCheckConnect = False Then
                    Update_button("*connect*", btnConnect, Color.Transparent, Color.Black)
                    Update_label("Disconnect", status0, Color.Red, Color.WhiteSmoke)
                End If
            End If
            If btnConnectSend.Text = "disconnect" Then
                If _rs232Send.IsCheckConnect = False Then
                    ' MessageBox.Show("please re-connect")
                    Update_button("*connect*", btnConnectSend, Color.Transparent, Color.Black)
                    Update_label("Disconnect", txtstatus1, Color.Red, Color.WhiteSmoke)
                End If
            End If
            If btnConnectIO.Text = "disconnect" Then
                If _rs232IO.IsCheckConnect = False Then
                    ' MessageBox.Show("please re-connect")
                    Update_button("*connect*", btnConnectIO, Color.Transparent, Color.Black)
                    Update_label("Disconnect", txtstatus2, Color.Red, Color.WhiteSmoke)
                End If
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Sub Timer2_Tick_1(sender As Object, e As EventArgs) Handles Timer2.Tick
        Try
            Update_label(BackgroundWorker1.IsBusy & "/" & BackgroundWorker2.IsBusy, lblA1, Nothing, Nothing)
            Update_label(BackgroundWorker3.IsBusy & "/" & BackgroundWorker4.IsBusy & "/" & BackgroundWorker6.IsBusy, lblA2, Nothing, Nothing)
            Update_label(flagNowStart & "/" & flagreset & "/" & flaglooptime & "/" & flagcancel2, lblA3, Nothing, Nothing)
            Update_label(show_result & "/" & TempA.ToString(), lblA4, Nothing, Nothing)
            Update_label(straddcheck & "/" & obj.Count.ToString, lblA5, Nothing, Nothing)
            Update_label(receiveadd, lblA6, Nothing, Nothing)
            Update_label(MessageKEY & "/" & strbGo, lblA9, Color.Transparent, Color.Black)
            'Update_label(Temp_224, lblA7, Nothing, Nothing)
            'Update_label(Temp_217, lblA8, Nothing, Nothing)
            '     Update_label(statusbox & "/" & time_check_daisha2 & "/" & AGVTcpControl.Master_cell, Label10, Nothing, Nothing)
            ' Update_label(flagNowStart & "/" & flagreset, lblA3, Nothing)
            '  Update_label(BackgroundWorker1.IsBusy.ToString, lbltimeC1, Color.Transparent, Color.DeepSkyBlue)
            UpdateStatus("", ListInQueue1)
            Dim list1 As New List(Of String)(DicQueueRequest.Keys)
            Dim str As String
            '   list1.Clear()
            For Each str In list1
                UpdateStatus(str, ListInQueue1)
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub

    Private Sub TableLayoutPanel6_Paint(sender As Object, e As PaintEventArgs) Handles TableLayoutPanel6.Paint

    End Sub

    Private Sub ToolStripMenuItem5_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem5.Click
        ReadStartRecord.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If Queue_signal > 0 Then
            Queue_signal = Queue_signal - 1
            ' Update_label(Queue_signal.ToString, Label8, Color.Gray, Color.Blue)
            Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
        End If
        DicQueueRequest.Clear()
    End Sub

    Private Sub DelayFinalSendToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DelayFinalSendToolStripMenuItem.Click
        Try
            Dim myValue As Object
            myValue = InputBox("Enter a value ", "Set Delay Tim Final (sec)", "15", 500, 350)
            DelayFinal = CInt(myValue.ToString())
            Update_ToolstripLabel(DelayFinal.ToString, T1, Nothing, colorFore)
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateLabel(ByVal strstatusLabel As String, ByVal lbl As Label, ByVal lblcolor As Color, ByVal lblForecolor As Color)
    Private Sub Update_label(ByVal strstatusLabel As String, ByVal lbl As Label, ByVal lblcolor As Color, ByVal lblForecolor As Color)
        Try
            If InvokeRequired Then
                If strstatusLabel = "" Then
                    Invoke(Sub() lbl.Text = strstatusLabel)
                    Invoke(Sub() lbl.BackColor = lblcolor)
                    Invoke(Sub() lbl.ForeColor = lblForecolor)
                Else
                    Invoke(Sub() lbl.Text = strstatusLabel)
                    Invoke(Sub() lbl.BackColor = lblcolor)
                    Invoke(Sub() lbl.ForeColor = lblForecolor)
                End If
            Else
                If strstatusLabel = "" Then
                    lbl.Text = strstatusLabel
                    lbl.BackColor = lblcolor
                    lbl.ForeColor = lblForecolor
                Else
                    lbl.Text = strstatusLabel
                    lbl.BackColor = lblcolor
                    lbl.ForeColor = lblForecolor
                End If
            End If

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdatetextbox(ByVal strstatustextbox As String, ByVal txt As TextBox, ByVal lblcolor As Color)
    Private Sub Update_textbox(ByVal strstatustextbox As String, ByVal txt As TextBox, ByVal lblcolor As Color)
        Try
            If InvokeRequired Then
                If strstatustextbox = "" Then
                    Invoke(Sub() txt.BackColor = lblcolor)
                Else
                    Invoke(Sub() txt.Text = strstatustextbox)
                    Invoke(Sub() txt.BackColor = lblcolor)
                End If
            Else
                If strstatustextbox = "" Then
                    txt.BackColor = lblcolor
                Else
                    txt.Text = strstatustextbox
                    txt.BackColor = lblcolor
                End If
            End If

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateToolstripStaLabel(ByVal strstatusToolstripStaLabel As String, ByVal ToolstripStaLabel As ToolStripStatusLabel, ByVal lblcolor As Color)
    Private Sub Update_ToolstripStaLabel(ByVal strstatusToolstripStaLabel As String, ByVal ToolstripStaLabel As ToolStripStatusLabel, ByVal lblcolor As Color)
        Try
            If InvokeRequired Then
                If strstatusToolstripStaLabel = "" Then
                    Invoke(Sub() ToolstripStaLabel.BackColor = lblcolor)
                Else
                    Invoke(Sub() ToolstripStaLabel.Text = strstatusToolstripStaLabel)
                    Invoke(Sub() ToolstripStaLabel.BackColor = lblcolor)
                End If
            Else
                If strstatusToolstripStaLabel = "" Then
                    ToolstripStaLabel.BackColor = lblcolor
                Else
                    ToolstripStaLabel.Text = strstatusToolstripStaLabel
                    ToolstripStaLabel.BackColor = lblcolor
                End If
            End If

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateToolStripLabel(ByVal strstatusToolstripLabel As String, ByVal ToolstripLabel As ToolStripLabel, ByVal lblcolor As Color, ByVal Forecolor As Color)
    Private Sub Update_ToolstripLabel(ByVal strstatusToolstripLabel As String, ByVal ToolstripLabel As ToolStripLabel, ByVal lblcolor As Color, ByVal Forecolor As Color)
        Try
            If InvokeRequired Then
                If strstatusToolstripLabel = "" Then
                    Invoke(Sub() ToolstripLabel.BackColor = lblcolor)
                    Invoke(Sub() ToolstripLabel.ForeColor = Forecolor)
                Else
                    Invoke(Sub() ToolstripLabel.Text = strstatusToolstripLabel)
                    Invoke(Sub() ToolstripLabel.BackColor = lblcolor)
                    Invoke(Sub() ToolstripLabel.ForeColor = Forecolor)
                End If
            Else
                If strstatusToolstripLabel = "" Then
                    ToolstripLabel.BackColor = lblcolor
                    ToolstripLabel.ForeColor = Forecolor
                Else
                    ToolstripLabel.Text = strstatusToolstripLabel
                    ToolstripLabel.BackColor = lblcolor
                    ToolstripLabel.ForeColor = Forecolor
                End If
            End If

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try

    End Sub

    Private Delegate Sub DelegateUpdatebitmap(ByVal strstatusbitmap As ToolStripLabel, ByVal bitmapp As Bitmap)
    Private Sub Update_bitmap(ByVal strstatusbitmap As ToolStripLabel, ByVal bitmapp As Bitmap)
        '  Me.statusRXSend.Image = My.Resources.ledGreen
        Try
            If InvokeRequired Then
                Invoke(Sub() strstatusbitmap.Image = bitmapp)
            Else
                strstatusbitmap.Image = bitmapp
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateButton(ByVal strstatusbutton As String, ByVal btn1 As Button, ByVal colorB As Color, ByVal colorFore1 As Color)
    Private Sub Update_button(ByVal strstatusbutton As String, ByVal btn1 As Button, ByVal colorB As Color, ByVal colorFore1 As Color)
        '  Me.statusRXSend.Image = My.Resources.ledGreen
        Try
            If InvokeRequired Then

                Invoke(Sub() btn1.Text = strstatusbutton)
                Invoke(Sub() btn1.BackColor = colorB)
                Invoke(Sub() btn1.ForeColor = colorFore1)
            Else
                btn1.Text = strstatusbutton
                btn1.BackColor = colorB
                btn1.ForeColor = colorFore1
            End If

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateCSV(ByVal StrCSV1 As String, ByVal StrCSV2 As String, ByVal StrCSV3 As String, ByVal StrCSV4 As String, ByVal StrCSV5 As String, ByVal StrCSV6 As String)
    Private Sub Update_CSV(ByVal StrCSV1 As String, ByVal StrCSV2 As String, ByVal StrCSV3 As String, ByVal StrCSV4 As String, ByVal StrCSV5 As String, ByVal StrCSV6 As String)
        '  Me.statusRXSend.Image = My.Resources.ledGreen
        If StrCSV1 = "" Then
            StrCSV1 = "Empty"
        End If
        If StrCSV2 = "" Then
            StrCSV2 = "Empty"
        End If
        If StrCSV3 = "" Then
            StrCSV3 = "Empty"
        End If
        If StrCSV4 = "" Then
            StrCSV4 = "0"
        End If
        If StrCSV5 = "" Then
            StrCSV5 = "0"
        End If
        If StrCSV6 = "" Then
            StrCSV6 = "0"
        End If
        Try
            If InvokeRequired Then
                Invoke(Sub() exportToCSV.CreateCSVfile("D:\IprojectDB\Record Start" & "\" & "AutostartRecord" & (DateTime.Now.ToShortDateString().Replace("/", "-")) & ".csv", StrCSV1, StrCSV2, StrCSV3, StrCSV4, StrCSV5, StrCSV6))
            Else
                exportToCSV.CreateCSVfile("D:\IprojectDB\Record Start" & "\" & "AutostartRecord" & (DateTime.Now.ToShortDateString().Replace("/", "-")) & ".csv", StrCSV1, StrCSV2, StrCSV3, StrCSV4, StrCSV5, StrCSV6)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Delegate Sub DelegateUpdateLog(ByVal StrCSV1 As String)
    Private Sub Update_Log(ByVal StrCSV1 As String)
        '  Me.statusRXSend.Image = My.Resources.ledGreen
        Try
            If InvokeRequired Then
                Invoke(Sub() logE.Log(vbCr & StrCSV1 & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"))
            Else
                logE.Log(vbCr & StrCSV1 & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString())
        End Try
    End Sub
    Private Sub updateAGVQ(ByRef objT As Queue(Of String), ByRef ListInQueue As ListBox)
        Try
            '    Try)
            If objT.Count <> 0 Then
                Dim arr As Object()
                arr = objT.ToArray()
                UpdateStatus("", ListInQueue)
                For i As Integer = 0 To objT.Count - 1
                    UpdateStatus(arr(i).ToString, ListInQueue)
                Next
            ElseIf objT.Count = 0 Then
                ' ListInQueue.Items.Clear()
                UpdateStatus("", ListInQueue)
                '  MessageBox.Show("queue is empty")
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateStatus22(ByVal statusText1 As String, ByVal txt As ListBox)
    Private Sub UpdateStatus(ByVal statusText1 As String, ByVal txt As ListBox)
        Try

            If InvokeRequired Then
                If statusText1 = "" Then
                    Invoke(Sub() txt.Items.Clear())
                Else
                    Invoke(Sub() txt.Items.Add(statusText1))
                End If
            Else
                If statusText1 = "" Then
                    txt.Items.Clear()
                Else
                    txt.Items.Add(statusText1)
                End If
            End If
        Catch ex As Exception
            '  logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateTCP(ByVal TxtCell As String)
    Private Sub SendTCP(ByVal TxtCell As String)
        Try
            If InvokeRequired Then
                Invoke(Sub() TCPChat_Sender(TxtCell))
            Else
                TCPChat_Sender(TxtCell)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Sub BackgroundWorker1_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        Try
resend:     Dim worker As BackgroundWorker = CType(sender, BackgroundWorker)
            Dim worker2 As BackgroundWorker = CType(sender, BackgroundWorker)
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim Card(3) As Byte
            Dim res As Byte
            Dim time1, time2, time3, time4, time5, time6 As Date
            Dim timelast, timenewstart As Date
            Dim totaltimecheckdaisha As TimeSpan
            Dim timewaitAGV As TimeSpan
            Dim timewaitkittingdaisha As TimeSpan
            Dim timewaitsendStrat As TimeSpan

            Static A As Integer = 0
            responsefromAGV = ""
            statusbox = ""
            flagcheckio = False
#Region "Check AGV in Queue"
            If CheckBox3.Checked = False Then


                If obj.Count = 0 Then
                    time1 = Now
                    While True 'check 
                        If obj.Count <> 0 Then
                            Exit While
                        End If
                        If flagcancel = True Then
                            QueueManage.deDequeue_AGV(obj, ListInQueue1)
                            updateAGVQ(obj, ListInQueue1)
                            time2 = Now
                            timewaitAGV = time2.Subtract(time1)
                            totaltime_wait_AGV = FormatNumber(timewaitAGV.Seconds)
                            GoTo Cancel
                        End If
                    End While
                    time2 = Now
                    timewaitAGV = time2.Subtract(time1)
                    totaltime_wait_AGV = FormatNumber(timewaitAGV.Seconds)

                End If
            End If
#End Region

#Region "CheckIO1"

            time3 = Now
            flagcheckio = True
            While True
                Update_label("", Label41, Color.Transparent, Color.Black)
                If AGVTcpControl.Master_cell <> "Queue" And AGVTcpControl.Master_cell <> "" And statusbox = Comconfig.IOValue Then
                    boxstatus = "OK"
                    Update_label("Kitting Daisha", Label7, colorlabel, colorFore)
                    '    flagcheckio = False
                    Exit While
                ElseIf AGVTcpControl.Master_cell = "Queue" Then 'And statusbox = Comconfig.IOValue Then
                    timenewstart = Now
                    totaltimecheckdaisha = timenewstart.Subtract(timelast)
                    totaltime_check_daisha = FormatNumber(totaltimecheckdaisha.Seconds)
                    Update_label(CInt(totaltime_check_daisha).ToString & "  Sec.", Label42, Color.Transparent, Color.Black)
                    If CInt(totaltime_check_daisha) > TimeCheckDaisha Then
                        boxstatus = "OK"
                        totaltime_check_daisha = ""
                        Update_label("", Label41, Color.Transparent, Color.Black)
                        Update_label("", Label42, Color.Transparent, Color.Black)
                        Exit While
                    Else
                        Update_label("Delay#", Label41, Color.Red, Color.White)
                        Delay(1)
                        Update_label(CInt(totaltime_check_daisha).ToString & "  Sec.", Label42, Color.Transparent, Color.Black)
                    End If

                End If

                If flagcancel = True Then
                    QueueManage.deDequeue_AGV(obj, ListInQueue1)
                    updateAGVQ(obj, ListInQueue1)
                    If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                        BackgroundWorker2.RunWorkerAsync()
                    End If
                    totaltime_check_daisha = ""
                    Update_label("", Label41, Color.Transparent, Color.Black)
                    Update_label("", Label42, Color.Transparent, Color.Black)
                    '1 flagcancel = False
                    GoTo Cancel
                End If

            End While
            time4 = Now
            timewaitkittingdaisha = time4.Subtract(time3)
            totaltime_wait_Kitting = FormatNumber(timewaitkittingdaisha.Seconds)
#End Region
#Region "main send"
            If AGVTcpControl.Master_cell <> "" And boxstatus = "OK" And obj.Count <> 0 Then
                flagNowStart = True
                AGVTcpControl.Master_cell = ""
                time5 = Now
                statusbox = ""
                boxstatus = ""
                Dim strdata As String = Nothing
                QueueManage.Peek_1(obj, Pac, strdata, addT, res, Card)
                strname = strdata
                Dim result As Long = BitConverter.ToUInt32(Card, 0)
                '7E 00 10 10 01 00 13 A2 00 40 DB 4A B1 FF FE 00 00 01 00 25
                memmopoint = strdata
                Delay(CInt(Comconfig.DelayTimeBeforeSend))
                If CheckBox1.Checked = True Then
                    flaglooptime = True
                End If
                While True '///////////
                    If responsefromAGV = "OK" And memmopoint = receiveadd Then
                        responsefromAGV = ""
                        boxstatus = ""
                        statusbox = ""
                        AGVTcpControl.Master_cell = ""
                        Update_button("Wait Signal", Button2, Color.Gray, colorFore)
                        QueueManage.deDequeue_AGV(obj, ListInQueue1)
                        updateAGVQ(obj, ListInQueue1)
                        If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                            BackgroundWorker2.RunWorkerAsync()
                        End If
                        Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                        A = 0
                        flagcancel = True
                        Exit While
                    End If

                    If A = CInt(Comconfig.SendCount) Then 'defult =8
                        'If Queue_signal > 0 Then
                        '    Queue_signal = Queue_signal - 1
                        '    Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                        'End If
                        A = 0
                        QueueManage.deDequeue_AGV(obj, ListInQueue1)
                        updateAGVQ(obj, ListInQueue1)
                        AGVTcpControl.Master_cell = ""
                        Update_button("Wait Signal", Button2, Color.Gray, colorFore)
                        flagcancel = True
                        Exit While
                    End If

                    If flagcancel = True And memmopoint = receiveadd Then
                        QueueManage.deDequeue_AGV(obj, ListInQueue1)
                        updateAGVQ(obj, ListInQueue1)
                        If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                            BackgroundWorker2.RunWorkerAsync()
                        End If
                        '1 flagcancel = False
                        GoTo Cancel
                    End If
                    If flaglooptime = True Or CheckBox1.Checked = False Then
                        SSS = 0
                        Send_Packet_to_AGV(_rs232Send, addT, &H1, &H0)
                        A = A + 1
                        TempA = A
                    End If
                    If (worker.CancellationPending = True) Then
                        e.Cancel = True
                        Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                        System.Threading.Thread.Sleep(CInt(Comconfig.LoopTimeSend))
                    Else
                        System.Threading.Thread.Sleep(CInt(Comconfig.LoopTimeSend))
                        worker.ReportProgress(A)
                    End If
                End While '////////////////////////////
            End If 'end main send
#End Region
Cancel:     TempA = A
            time6 = Now
            timewaitsendStrat = time6.Subtract(time5)
            totaltime_Send_AGV = FormatNumber(timewaitsendStrat.Seconds)
            Update_CSV(TstrCell.Text.ToString(), stradd9, strname, totaltime_wait_Kitting.ToString(), totaltime_wait_AGV.ToString(), totaltime_Send_AGV.ToString())

            If Queue_signal > 0 Then
                Queue_signal = Queue_signal - 1
                Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                show_detailAGV()
                timelast = Now
                '     Delay(DelayBefore)
                If Queue_signal >= 1 Then
                    AGVTcpControl.Master_cell = "Queue"
                    Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                End If
                Update_label("Kitting Daisha", Label7, Color.Gray, colorFore)
                totaltime_wait_AGV = ""
                totaltime_wait_Kitting = ""
                totaltime_Send_AGV = ""
                memmopoint = ""
                responsefromAGV = ""
                boxstatus = ""
                statusbox = ""
                strname = ""
                flagcancel = False
                flagNowStart = False
                GoTo resend
            Else
                AGVTcpControl.Master_cell = ""
                Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                responsefromAGV = ""
                boxstatus = ""
                statusbox = ""
                Temp_217 = "" '********30/3/17
                Temp_224 = "" '*1
                status217 = False
                flagNowStart = False
                show_detailAGV()
            End If
            '    SSS = 0
        Catch ex As Exception
            ' logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - -- - -")
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Sub BackgroundWorker1_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        Try
            timelasecheck = Now
            Update_button("Wait Signal", Button2, Color.Gray, colorFore)
            Update_label("Kitting Daisha", Label7, Color.Gray, colorFore)
            totaltime_wait_AGV = ""
            totaltime_wait_Kitting = ""
            totaltime_Send_AGV = ""
            show_detailAGV()
            If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                BackgroundWorker2.RunWorkerAsync()
            End If
            memmopoint = ""
            System.Threading.Thread.Sleep(2000)
            responsefromAGV = ""
            AGVTcpControl.Master_cell = ""
            boxstatus = ""
            statusbox = ""
            flagcancel = False
            flagNowStart = False
            If Queue_signal > 0 Then
                Queue_signal = Queue_signal - 1
                '  Update_label(Queue_signal.ToString, Label8, Color.Gray, Color.Blue)
                Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
            End If
        Catch ex As Exception
            '   logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Sub BackgroundWorker1_ProgressChanged(sender As Object, e As ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged

    End Sub
    Private Sub BackgroundWorker2_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker2.DoWork

        Dim worker As BackgroundWorker = CType(sender, BackgroundWorker)
resend: While True
            If CheckBox1.Checked = False Then
                SSS = 0
                'BackgroundWorker2.CancelAsync()
                Exit Sub
            End If
            SSS = SSS + 1
            worker.ReportProgress(SSS)
            Ssecand = cycletime

            If flagreset = True Then
                flagreset = False
                '  GoTo Reset
            End If
            If SSS = Ssecand Then
                AGVTcpControl.Master_cell = "Resend"
                SSS = 0
                '    Update_label(AGVTcpControl.Master_cell, lblsignal2, Color.Gray)
                Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                Ssecand = 0
                worker.ReportProgress(SSS)
                If BackgroundWorker1.IsBusy <> True Then
                    BackgroundWorker1.RunWorkerAsync()
                End If
                ' Exit While
            End If
            If SSS > DelayFinal Or CheckBox1.Checked = False Then
                flaglooptime = False

            End If
            If (worker.CancellationPending = True) Then
                e.Cancel = True
            Else
                System.Threading.Thread.Sleep(1000)
            End If

        End While
        '    Exit While
        'End If
        If (worker.CancellationPending = True) Then
            e.Cancel = True
        Else
            System.Threading.Thread.Sleep(1000)
        End If
        '* End While
    End Sub
    Private Sub BackgroundWorker2_ProgressChanged(sender As Object, e As ProgressChangedEventArgs) Handles BackgroundWorker2.ProgressChanged
        Update_label(e.ProgressPercentage.ToString(), TstrCycleCount, Color.SeaShell, Nothing)
    End Sub

    Private Sub BackgroundWorker2_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker2.RunWorkerCompleted
    End Sub

    Private Sub frmMain2_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        myChat.disconnect() 'TCPChat Disconnect Host
    End Sub

#End Region
#Region "TCP Chat Function"
    Private Sub TCPChat_Sender(ByVal TCPsender As String)
        With CType(TCPsender, String)
            If TCPsender.Length > 0 Then
                myChat.SendData(TCPsender, "127.0.0.1", 5000)
                TCPsender = ""
            End If
        End With

    End Sub
    Public Sub txtOut(ByVal txt As String) Handles myChat.Datareceived
        If txt <> "200" Then
            UpdateStatus("< " & txt, lbout)
            Dim delimiter() As String = {"|"}
            Dim resArray() As String = txt.Split(delimiter, StringSplitOptions.None)
            If resArray.Length = 3 Then
                getcell = resArray(0)
                getadd = resArray(1)
                getstatus = resArray(2)
                '   getResultdelay = resArray(3)
                '<< SendTCP("A" & "|" & strb & "|" & Comconfig.CellNo)
                '>> SendTCP("Ans" & "|" & getstatus & "|" & DateAndTime.TimeString, CInt(Readconfig.RemotePortCell1))
                '   If getcell = "Ans" And getadd = strbGo Then
                If getcell = "Ans" Then
                    getaddgo = getadd
                    Send_Packet_to_AGV(_rs232Send, ADDGo, &H4F, &H4B)
                    For i = 0 To ADDGo.Length - 1
                        ADDGo(i) = 0
                    Next
                    show_ADD = ""
                    ' ElseIf getcell = "SEND" And getadd = strbGo Then
                ElseIf getcell = "SEND" Then
                    If Not DicQueueRequest.ContainsKey(txt) Then
                        QueueManage.Enqueue_AGV(obj3, ListBox1, txt)
                        DicQueueRequest.Add(txt, "1")
                        updateAGVQ(obj3, ListBox1)
                        ADDGo = Reconvert.convert(getadd, " ")
                        Requestsendline = CByte(getstatus)
                        getaddgo = getadd
                        '  statusbox = Comconfig.IOValue
                        '   SendTCP("SEND" & "|" & res & "|" & Requestsendline.ToString, CInt(Readconfig.RemotePortCell3))
                        If BackgroundWorker6.IsBusy <> True And CheckBox3.Checked = True Then
                            Update_button("Start" & AGVTcpControl.Master_cell, Button2, colorlabel, colorFore)
                            Delay(0.5)
                            BackgroundWorker6.RunWorkerAsync()
                        End If
                        Delay(2)
                    End If
                    SendTCP("SUCCESS" & "|" & Comconfig.CellNo.ToString & "|" & strbGo2 & "|" & getstatus)
                ElseIf getcell = "DELAY" Then
                    ResultDelay = getadd
                End If
            End If
            getcell = ""
            getadd = ""
            getstatus = ""
            resArray(0) = ""
            resArray(1) = ""
            resArray(2) = ""
        End If

    End Sub
#End Region
#Region "BG6_CheckIO"
    Private Sub BackgroundWorker6_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker6.DoWork
        Try
            Dim Pac(20), addT(3), Card2(3) As Byte
            Dim strdata2, strb3, AGVName, res As String
            Dim addFixsend(3) As Byte
            Dim addfixuptime(3) As Byte
            Static CountSent As Integer
resend:     While True
                If obj3.Count > 0 Then
                    QueueManage.Peek_3(obj3, Pac, strdata2, addT, res, AGVName)
                    strb3 = Hex(addT(0)).PadLeft(2, "0"c) & Hex(addT(1)).PadLeft(2, "0"c) & Hex(addT(2)).PadLeft(2, "0"c) & Hex(addT(3)).PadLeft(2, "0"c)
                    flagcheckio = True
                    MessageKEY = strdata2
                    strbGo = strb3
                    'If statusbox = Comconfig.IOValue Then
                    '   Comparesend(CountSent, addT, AGVName)
                    If CheckBox2.Checked = True Then
                        Delay(CInt(ResultDelay))
                    End If
                    Do
                        'Update_label("R", Label18, Color.Black, Color.Orange)
                        If CountSent = CInt(Comconfig.SendCount) Or flagcancel2 = True Then
                            ' flagcancel2 = False
                            CountSent = 0
                            Exit Do
                        End If
                        CountSent += 1
                        Delay(0.5)
                        Send_cmd_tOagv(_rs232Send, addT, &H3, &H52, Requestsendline)
                        'Update_label("R", Label18, Color.White, Color.Orange)
                    Loop Until receiveadd = AGVName And responsefromAGV = "Route" & Requestsendline
                    CountSent = 0
                    responsefromAGV = ""
                    Dim fixaddUpTime1 As String = ReadPCsetting2.dicaddRCV.Item("99")
                    Dim fixaddUpTime2 As String
                    fixaddUpTime2 = Reconvert.FormatAdd("## ## ## ##", fixaddUpTime1)
                    addfixuptime = Reconvert.convert(fixaddUpTime2, " ")
                    Dim fixaddsend As String = ReadPCsetting2.dicaddRCV.Item(Requestsendline.ToString)
                    Dim fixaddsend2 As String
                    fixaddsend2 = Reconvert.FormatAdd("## ## ## ##", fixaddsend)
                    addFixsend = Reconvert.convert(fixaddsend2, " ")
                    Do
                        ' Update_label("A", Label18, Color.Black, Color.BlueViolet)
                        If CountSent = 7 Or flagcancel2 = True Then
                            '  flagcancel2 = False
                            CountSent = 0
                            Exit Do
                        End If
                        CountSent += 1
                        Delay(0.7)
                        Send_cmd_04(_rs232Send, addT, &H2, addFixsend)
                    Loop Until receiveadd = AGVName And responsefromAGV = "ADD"
                    CountSent = 0
                    responsefromAGV = ""
                    '  End If
                    '  If ChkC01.Checked = True Then
                    Do
                        ' Update_label("S", Label18, Color.Black, Color.Pink)
                        If CountSent = CInt(Comconfig.SendCount) Or flagcancel2 = True Then
                            flagcancel2 = False
                            CountSent = 0
                            Exit Do
                        End If
                        CountSent += 1
                        Delay(0.5)
                        Send_cmd_tOagv(_rs232Send, addT, &H1, &H0, &H0)
                        'Update_label("S", Label18, Color.White, Color.Pink)
                    Loop Until receiveadd = AGVName And responsefromAGV = "OK"
                    strbGo2 = Hex(ADDGo(0)).PadLeft(2, "0"c) & " " & Hex(ADDGo(1)).PadLeft(2, "0"c) & " " & Hex(ADDGo(2)).PadLeft(2, "0"c) & " " & Hex(ADDGo(3)).PadLeft(2, "0"c)
                    CountSent = 0
                    responsefromAGV = ""
                    ' Requestsendline = 0
                    AGVName = ""
                    Update_label(" ", Label18, Color.Transparent, Color.Pink)
                    If CheckBox4.Checked = False Then
                        If obj3.Count > 0 Then
                            '  flagcancel2 = True
                            MessageKEY = obj3.Peek()
                            QueueManage.deDequeue_AGV(obj3, ListBox1)
                            updateAGVQ(obj3, ListBox1)
                        End If
                        Dim delimiter() As String = {"|"}
                        Dim resArray() As String = MessageKEY.Split(delimiter, StringSplitOptions.None)
                        If resArray.Length = 3 Then
                            getcell2 = resArray(0)
                            getadd2 = resArray(1)
                            getstatus2 = resArray(2)
                            '  If getadd2 = strbGo And DicQueueRequest.ContainsKey(MessageKEY) Then
                            If DicQueueRequest.ContainsKey(MessageKEY) Then
                                SendTCP("CLRKEY" & "|" & getadd2 & "|" & Comconfig.CellNo & "|" & "CLR")
                                DicQueueRequest.Remove(MessageKEY)
                                MessageKEY = ""
                                ' strbGo = ""
                            End If
                            System.Threading.Thread.Sleep(500)
                            SendTCP("CLRAGV" & "|" & getadd2 & "|" & Comconfig.CellNo & "|" & "CLR")
                        End If

                    End If
                    If obj3.Count > 0 Then
                        GoTo resend
                    Else
                        Exit While
                    End If
                ElseIf obj3.Count <= 0 Then
                    Exit While
                End If
            End While
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Sub BackgroundWorker6_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker6.RunWorkerCompleted
        timelasecheck = Now
        flagcancel2 = False
    End Sub
    Private Sub Comparesend(ByVal CountSent As Integer, ByVal addFixsend() As Byte, ByVal compareAdd As String)


    End Sub

#End Region
End Class
