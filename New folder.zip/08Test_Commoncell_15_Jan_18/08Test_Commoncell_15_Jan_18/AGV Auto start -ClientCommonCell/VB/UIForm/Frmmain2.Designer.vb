﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblGetport = New System.Windows.Forms.Label()
        Me.lblRxCnt = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.status0 = New System.Windows.Forms.Label()
        Me.SplitContainer5 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtstatus1 = New System.Windows.Forms.Label()
        Me.lblGetportSend = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblTxCntSend = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.btnConnectSend = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtstatus2 = New System.Windows.Forms.Label()
        Me.lblGetportIO = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.lblRxCntIO = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.btnConnectIO = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Menu1 = New System.Windows.Forms.MenuStrip()
        Me.FileTool = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadConfig = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveConfig = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tcboselect = New System.Windows.Forms.ToolStripComboBox()
        Me.cboComPort = New System.Windows.Forms.ToolStripComboBox()
        Me.cboBaudrate = New System.Windows.Forms.ToolStripComboBox()
        Me.cboDataBits = New System.Windows.Forms.ToolStripComboBox()
        Me.cboParity = New System.Windows.Forms.ToolStripComboBox()
        Me.cboStopbits = New System.Windows.Forms.ToolStripComboBox()
        Me.cboDelay = New System.Windows.Forms.ToolStripComboBox()
        Me.cboThreshold = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitTool = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionsTool = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReceiveboxFontToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LargeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MediumToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SmallToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFormToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnSettime = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetTimeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DelayFinalSendToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DelayBeforeResendToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetValueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetUpAGVToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetUp0401ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetUp0401BordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetUp0402ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetUp03ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartCMD01ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopCMD02ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetAGVNOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.TstrCycleCount = New System.Windows.Forms.Label()
        Me.lblIO03 = New System.Windows.Forms.Label()
        Me.tstrCard = New System.Windows.Forms.Label()
        Me.TstrCell = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer8 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel7 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel8 = New System.Windows.Forms.TableLayoutPanel()
        Me.SplitContainer6 = New System.Windows.Forms.SplitContainer()
        Me.lblIO01 = New System.Windows.Forms.Label()
        Me.SplitContainer7 = New System.Windows.Forms.SplitContainer()
        Me.lblIO02 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel9 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ListInQueue1 = New System.Windows.Forms.ListBox()
        Me.TableLayoutPanel10 = New System.Windows.Forms.TableLayoutPanel()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.lbout = New System.Windows.Forms.ListBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblA5 = New System.Windows.Forms.Label()
        Me.lblA6 = New System.Windows.Forms.Label()
        Me.lblA7 = New System.Windows.Forms.Label()
        Me.lblA8 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblA1 = New System.Windows.Forms.Label()
        Me.lblA2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblA3 = New System.Windows.Forms.Label()
        Me.lblA4 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.LblStaIO = New System.Windows.Forms.Label()
        Me.lblA9 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.StatusStrip6 = New System.Windows.Forms.StatusStrip()
        Me.TstaTCPSignal = New System.Windows.Forms.ToolStripStatusLabel()
        Me.T1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.T2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lblCommontext = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker2 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker3 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker4 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker5 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker6 = New System.ComponentModel.BackgroundWorker()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorker7 = New System.ComponentModel.BackgroundWorker()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.SplitContainer4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        CType(Me.SplitContainer5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer5.Panel1.SuspendLayout()
        Me.SplitContainer5.Panel2.SuspendLayout()
        Me.SplitContainer5.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Menu1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.SplitContainer8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer8.Panel1.SuspendLayout()
        Me.SplitContainer8.Panel2.SuspendLayout()
        Me.SplitContainer8.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.TableLayoutPanel7.SuspendLayout()
        Me.TableLayoutPanel8.SuspendLayout()
        CType(Me.SplitContainer6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer6.Panel1.SuspendLayout()
        Me.SplitContainer6.Panel2.SuspendLayout()
        Me.SplitContainer6.SuspendLayout()
        CType(Me.SplitContainer7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer7.Panel2.SuspendLayout()
        Me.SplitContainer7.SuspendLayout()
        Me.TableLayoutPanel9.SuspendLayout()
        Me.TableLayoutPanel10.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.StatusStrip6.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer4)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Menu1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(584, 742)
        Me.SplitContainer1.SplitterDistance = 99
        Me.SplitContainer1.TabIndex = 0
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 27)
        Me.SplitContainer4.Name = "SplitContainer4"
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.TableLayoutPanel2)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.SplitContainer5)
        Me.SplitContainer4.Size = New System.Drawing.Size(584, 72)
        Me.SplitContainer4.SplitterDistance = 192
        Me.SplitContainer4.TabIndex = 4
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Label9, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label16, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.lblGetport, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.lblRxCnt, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label1, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.btnConnect, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label2, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.status0, 1, 3)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 4
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(192, 72)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'Label9
        '
        Me.Label9.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(4, 43)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 15)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Com NO."
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label16
        '
        Me.Label16.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(4, 59)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(79, 15)
        Me.Label16.TabIndex = 15
        Me.Label16.Text = "Status:"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblGetport
        '
        Me.lblGetport.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblGetport.AutoSize = True
        Me.lblGetport.BackColor = System.Drawing.Color.Transparent
        Me.lblGetport.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGetport.Location = New System.Drawing.Point(90, 43)
        Me.lblGetport.Name = "lblGetport"
        Me.lblGetport.Size = New System.Drawing.Size(98, 15)
        Me.lblGetport.TabIndex = 13
        Me.lblGetport.Text = "com1"
        Me.lblGetport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRxCnt
        '
        Me.lblRxCnt.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblRxCnt.AutoSize = True
        Me.lblRxCnt.BackColor = System.Drawing.Color.Transparent
        Me.lblRxCnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRxCnt.Location = New System.Drawing.Point(90, 27)
        Me.lblRxCnt.Name = "lblRxCnt"
        Me.lblRxCnt.Size = New System.Drawing.Size(98, 15)
        Me.lblRxCnt.TabIndex = 11
        Me.lblRxCnt.Text = "00000"
        Me.lblRxCnt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 15)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "RX Count:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnConnect
        '
        Me.btnConnect.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnConnect.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConnect.Location = New System.Drawing.Point(90, 4)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(98, 19)
        Me.btnConnect.TabIndex = 3
        Me.btnConnect.Text = "*connect*"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.LightGray
        Me.Label2.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(4, 1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 25)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "[1]RECEIVE:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'status0
        '
        Me.status0.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.status0.AutoSize = True
        Me.status0.BackColor = System.Drawing.Color.Transparent
        Me.status0.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.status0.Location = New System.Drawing.Point(90, 59)
        Me.status0.Name = "status0"
        Me.status0.Size = New System.Drawing.Size(98, 15)
        Me.status0.TabIndex = 14
        Me.status0.Text = "null"
        Me.status0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SplitContainer5
        '
        Me.SplitContainer5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer5.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer5.Name = "SplitContainer5"
        '
        'SplitContainer5.Panel1
        '
        Me.SplitContainer5.Panel1.Controls.Add(Me.TableLayoutPanel3)
        '
        'SplitContainer5.Panel2
        '
        Me.SplitContainer5.Panel2.Controls.Add(Me.TableLayoutPanel4)
        Me.SplitContainer5.Size = New System.Drawing.Size(388, 72)
        Me.SplitContainer5.SplitterDistance = 203
        Me.SplitContainer5.TabIndex = 0
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Label8, 0, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.txtstatus1, 0, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.lblGetportSend, 1, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.Label17, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.lblTxCntSend, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label20, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.btnConnectSend, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Label21, 0, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 4
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(203, 72)
        Me.TableLayoutPanel3.TabIndex = 1
        '
        'Label8
        '
        Me.Label8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(4, 59)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 15)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Status:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtstatus1
        '
        Me.txtstatus1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtstatus1.AutoSize = True
        Me.txtstatus1.BackColor = System.Drawing.Color.Transparent
        Me.txtstatus1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstatus1.Location = New System.Drawing.Point(85, 59)
        Me.txtstatus1.Name = "txtstatus1"
        Me.txtstatus1.Size = New System.Drawing.Size(114, 15)
        Me.txtstatus1.TabIndex = 14
        Me.txtstatus1.Text = "null"
        Me.txtstatus1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGetportSend
        '
        Me.lblGetportSend.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblGetportSend.AutoSize = True
        Me.lblGetportSend.BackColor = System.Drawing.Color.Transparent
        Me.lblGetportSend.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGetportSend.Location = New System.Drawing.Point(85, 43)
        Me.lblGetportSend.Name = "lblGetportSend"
        Me.lblGetportSend.Size = New System.Drawing.Size(114, 15)
        Me.lblGetportSend.TabIndex = 13
        Me.lblGetportSend.Text = "com1"
        Me.lblGetportSend.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(4, 43)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(74, 15)
        Me.Label17.TabIndex = 12
        Me.Label17.Text = "Com NO."
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTxCntSend
        '
        Me.lblTxCntSend.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTxCntSend.AutoSize = True
        Me.lblTxCntSend.BackColor = System.Drawing.Color.Transparent
        Me.lblTxCntSend.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTxCntSend.Location = New System.Drawing.Point(85, 27)
        Me.lblTxCntSend.Name = "lblTxCntSend"
        Me.lblTxCntSend.Size = New System.Drawing.Size(114, 15)
        Me.lblTxCntSend.TabIndex = 11
        Me.lblTxCntSend.Text = "00000"
        Me.lblTxCntSend.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(4, 27)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(74, 15)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "TX Count:"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnConnectSend
        '
        Me.btnConnectSend.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnConnectSend.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConnectSend.Location = New System.Drawing.Point(85, 4)
        Me.btnConnectSend.Name = "btnConnectSend"
        Me.btnConnectSend.Size = New System.Drawing.Size(114, 19)
        Me.btnConnectSend.TabIndex = 3
        Me.btnConnectSend.Text = "*connect*"
        Me.btnConnectSend.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label21.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(4, 1)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(74, 25)
        Me.Label21.TabIndex = 9
        Me.Label21.Text = "[2]SEND :"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Label22, 0, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.txtstatus2, 0, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.lblGetportIO, 1, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label25, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.lblRxCntIO, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label27, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.btnConnectIO, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label28, 0, 0)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 4
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(181, 72)
        Me.TableLayoutPanel4.TabIndex = 1
        '
        'Label22
        '
        Me.Label22.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(4, 59)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(65, 15)
        Me.Label22.TabIndex = 15
        Me.Label22.Text = "Status:"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtstatus2
        '
        Me.txtstatus2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtstatus2.AutoSize = True
        Me.txtstatus2.BackColor = System.Drawing.Color.Transparent
        Me.txtstatus2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstatus2.Location = New System.Drawing.Point(76, 59)
        Me.txtstatus2.Name = "txtstatus2"
        Me.txtstatus2.Size = New System.Drawing.Size(101, 15)
        Me.txtstatus2.TabIndex = 14
        Me.txtstatus2.Text = "null"
        Me.txtstatus2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGetportIO
        '
        Me.lblGetportIO.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblGetportIO.AutoSize = True
        Me.lblGetportIO.BackColor = System.Drawing.Color.Transparent
        Me.lblGetportIO.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGetportIO.Location = New System.Drawing.Point(76, 43)
        Me.lblGetportIO.Name = "lblGetportIO"
        Me.lblGetportIO.Size = New System.Drawing.Size(101, 15)
        Me.lblGetportIO.TabIndex = 13
        Me.lblGetportIO.Text = "com1"
        Me.lblGetportIO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label25
        '
        Me.Label25.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(4, 43)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(65, 15)
        Me.Label25.TabIndex = 12
        Me.Label25.Text = "Com NO."
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblRxCntIO
        '
        Me.lblRxCntIO.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblRxCntIO.AutoSize = True
        Me.lblRxCntIO.BackColor = System.Drawing.Color.Transparent
        Me.lblRxCntIO.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRxCntIO.Location = New System.Drawing.Point(76, 27)
        Me.lblRxCntIO.Name = "lblRxCntIO"
        Me.lblRxCntIO.Size = New System.Drawing.Size(101, 15)
        Me.lblRxCntIO.TabIndex = 11
        Me.lblRxCntIO.Text = "00000"
        Me.lblRxCntIO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label27
        '
        Me.Label27.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(4, 27)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(65, 15)
        Me.Label27.TabIndex = 10
        Me.Label27.Text = "RX Count:"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnConnectIO
        '
        Me.btnConnectIO.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnConnectIO.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConnectIO.Location = New System.Drawing.Point(76, 4)
        Me.btnConnectIO.Name = "btnConnectIO"
        Me.btnConnectIO.Size = New System.Drawing.Size(101, 19)
        Me.btnConnectIO.TabIndex = 3
        Me.btnConnectIO.Text = "*connect*"
        Me.btnConnectIO.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.SystemColors.Info
        Me.Label28.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(4, 1)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(65, 25)
        Me.Label28.TabIndex = 9
        Me.Label28.Text = "[3] IO :"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Menu1
        '
        Me.Menu1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileTool, Me.OptionsTool, Me.ToolStripMenuItem3, Me.SetUpAGVToolStripMenuItem, Me.ToolStripTextBox1})
        Me.Menu1.Location = New System.Drawing.Point(0, 0)
        Me.Menu1.Name = "Menu1"
        Me.Menu1.Size = New System.Drawing.Size(584, 27)
        Me.Menu1.TabIndex = 3
        Me.Menu1.Text = "MenuStrip1"
        '
        'FileTool
        '
        Me.FileTool.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadConfig, Me.SaveConfig, Me.ExitTool})
        Me.FileTool.Name = "FileTool"
        Me.FileTool.Size = New System.Drawing.Size(37, 23)
        Me.FileTool.Text = "File"
        '
        'LoadConfig
        '
        Me.LoadConfig.Image = Global.comTerm.My.Resources.Resources.Disk
        Me.LoadConfig.Name = "LoadConfig"
        Me.LoadConfig.Size = New System.Drawing.Size(137, 22)
        Me.LoadConfig.Text = "Load config"
        '
        'SaveConfig
        '
        Me.SaveConfig.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tcboselect, Me.cboComPort, Me.cboBaudrate, Me.cboDataBits, Me.cboParity, Me.cboStopbits, Me.cboDelay, Me.cboThreshold, Me.ToolStripMenuItem1})
        Me.SaveConfig.Image = Global.comTerm.My.Resources.Resources.Disk_download
        Me.SaveConfig.Name = "SaveConfig"
        Me.SaveConfig.Size = New System.Drawing.Size(137, 22)
        Me.SaveConfig.Text = "save config"
        '
        'Tcboselect
        '
        Me.Tcboselect.Items.AddRange(New Object() {"Receive Comport", "Send Comport"})
        Me.Tcboselect.Name = "Tcboselect"
        Me.Tcboselect.Size = New System.Drawing.Size(121, 23)
        Me.Tcboselect.Text = "<Select one>"
        '
        'cboComPort
        '
        Me.cboComPort.AutoSize = False
        Me.cboComPort.MergeAction = System.Windows.Forms.MergeAction.MatchOnly
        Me.cboComPort.Name = "cboComPort"
        Me.cboComPort.Size = New System.Drawing.Size(100, 23)
        Me.cboComPort.Text = "<Port>"
        '
        'cboBaudrate
        '
        Me.cboBaudrate.AutoSize = False
        Me.cboBaudrate.DropDownWidth = 50
        Me.cboBaudrate.Items.AddRange(New Object() {"2400", "4800", "9600", "19200", "38400", "115200"})
        Me.cboBaudrate.Name = "cboBaudrate"
        Me.cboBaudrate.Size = New System.Drawing.Size(100, 23)
        Me.cboBaudrate.Text = "<Baud>"
        '
        'cboDataBits
        '
        Me.cboDataBits.AutoSize = False
        Me.cboDataBits.Items.AddRange(New Object() {"7", "8"})
        Me.cboDataBits.Name = "cboDataBits"
        Me.cboDataBits.Size = New System.Drawing.Size(100, 23)
        Me.cboDataBits.Text = "<data>"
        '
        'cboParity
        '
        Me.cboParity.AutoSize = False
        Me.cboParity.Items.AddRange(New Object() {"None", "Even", "Mark", "Odd", "Space"})
        Me.cboParity.Name = "cboParity"
        Me.cboParity.Size = New System.Drawing.Size(100, 23)
        Me.cboParity.Text = "<Parity>"
        '
        'cboStopbits
        '
        Me.cboStopbits.AutoSize = False
        Me.cboStopbits.DropDownWidth = 50
        Me.cboStopbits.Items.AddRange(New Object() {"None", "One", "Two"})
        Me.cboStopbits.Name = "cboStopbits"
        Me.cboStopbits.Size = New System.Drawing.Size(100, 23)
        Me.cboStopbits.Text = "<Stop>"
        '
        'cboDelay
        '
        Me.cboDelay.AutoSize = False
        Me.cboDelay.Items.AddRange(New Object() {"1", "2", "5", "10", "20", "50", "100", "200", "500", "1000"})
        Me.cboDelay.Name = "cboDelay"
        Me.cboDelay.Size = New System.Drawing.Size(100, 23)
        Me.cboDelay.Text = "<Delay>"
        Me.cboDelay.ToolTipText = "Datareceived handle delay"
        '
        'cboThreshold
        '
        Me.cboThreshold.AutoSize = False
        Me.cboThreshold.Items.AddRange(New Object() {"1", "2", "5", "10", "20", "50", "100", "200", "500", "1000"})
        Me.cboThreshold.Name = "cboThreshold"
        Me.cboThreshold.Size = New System.Drawing.Size(100, 23)
        Me.cboThreshold.Text = "<thresh>"
        Me.cboThreshold.ToolTipText = ".receivedBytesThreshold property"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.BackColor = System.Drawing.Color.Silver
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(181, 22)
        Me.ToolStripMenuItem1.Text = "Save Data"
        '
        'ExitTool
        '
        Me.ExitTool.Image = Global.comTerm.My.Resources.Resources.Standby
        Me.ExitTool.Name = "ExitTool"
        Me.ExitTool.Size = New System.Drawing.Size(137, 22)
        Me.ExitTool.Text = "Exit"
        '
        'OptionsTool
        '
        Me.OptionsTool.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReceiveboxFontToolStripMenuItem, Me.OpenFormToolStripMenuItem, Me.btnSettime, Me.ToolStripMenuItem4, Me.ResetTimeToolStripMenuItem, Me.DelayFinalSendToolStripMenuItem, Me.DelayBeforeResendToolStripMenuItem, Me.ToolStripMenuItem5, Me.ResetValueToolStripMenuItem, Me.ResetDataToolStripMenuItem})
        Me.OptionsTool.Name = "OptionsTool"
        Me.OptionsTool.Size = New System.Drawing.Size(61, 23)
        Me.OptionsTool.Text = "Options"
        '
        'ReceiveboxFontToolStripMenuItem
        '
        Me.ReceiveboxFontToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LargeToolStripMenuItem, Me.MediumToolStripMenuItem, Me.SmallToolStripMenuItem})
        Me.ReceiveboxFontToolStripMenuItem.Name = "ReceiveboxFontToolStripMenuItem"
        Me.ReceiveboxFontToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ReceiveboxFontToolStripMenuItem.Text = "font"
        '
        'LargeToolStripMenuItem
        '
        Me.LargeToolStripMenuItem.Name = "LargeToolStripMenuItem"
        Me.LargeToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.LargeToolStripMenuItem.Text = "Large"
        '
        'MediumToolStripMenuItem
        '
        Me.MediumToolStripMenuItem.Name = "MediumToolStripMenuItem"
        Me.MediumToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.MediumToolStripMenuItem.Text = "Medium"
        '
        'SmallToolStripMenuItem
        '
        Me.SmallToolStripMenuItem.Name = "SmallToolStripMenuItem"
        Me.SmallToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.SmallToolStripMenuItem.Text = "Small"
        '
        'OpenFormToolStripMenuItem
        '
        Me.OpenFormToolStripMenuItem.Name = "OpenFormToolStripMenuItem"
        Me.OpenFormToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.OpenFormToolStripMenuItem.Text = "open form"
        '
        'btnSettime
        '
        Me.btnSettime.Name = "btnSettime"
        Me.btnSettime.Size = New System.Drawing.Size(181, 22)
        Me.btnSettime.Text = "Set time"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(181, 22)
        Me.ToolStripMenuItem4.Text = "Set cycle time"
        '
        'ResetTimeToolStripMenuItem
        '
        Me.ResetTimeToolStripMenuItem.Name = "ResetTimeToolStripMenuItem"
        Me.ResetTimeToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ResetTimeToolStripMenuItem.Text = "Reset time"
        '
        'DelayFinalSendToolStripMenuItem
        '
        Me.DelayFinalSendToolStripMenuItem.Name = "DelayFinalSendToolStripMenuItem"
        Me.DelayFinalSendToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DelayFinalSendToolStripMenuItem.Text = "Delay Final Send"
        '
        'DelayBeforeResendToolStripMenuItem
        '
        Me.DelayBeforeResendToolStripMenuItem.Name = "DelayBeforeResendToolStripMenuItem"
        Me.DelayBeforeResendToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DelayBeforeResendToolStripMenuItem.Text = "Delay Before Resend"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(181, 22)
        Me.ToolStripMenuItem5.Text = "Show Start Record"
        '
        'ResetValueToolStripMenuItem
        '
        Me.ResetValueToolStripMenuItem.Name = "ResetValueToolStripMenuItem"
        Me.ResetValueToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ResetValueToolStripMenuItem.Text = "Reset Value"
        '
        'ResetDataToolStripMenuItem
        '
        Me.ResetDataToolStripMenuItem.Name = "ResetDataToolStripMenuItem"
        Me.ResetDataToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ResetDataToolStripMenuItem.Text = "Reset Data"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(12, 23)
        '
        'SetUpAGVToolStripMenuItem
        '
        Me.SetUpAGVToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SetUp0401ToolStripMenuItem, Me.SetUp0401BordToolStripMenuItem, Me.SetUp0402ToolStripMenuItem, Me.SetUp03ToolStripMenuItem, Me.StartCMD01ToolStripMenuItem, Me.StopCMD02ToolStripMenuItem, Me.SetAGVNOToolStripMenuItem})
        Me.SetUpAGVToolStripMenuItem.Name = "SetUpAGVToolStripMenuItem"
        Me.SetUpAGVToolStripMenuItem.Size = New System.Drawing.Size(79, 23)
        Me.SetUpAGVToolStripMenuItem.Text = "Set Up AGV"
        '
        'SetUp0401ToolStripMenuItem
        '
        Me.SetUp0401ToolStripMenuItem.Name = "SetUp0401ToolStripMenuItem"
        Me.SetUp0401ToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.SetUp0401ToolStripMenuItem.Text = "Set Up 04 01"
        '
        'SetUp0401BordToolStripMenuItem
        '
        Me.SetUp0401BordToolStripMenuItem.Name = "SetUp0401BordToolStripMenuItem"
        Me.SetUp0401BordToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.SetUp0401BordToolStripMenuItem.Text = "Set Up 04 01 boardcast"
        '
        'SetUp0402ToolStripMenuItem
        '
        Me.SetUp0402ToolStripMenuItem.Name = "SetUp0402ToolStripMenuItem"
        Me.SetUp0402ToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.SetUp0402ToolStripMenuItem.Text = "Set up 04 02"
        '
        'SetUp03ToolStripMenuItem
        '
        Me.SetUp03ToolStripMenuItem.Name = "SetUp03ToolStripMenuItem"
        Me.SetUp03ToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.SetUp03ToolStripMenuItem.Text = "Set Up 03 "
        '
        'StartCMD01ToolStripMenuItem
        '
        Me.StartCMD01ToolStripMenuItem.Name = "StartCMD01ToolStripMenuItem"
        Me.StartCMD01ToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.StartCMD01ToolStripMenuItem.Text = "Start CMD(01)"
        '
        'StopCMD02ToolStripMenuItem
        '
        Me.StopCMD02ToolStripMenuItem.Name = "StopCMD02ToolStripMenuItem"
        Me.StopCMD02ToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.StopCMD02ToolStripMenuItem.Text = "Stop CMD(02)"
        '
        'SetAGVNOToolStripMenuItem
        '
        Me.SetAGVNOToolStripMenuItem.Name = "SetAGVNOToolStripMenuItem"
        Me.SetAGVNOToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.SetAGVNOToolStripMenuItem.Text = "Set AGV NO."
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(100, 23)
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.TableLayoutPanel5)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer3)
        Me.SplitContainer2.Size = New System.Drawing.Size(584, 639)
        Me.SplitContainer2.SplitterDistance = 107
        Me.SplitContainer2.TabIndex = 0
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel5.ColumnCount = 7
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 64.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 71.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 116.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 85.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 207.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.Label23, 4, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Button4, 4, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.Label42, 6, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.Label41, 5, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.TstrCycleCount, 3, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.lblIO03, 2, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.tstrCard, 1, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.TstrCell, 0, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.Label35, 6, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label34, 5, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label32, 3, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label31, 2, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label30, 1, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label29, 0, 0)
        Me.TableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 2
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.52252!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 77.47748!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(584, 107)
        Me.TableLayoutPanel5.TabIndex = 142
        '
        'Label23
        '
        Me.Label23.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(284, 1)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(110, 23)
        Me.Label23.TabIndex = 135
        Me.Label23.Text = "#Wait Start "
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 42.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.Location = New System.Drawing.Point(284, 28)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(110, 75)
        Me.Button4.TabIndex = 134
        Me.Button4.Text = "-"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.BackColor = System.Drawing.Color.Transparent
        Me.Label42.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label42.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label42.Location = New System.Drawing.Point(487, 25)
        Me.Label42.MaximumSize = New System.Drawing.Size(80, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(80, 81)
        Me.Label42.TabIndex = 25
        Me.Label42.Text = "00 Sec"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label41
        '
        Me.Label41.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label41.AutoSize = True
        Me.Label41.BackColor = System.Drawing.Color.Transparent
        Me.Label41.Font = New System.Drawing.Font("Arial", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label41.Location = New System.Drawing.Point(401, 25)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(79, 81)
        Me.Label41.TabIndex = 24
        Me.Label41.Text = "#Delay"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TstrCycleCount
        '
        Me.TstrCycleCount.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TstrCycleCount.AutoSize = True
        Me.TstrCycleCount.BackColor = System.Drawing.Color.Transparent
        Me.TstrCycleCount.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TstrCycleCount.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.TstrCycleCount.Location = New System.Drawing.Point(214, 25)
        Me.TstrCycleCount.Name = "TstrCycleCount"
        Me.TstrCycleCount.Size = New System.Drawing.Size(63, 81)
        Me.TstrCycleCount.TabIndex = 22
        Me.TstrCycleCount.Text = "000"
        Me.TstrCycleCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblIO03
        '
        Me.lblIO03.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblIO03.AutoSize = True
        Me.lblIO03.BackColor = System.Drawing.Color.Transparent
        Me.lblIO03.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIO03.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblIO03.Location = New System.Drawing.Point(142, 25)
        Me.lblIO03.Name = "lblIO03"
        Me.lblIO03.Size = New System.Drawing.Size(65, 81)
        Me.lblIO03.TabIndex = 21
        Me.lblIO03.Text = "Rst"
        Me.lblIO03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tstrCard
        '
        Me.tstrCard.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tstrCard.AutoSize = True
        Me.tstrCard.BackColor = System.Drawing.Color.Transparent
        Me.tstrCard.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tstrCard.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.tstrCard.Location = New System.Drawing.Point(77, 25)
        Me.tstrCard.Name = "tstrCard"
        Me.tstrCard.Size = New System.Drawing.Size(58, 81)
        Me.tstrCard.TabIndex = 20
        Me.tstrCard.Text = "210"
        Me.tstrCard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TstrCell
        '
        Me.TstrCell.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TstrCell.AutoSize = True
        Me.TstrCell.BackColor = System.Drawing.Color.Transparent
        Me.TstrCell.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TstrCell.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.TstrCell.Location = New System.Drawing.Point(4, 25)
        Me.TstrCell.Name = "TstrCell"
        Me.TstrCell.Size = New System.Drawing.Size(66, 81)
        Me.TstrCell.TabIndex = 19
        Me.TstrCell.Text = "C3-0"
        Me.TstrCell.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label35
        '
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(487, 1)
        Me.Label35.MaximumSize = New System.Drawing.Size(70, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(70, 23)
        Me.Label35.TabIndex = 18
        Me.Label35.Text = "# Count Delay"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label34
        '
        Me.Label34.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(401, 1)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(79, 23)
        Me.Label34.TabIndex = 17
        Me.Label34.Text = "#Delay Status"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label32
        '
        Me.Label32.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(214, 1)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(63, 23)
        Me.Label32.TabIndex = 15
        Me.Label32.Text = "CT. Count"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label31
        '
        Me.Label31.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(142, 1)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(65, 23)
        Me.Label31.TabIndex = 14
        Me.Label31.Text = "# Reset"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label30
        '
        Me.Label30.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(77, 1)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(58, 23)
        Me.Label30.TabIndex = 13
        Me.Label30.Text = "# RFID NO."
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label29
        '
        Me.Label29.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(4, 1)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(66, 23)
        Me.Label29.TabIndex = 12
        Me.Label29.Text = "#Cell"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.SplitContainer8)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.TableLayoutPanel1)
        Me.SplitContainer3.Size = New System.Drawing.Size(584, 528)
        Me.SplitContainer3.SplitterDistance = 374
        Me.SplitContainer3.TabIndex = 0
        '
        'SplitContainer8
        '
        Me.SplitContainer8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer8.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer8.Name = "SplitContainer8"
        '
        'SplitContainer8.Panel1
        '
        Me.SplitContainer8.Panel1.Controls.Add(Me.TableLayoutPanel6)
        '
        'SplitContainer8.Panel2
        '
        Me.SplitContainer8.Panel2.Controls.Add(Me.TableLayoutPanel10)
        Me.SplitContainer8.Panel2.Controls.Add(Me.Label18)
        Me.SplitContainer8.Size = New System.Drawing.Size(584, 374)
        Me.SplitContainer8.SplitterDistance = 328
        Me.SplitContainer8.TabIndex = 147
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.ColumnCount = 3
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel6.Controls.Add(Me.TableLayoutPanel7, 1, 1)
        Me.TableLayoutPanel6.Controls.Add(Me.TableLayoutPanel8, 1, 3)
        Me.TableLayoutPanel6.Controls.Add(Me.TableLayoutPanel9, 1, 5)
        Me.TableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 7
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.71119!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.28881!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 14.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 136.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(328, 374)
        Me.TableLayoutPanel6.TabIndex = 142
        '
        'TableLayoutPanel7
        '
        Me.TableLayoutPanel7.ColumnCount = 1
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 85.40772!))
        Me.TableLayoutPanel7.Controls.Add(Me.Button2, 0, 0)
        Me.TableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel7.Location = New System.Drawing.Point(19, 12)
        Me.TableLayoutPanel7.Name = "TableLayoutPanel7"
        Me.TableLayoutPanel7.RowCount = 1
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel7.Size = New System.Drawing.Size(291, 73)
        Me.TableLayoutPanel7.TabIndex = 142
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(3, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(285, 67)
        Me.Button2.TabIndex = 129
        Me.Button2.Text = "Signal:"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'TableLayoutPanel8
        '
        Me.TableLayoutPanel8.ColumnCount = 3
        Me.TableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 196.0!))
        Me.TableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.876543!))
        Me.TableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90.12346!))
        Me.TableLayoutPanel8.Controls.Add(Me.SplitContainer6, 2, 0)
        Me.TableLayoutPanel8.Controls.Add(Me.Label7, 0, 0)
        Me.TableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel8.Location = New System.Drawing.Point(19, 99)
        Me.TableLayoutPanel8.Name = "TableLayoutPanel8"
        Me.TableLayoutPanel8.RowCount = 1
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel8.Size = New System.Drawing.Size(291, 113)
        Me.TableLayoutPanel8.TabIndex = 143
        '
        'SplitContainer6
        '
        Me.SplitContainer6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer6.Location = New System.Drawing.Point(208, 3)
        Me.SplitContainer6.Name = "SplitContainer6"
        Me.SplitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer6.Panel1
        '
        Me.SplitContainer6.Panel1.Controls.Add(Me.lblIO01)
        '
        'SplitContainer6.Panel2
        '
        Me.SplitContainer6.Panel2.Controls.Add(Me.SplitContainer7)
        Me.SplitContainer6.Size = New System.Drawing.Size(80, 107)
        Me.SplitContainer6.SplitterDistance = 39
        Me.SplitContainer6.TabIndex = 132
        '
        'lblIO01
        '
        Me.lblIO01.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblIO01.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblIO01.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblIO01.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIO01.Location = New System.Drawing.Point(0, 0)
        Me.lblIO01.Name = "lblIO01"
        Me.lblIO01.Size = New System.Drawing.Size(80, 39)
        Me.lblIO01.TabIndex = 0
        Me.lblIO01.Text = "S1"
        Me.lblIO01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SplitContainer7
        '
        Me.SplitContainer7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer7.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer7.Name = "SplitContainer7"
        Me.SplitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer7.Panel2
        '
        Me.SplitContainer7.Panel2.Controls.Add(Me.lblIO02)
        Me.SplitContainer7.Size = New System.Drawing.Size(80, 64)
        Me.SplitContainer7.SplitterDistance = 26
        Me.SplitContainer7.TabIndex = 0
        '
        'lblIO02
        '
        Me.lblIO02.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblIO02.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblIO02.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblIO02.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIO02.Location = New System.Drawing.Point(0, 0)
        Me.lblIO02.Name = "lblIO02"
        Me.lblIO02.Size = New System.Drawing.Size(80, 34)
        Me.lblIO02.TabIndex = 1
        Me.lblIO02.Text = "S2"
        Me.lblIO02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.LightGray
        Me.Label7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(3, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(190, 113)
        Me.Label7.TabIndex = 131
        Me.Label7.Text = "Kitting Daisha"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel9
        '
        Me.TableLayoutPanel9.ColumnCount = 3
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 97.19299!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.807018!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110.0!))
        Me.TableLayoutPanel9.Controls.Add(Me.Label19, 0, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.Button3, 2, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.Button1, 2, 2)
        Me.TableLayoutPanel9.Controls.Add(Me.ListInQueue1, 0, 2)
        Me.TableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel9.Location = New System.Drawing.Point(19, 232)
        Me.TableLayoutPanel9.Name = "TableLayoutPanel9"
        Me.TableLayoutPanel9.RowCount = 3
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.83784!))
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.16216!))
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62.0!))
        Me.TableLayoutPanel9.Size = New System.Drawing.Size(291, 130)
        Me.TableLayoutPanel9.TabIndex = 144
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.LightGray
        Me.Label19.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label19.Location = New System.Drawing.Point(3, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(169, 59)
        Me.Label19.TabIndex = 130
        Me.Label19.Text = "-:-"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button3
        '
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button3.Location = New System.Drawing.Point(183, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(105, 53)
        Me.Button3.TabIndex = 127
        Me.Button3.Text = "CLR" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Data"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button1.Location = New System.Drawing.Point(183, 70)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 57)
        Me.Button1.TabIndex = 129
        Me.Button1.Text = "Cancel" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "1st"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ListInQueue1
        '
        Me.ListInQueue1.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.ListInQueue1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListInQueue1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListInQueue1.FormattingEnabled = True
        Me.ListInQueue1.ItemHeight = 25
        Me.ListInQueue1.Location = New System.Drawing.Point(3, 70)
        Me.ListInQueue1.Name = "ListInQueue1"
        Me.ListInQueue1.Size = New System.Drawing.Size(169, 57)
        Me.ListInQueue1.TabIndex = 131
        '
        'TableLayoutPanel10
        '
        Me.TableLayoutPanel10.ColumnCount = 1
        Me.TableLayoutPanel10.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel10.Controls.Add(Me.CheckBox2, 0, 5)
        Me.TableLayoutPanel10.Controls.Add(Me.CheckBox1, 0, 3)
        Me.TableLayoutPanel10.Controls.Add(Me.CheckBox3, 0, 2)
        Me.TableLayoutPanel10.Controls.Add(Me.CheckBox4, 0, 5)
        Me.TableLayoutPanel10.Controls.Add(Me.lbout, 0, 1)
        Me.TableLayoutPanel10.Controls.Add(Me.ListBox1, 0, 0)
        Me.TableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel10.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel10.Name = "TableLayoutPanel10"
        Me.TableLayoutPanel10.RowCount = 6
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.63636!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 64.36364!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27.0!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21.0!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel10.Size = New System.Drawing.Size(252, 374)
        Me.TableLayoutPanel10.TabIndex = 147
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(3, 335)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(81, 15)
        Me.CheckBox2.TabIndex = 151
        Me.CheckBox2.Text = "CheckBox2"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(3, 276)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(81, 17)
        Me.CheckBox1.TabIndex = 135
        Me.CheckBox1.Text = "CheckBox1"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Checked = True
        Me.CheckBox3.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox3.Location = New System.Drawing.Point(3, 246)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(87, 17)
        Me.CheckBox3.TabIndex = 147
        Me.CheckBox3.Text = "USE TCP/IP"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(3, 356)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(81, 15)
        Me.CheckBox4.TabIndex = 148
        Me.CheckBox4.Text = "CheckBox4"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'lbout
        '
        Me.lbout.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbout.FormattingEnabled = True
        Me.lbout.Location = New System.Drawing.Point(3, 89)
        Me.lbout.Name = "lbout"
        Me.lbout.Size = New System.Drawing.Size(246, 151)
        Me.lbout.TabIndex = 149
        '
        'ListBox1
        '
        Me.ListBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(3, 3)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(246, 80)
        Me.ListBox1.TabIndex = 150
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(127, 153)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(45, 13)
        Me.Label18.TabIndex = 146
        Me.Label18.Text = "Label18"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.lblA5, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA6, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA7, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA8, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label13, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA1, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA2, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA3, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA4, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label12, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.LblStaIO, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA9, 3, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label15, 2, 4)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 5
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(584, 116)
        Me.TableLayoutPanel1.TabIndex = 2
        '
        'lblA5
        '
        Me.lblA5.AutoSize = True
        Me.lblA5.Location = New System.Drawing.Point(410, 1)
        Me.lblA5.Name = "lblA5"
        Me.lblA5.Size = New System.Drawing.Size(10, 13)
        Me.lblA5.TabIndex = 12
        Me.lblA5.Text = "-"
        '
        'lblA6
        '
        Me.lblA6.AutoSize = True
        Me.lblA6.Location = New System.Drawing.Point(410, 22)
        Me.lblA6.Name = "lblA6"
        Me.lblA6.Size = New System.Drawing.Size(10, 13)
        Me.lblA6.TabIndex = 13
        Me.lblA6.Text = "-"
        '
        'lblA7
        '
        Me.lblA7.AutoSize = True
        Me.lblA7.Location = New System.Drawing.Point(410, 43)
        Me.lblA7.Name = "lblA7"
        Me.lblA7.Size = New System.Drawing.Size(10, 13)
        Me.lblA7.TabIndex = 14
        Me.lblA7.Text = "-"
        '
        'lblA8
        '
        Me.lblA8.AutoSize = True
        Me.lblA8.Location = New System.Drawing.Point(410, 64)
        Me.lblA8.Name = "lblA8"
        Me.lblA8.Size = New System.Drawing.Size(10, 13)
        Me.lblA8.TabIndex = 15
        Me.lblA8.Text = "-"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(294, 22)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(29, 12)
        Me.Label13.TabIndex = 10
        Me.Label13.Text = "RAdd"
        '
        'lblA1
        '
        Me.lblA1.AutoSize = True
        Me.lblA1.Location = New System.Drawing.Point(120, 1)
        Me.lblA1.Name = "lblA1"
        Me.lblA1.Size = New System.Drawing.Size(10, 13)
        Me.lblA1.TabIndex = 4
        Me.lblA1.Text = "-"
        '
        'lblA2
        '
        Me.lblA2.AutoSize = True
        Me.lblA2.Location = New System.Drawing.Point(120, 22)
        Me.lblA2.Name = "lblA2"
        Me.lblA2.Size = New System.Drawing.Size(10, 13)
        Me.lblA2.TabIndex = 7
        Me.lblA2.Text = "-"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 1)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "BG1,2:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "BG3,4:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, 43)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 12)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "FST,FC,FC2:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 64)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Card,Count:"
        '
        'lblA3
        '
        Me.lblA3.AutoSize = True
        Me.lblA3.Location = New System.Drawing.Point(120, 43)
        Me.lblA3.Name = "lblA3"
        Me.lblA3.Size = New System.Drawing.Size(10, 13)
        Me.lblA3.TabIndex = 5
        Me.lblA3.Text = "-"
        '
        'lblA4
        '
        Me.lblA4.AutoSize = True
        Me.lblA4.Location = New System.Drawing.Point(120, 64)
        Me.lblA4.Name = "lblA4"
        Me.lblA4.Size = New System.Drawing.Size(10, 13)
        Me.lblA4.TabIndex = 6
        Me.lblA4.Text = "-"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(294, 43)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(37, 12)
        Me.Label14.TabIndex = 11
        Me.Label14.Text = "224Add"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(294, 64)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(37, 12)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "217Add"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(294, 1)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(61, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "AddChk/Q:"
        '
        'LblStaIO
        '
        Me.LblStaIO.AutoSize = True
        Me.LblStaIO.Location = New System.Drawing.Point(120, 85)
        Me.LblStaIO.Name = "LblStaIO"
        Me.LblStaIO.Size = New System.Drawing.Size(10, 13)
        Me.LblStaIO.TabIndex = 16
        Me.LblStaIO.Text = "-"
        '
        'lblA9
        '
        Me.lblA9.AutoSize = True
        Me.lblA9.Location = New System.Drawing.Point(410, 85)
        Me.lblA9.Name = "lblA9"
        Me.lblA9.Size = New System.Drawing.Size(10, 13)
        Me.lblA9.TabIndex = 17
        Me.lblA9.Text = "-"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(294, 85)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(64, 12)
        Me.Label15.TabIndex = 19
        Me.Label15.Text = "MKey/strbGo:"
        '
        'StatusStrip6
        '
        Me.StatusStrip6.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TstaTCPSignal, Me.T1, Me.T2})
        Me.StatusStrip6.Location = New System.Drawing.Point(0, 720)
        Me.StatusStrip6.Name = "StatusStrip6"
        Me.StatusStrip6.Size = New System.Drawing.Size(584, 22)
        Me.StatusStrip6.TabIndex = 131
        Me.StatusStrip6.Text = "StatusStrip6"
        '
        'TstaTCPSignal
        '
        Me.TstaTCPSignal.Name = "TstaTCPSignal"
        Me.TstaTCPSignal.Size = New System.Drawing.Size(60, 17)
        Me.TstaTCPSignal.Text = "lblReceive"
        '
        'T1
        '
        Me.T1.Name = "T1"
        Me.T1.Size = New System.Drawing.Size(20, 17)
        Me.T1.Text = "T1"
        '
        'T2
        '
        Me.T2.Name = "T2"
        Me.T2.Size = New System.Drawing.Size(20, 17)
        Me.T2.Text = "T2"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblCommontext, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 698)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(584, 22)
        Me.StatusStrip1.TabIndex = 132
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lblCommontext
        '
        Me.lblCommontext.Name = "lblCommontext"
        Me.lblCommontext.Size = New System.Drawing.Size(90, 17)
        Me.lblCommontext.Text = "lblCommontext"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(20, 17)
        Me.ToolStripStatusLabel2.Text = "T1"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(20, 17)
        Me.ToolStripStatusLabel3.Text = "T2"
        '
        'BackgroundWorker1
        '
        '
        'BackgroundWorker2
        '
        '
        'BackgroundWorker4
        '
        '
        'BackgroundWorker5
        '
        '
        'BackgroundWorker6
        '
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 500
        '
        'frmMain2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(584, 742)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.StatusStrip6)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "frmMain2"
        Me.Text = " "
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer4.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.SplitContainer5.Panel1.ResumeLayout(False)
        Me.SplitContainer5.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer5.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.Menu1.ResumeLayout(False)
        Me.Menu1.PerformLayout()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.TableLayoutPanel5.PerformLayout()
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer3.ResumeLayout(False)
        Me.SplitContainer8.Panel1.ResumeLayout(False)
        Me.SplitContainer8.Panel2.ResumeLayout(False)
        Me.SplitContainer8.Panel2.PerformLayout()
        CType(Me.SplitContainer8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer8.ResumeLayout(False)
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.TableLayoutPanel7.ResumeLayout(False)
        Me.TableLayoutPanel8.ResumeLayout(False)
        Me.SplitContainer6.Panel1.ResumeLayout(False)
        Me.SplitContainer6.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer6.ResumeLayout(False)
        Me.SplitContainer7.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer7.ResumeLayout(False)
        Me.TableLayoutPanel9.ResumeLayout(False)
        Me.TableLayoutPanel10.ResumeLayout(False)
        Me.TableLayoutPanel10.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.StatusStrip6.ResumeLayout(False)
        Me.StatusStrip6.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents SplitContainer3 As SplitContainer
    Friend WithEvents StatusStrip6 As StatusStrip
    Friend WithEvents TstaTCPSignal As ToolStripStatusLabel
    Friend WithEvents T1 As ToolStripStatusLabel
    Friend WithEvents T2 As ToolStripStatusLabel
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents lblCommontext As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents lblA5 As Label
    Friend WithEvents lblA6 As Label
    Friend WithEvents lblA7 As Label
    Friend WithEvents lblA8 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lblA1 As Label
    Friend WithEvents lblA2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblA3 As Label
    Friend WithEvents lblA4 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents lblIO01 As Label
    Friend WithEvents lblIO02 As Label
    Friend WithEvents SplitContainer4 As SplitContainer
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents SplitContainer5 As SplitContainer
    Friend WithEvents Menu1 As MenuStrip
    Friend WithEvents FileTool As ToolStripMenuItem
    Friend WithEvents LoadConfig As ToolStripMenuItem
    Friend WithEvents SaveConfig As ToolStripMenuItem
    Friend WithEvents Tcboselect As ToolStripComboBox
    Friend WithEvents cboComPort As ToolStripComboBox
    Friend WithEvents cboBaudrate As ToolStripComboBox
    Friend WithEvents cboDataBits As ToolStripComboBox
    Friend WithEvents cboParity As ToolStripComboBox
    Friend WithEvents cboStopbits As ToolStripComboBox
    Friend WithEvents cboDelay As ToolStripComboBox
    Friend WithEvents cboThreshold As ToolStripComboBox
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ExitTool As ToolStripMenuItem
    Friend WithEvents OptionsTool As ToolStripMenuItem
    Friend WithEvents ReceiveboxFontToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LargeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MediumToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SmallToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenFormToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnSettime As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents ResetTimeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DelayFinalSendToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DelayBeforeResendToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As ToolStripMenuItem
    Friend WithEvents ResetValueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResetDataToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents btnConnect As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents lblRxCnt As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents status0 As Label
    Friend WithEvents lblGetport As Label
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents Label8 As Label
    Friend WithEvents txtstatus1 As Label
    Friend WithEvents lblGetportSend As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents lblTxCntSend As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents btnConnectSend As Button
    Friend WithEvents Label21 As Label
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents Label22 As Label
    Friend WithEvents txtstatus2 As Label
    Friend WithEvents lblGetportIO As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents lblRxCntIO As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents btnConnectIO As Button
    Friend WithEvents Label28 As Label
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents Label35 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents TstrCycleCount As Label
    Friend WithEvents lblIO03 As Label
    Friend WithEvents tstrCard As Label
    Friend WithEvents TstrCell As Label
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel7 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel8 As TableLayoutPanel
    Friend WithEvents SplitContainer6 As SplitContainer
    Friend WithEvents SplitContainer7 As SplitContainer
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents Button3 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label19 As Label
    Friend WithEvents ListInQueue1 As ListBox
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker3 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker4 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker5 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker6 As System.ComponentModel.BackgroundWorker
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents LblStaIO As Label
    Friend WithEvents lblA9 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Label9 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents BackgroundWorker7 As System.ComponentModel.BackgroundWorker
    Friend WithEvents SplitContainer8 As SplitContainer
    Friend WithEvents Label18 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents TableLayoutPanel10 As TableLayoutPanel
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents lbout As ListBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents SetUpAGVToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SetUp0401ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SetUp0401BordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SetUp0402ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SetUp03ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StartCMD01ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StopCMD02ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents SetAGVNOToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CheckBox2 As CheckBox
End Class
