﻿Imports System.IO
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json
Imports System.Collections.ObjectModel
Imports System.Text
Public Class ReadPCsetting
    Public dicaddRCV As New Dictionary(Of String, String)
    Dim path As String
    Dim append As Boolean
    Dim nameList As New List(Of myName)
    Dim name As New myName()
    Public Class myName
        Public Property Name() As String
            Get
                Return m_Name
            End Get
            Set(ByVal value As String)
                m_Name = value
            End Set
        End Property
        Private m_Name As String
        Public Property Surname() As String
            Get
                Return m_Surname
            End Get
            Set(ByVal value As String)
                m_Surname = value
            End Set
        End Property
        Private m_Surname As String
    End Class
    Public Sub New(ByVal path As String, ByVal append As Boolean)
        Me.path = path
        Me.append = append
    End Sub

    Public Sub insert(ByVal tName As String, ByVal ADD As String)
        name.Name = tName
        name.Surname = ADD
        nameList.Add(name)
    End Sub
    Public Sub Save()
        Dim str As New MemoryStream()
        Dim ser As New DataContractJsonSerializer(nameList.GetType())
        ser.WriteObject(str, nameList)

        str.Position = 0
        Dim sr As New StreamReader(str)

        Dim sw As StreamWriter = File.AppendText(path & ".json")
        WriteText(sr.ReadToEnd(), sw)
        sw.Close()
    End Sub


    Public Sub WriteText(ByVal message As String, ByVal tw As TextWriter)
        tw.WriteLine(message)
    End Sub
#Region "Read File Json"
    Public Class readmyName
        Public Property LineNo() As String
            Get
                Return m_LineNo
            End Get
            Set(ByVal value As String)
                m_LineNo = value
            End Set
        End Property
        Private m_LineNo As String
        Public Property addressRCV() As String
            Get
                Return m_addressRCV
            End Get
            Set(ByVal value As String)
                m_addressRCV = value
            End Set
        End Property
        Private m_addressRCV As String
    End Class
    Public Sub read()
        Dim strJSON As String = File.ReadAllText("D:/IprojectDB/Setting/PC_Setting.json")
        Dim ms As New MemoryStream(Encoding.UTF8.GetBytes(strJSON))
        Dim list2 As New ObservableCollection(Of readmyName)
        Dim serializer As New DataContractJsonSerializer(GetType(ObservableCollection(Of readmyName)))
        list2 = DirectCast(serializer.ReadObject(ms), ObservableCollection(Of readmyName))
        dicaddRCV.Clear()
        For Each name As readmyName In list2
            dicaddRCV.Add(name.LineNo.ToString, name.addressRCV.ToString)
        Next
    End Sub


    Public Shared Function ReadToObject(ByVal json As String) As readmyName
        Dim deserializedMember As New readmyName()
        Dim ms As New MemoryStream(Encoding.UTF8.GetBytes(json))
        Dim ser As New DataContractJsonSerializer(deserializedMember.GetType())
        deserializedMember = TryCast(ser.ReadObject(ms), readmyName)
        ms.Close()
        Return deserializedMember
    End Function
#End Region

End Class
