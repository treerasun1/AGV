﻿Imports System.Globalization
Public Class Reconvert
    Shared Function convert(ByVal str As String, ByVal Cha As String) As Byte()
        Dim data() As Byte = Nothing
        Dim s() As String = str.Split(New String() {Cha}, StringSplitOptions.RemoveEmptyEntries)
        data = New Byte(s.Length - 1) {}
        For i As Integer = 0 To data.Length - 1
            If Not Byte.TryParse(s(i), NumberStyles.HexNumber, CultureInfo.CurrentCulture, data(i)) Then
                data(i) = 255
                MsgBox("conversion failed!", MsgBoxStyle.Information)
                '  FormatAdd("## ## ## ##", s(i))
            End If
        Next
        Return data
    End Function
    Shared Function FormatAdd(format As String, arg As String) As String 'format=data ,FormatInt("#,##.##",x)
        Dim ArgString As String = arg.ToString
        Dim Result As String = ""
        Dim FormatIndex As Integer = 0
        For i As Integer = 0 To format.Length - 1
            If format.Substring(i, 1) = "#" Then
                Result = Result + ArgString.Substring(FormatIndex, 1)
                FormatIndex = FormatIndex + 1
            Else
                Result = Result + format.Substring(i, 1)
            End If
        Next

        Return Result
    End Function

End Class
