﻿Imports System.IO

Public Class ComConfigure
    '{"COM1", "9600", "8", "None", "One", "1", "1"}
    Public FileName As String = "Common"
    Public RFIDCARD As String = "210"
    Public RFIDCARD_CANCEL As String = "211"
    Public RFIDCARD_CANCEL2 As String = "212"

    Public TimeOutFlagIO As String = "15"
    Public SendCount As String = "15"

    Public MyIPHost As String = "127.0.0.1"
    Public MyPortHost As String = "5000"

    Public MyIPHost2 As String = "127.0.0.1"
    Public MyPortHost2 As String = "2056"

    Public cPortSend As String = "COM1"
    Public cBaudSend As String = "9600"
    Public cDataSend As String = "8"
    Public cParitySend As String = "None"
    Public cStopSend As String = "One"
    Public cDelaySend As String = "1"
    Public cThresholdSend As String = "1"

    Public cPortRCV As String = "COM1"
    Public cBaudRCV As String = "9600"
    Public cDataRCV As String = "8"
    Public cParityRCV As String = "None"
    Public cStopRCV As String = "One"
    Public cDelayRCV As String = "1"
    Public cThresholdRCV As String = "1"

    Public CmdRouteCell1 As String = "1"
    Public CmdTCPCell1 As String = "C3-1"
    Public ListBoxCell1 As String = "LIST1"
    Public RemoteIPCell1 As String = "127.0.0.1"
    Public RemotePortCell1 As String = "5001"

    Public CmdRouteCell2 As String = "2"
    Public CmdTCPCell2 As String = "C3-2"
    Public ListBoxCell2 As String = "LIST2"
    Public RemoteIPCell2 As String = "127.0.0.1"
    Public RemotePortCell2 As String = "5002"

    Public CmdRouteCell3 As String = "3"
    Public CmdTCPCell3 As String = "C3-3"
    Public ListBoxCell3 As String = "LIST3"
    Public RemoteIPCell3 As String = "127.0.0.1"
    Public RemotePortCell3 As String = "5003"



    Public path As String = "D:\IprojectDB\setting\TCPChat"
    Private file_name As String = path & FileName & ".conf"
    Public Sub New()
        ReadConfig(path & FileName & ".conf")
    End Sub
    Public Sub CreateConfig(ByVal Filename As String)
        '   Filename = path & Filename & ".conf"
        Dim file As StreamWriter = New StreamWriter(Filename)
        file.WriteLine("Filename=" & Filename)

        file.WriteLine("RFIDCARD=" & RFIDCARD)
        file.WriteLine("RFIDCARD_CANCEL=" & RFIDCARD_CANCEL)
        file.WriteLine("RFIDCARD_CANCEL2=" & RFIDCARD_CANCEL2)

        file.WriteLine("TimeOutFlagIO=" & TimeOutFlagIO)
        file.WriteLine("SendCount=" & SendCount)

        file.WriteLine("MyIPHost=" & MyIPHost)
        file.WriteLine("MyPortHost=" & MyPortHost)

        file.WriteLine("MyIPHost2=" & MyIPHost2)
        file.WriteLine("MyPortHost2=" & MyPortHost2)

        file.WriteLine("PortNameSend=" & cPortSend)
        file.WriteLine("BaudrateSend=" & cBaudSend)
        file.WriteLine("DataSend=" & cDataSend)
        file.WriteLine("ParitySend=" & cParitySend)
        file.WriteLine("StopSend=" & cStopSend)
        file.WriteLine("DelaySend=" & cDelaySend)
        file.WriteLine("ThresholdSend=" & cThresholdSend)

        file.WriteLine("PortNameRCV=" & cPortRCV)
        file.WriteLine("BaudrateRCV=" & cBaudRCV)
        file.WriteLine("DataRCV=" & cDataRCV)
        file.WriteLine("ParityRCV=" & cParityRCV)
        file.WriteLine("StopRCV=" & cStopRCV)
        file.WriteLine("DelayRCV=" & cDelayRCV)
        file.WriteLine("ThresholdRCV=" & cThresholdRCV)

        file.WriteLine("CmdRouteCell1=" & CmdRouteCell1)
        file.WriteLine("CmdTCPCell1=" & CmdTCPCell1)
        file.WriteLine("ListBoxCell1=" & ListBoxCell1)
        file.WriteLine("RemoteIPCell1=" & RemoteIPCell1)
        file.WriteLine("RemotePortCell1=" & RemotePortCell1)

        file.WriteLine("CmdRouteCell2=" & CmdRouteCell2)
        file.WriteLine("CmdTCPCell2=" & CmdTCPCell2)
        file.WriteLine("ListBoxCell2=" & ListBoxCell2)
        file.WriteLine("RemoteIPCell2=" & RemoteIPCell2)
        file.WriteLine("RemotePortCell2=" & RemotePortCell2)

        file.WriteLine("CmdRouteCell3=" & CmdRouteCell3)
        file.WriteLine("CmdTCPCell3=" & CmdTCPCell3)
        file.WriteLine("ListBoxCell3=" & ListBoxCell3)
        file.WriteLine("RemoteIPCell3=" & RemoteIPCell3)
        file.WriteLine("RemotePortCell3=" & RemotePortCell3)


        file.Close()
    End Sub

    Public Sub ReadConfig(ByVal Filename As String)
        'Dim File As StreamReader
        'Dim line As String
        Try
            For Each line As String In File.ReadLines(Filename)
                Dim s() As String = line.Split("="c)
                If s(0) = "File name" Then
                    Filename = s(1)
                ElseIf s(0) = "RFIDCARD" Then
                    RFIDCARD = s(1)
                ElseIf s(0) = "RFIDCARD_CANCEL" Then
                    RFIDCARD_CANCEL = s(1)
                ElseIf s(0) = "RFIDCARD_CANCEL2" Then
                    RFIDCARD_CANCEL2 = s(1)

                ElseIf s(0) = "TimeOutFlagIO" Then
                    TimeOutFlagIO = s(1)
                ElseIf s(0) = "SendCount" Then
                    SendCount = s(1)

                ElseIf s(0) = "MyIPHost" Then
                    MyIPHost = s(1)
                ElseIf s(0) = "MyPortHost" Then
                    MyPortHost = s(1)
                ElseIf s(0) = "MyIPHost2" Then
                    MyIPHost2 = s(1)
                ElseIf s(0) = "MyPortHost2" Then
                    MyPortHost2 = s(1)

                ElseIf s(0) = "PortNameSend" Then
                    cPortSend = s(1)
                ElseIf s(0) = "BaudrateSend" Then
                    cBaudSend = s(1)
                ElseIf s(0) = "DataSend" Then
                    cDataSend = s(1)
                ElseIf s(0) = "ParitySend" Then
                    cParitySend = s(1)
                ElseIf s(0) = "StopSend" Then
                    cStopSend = s(1)
                ElseIf s(0) = "DelaySend" Then
                    cDelaySend = s(1)
                ElseIf s(0) = "ThresholdSend" Then
                    cThresholdSend = s(1)

                ElseIf s(0) = "PortNameRCV" Then
                    cPortRCV = s(1)
                ElseIf s(0) = "BaudrateRCV" Then
                    cBaudRCV = s(1)
                ElseIf s(0) = "DataRCV" Then
                    cDataRCV = s(1)
                ElseIf s(0) = "ParityRCV" Then
                    cParityRCV = s(1)
                ElseIf s(0) = "StopRCV" Then
                    cStopRCV = s(1)
                ElseIf s(0) = "DelayRCV" Then
                    cDelayRCV = s(1)
                ElseIf s(0) = "ThresholdRCV" Then
                    cThresholdRCV = s(1)

                ElseIf s(0) = "CmdRouteCell1" Then
                    CmdRouteCell1 = s(1)
                ElseIf s(0) = "CmdTCPCell1" Then
                    CmdTCPCell1 = s(1)
                ElseIf s(0) = "ListBoxCell1" Then
                    ListBoxCell1 = s(1)
                ElseIf s(0) = "RemoteIPCell1" Then
                    RemoteIPCell1 = s(1)
                ElseIf s(0) = "RemotePortCell1" Then
                    RemotePortCell1 = s(1)

                ElseIf s(0) = "CmdRouteCell2" Then
                    CmdRouteCell2 = s(1)
                ElseIf s(0) = "CmdTCPCell2" Then
                    CmdTCPCell2 = s(1)
                ElseIf s(0) = "ListBoxCell2" Then
                    ListBoxCell2 = s(1)
                ElseIf s(0) = "RemoteIPCell2" Then
                    RemoteIPCell2 = s(1)
                ElseIf s(0) = "RemotePortCell2" Then
                    RemotePortCell2 = s(1)

                ElseIf s(0) = "CmdRouteCell3" Then
                    CmdRouteCell3 = s(1)
                ElseIf s(0) = "CmdTCPCell3" Then
                    CmdTCPCell3 = s(1)
                ElseIf s(0) = "ListBoxCell3" Then
                    ListBoxCell3 = s(1)
                ElseIf s(0) = "RemoteIPCell3" Then
                    RemoteIPCell3 = s(1)
                ElseIf s(0) = "RemotePortCell3" Then
                    RemotePortCell3 = s(1)

                End If

            Next line

        Catch e As FileNotFoundException

            CreateConfig(file_name)
            '//Console.WriteLine("Error: File not found.");

        Finally

        End Try
    End Sub
End Class
