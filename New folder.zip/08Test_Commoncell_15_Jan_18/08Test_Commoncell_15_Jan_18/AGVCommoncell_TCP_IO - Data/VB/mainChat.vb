﻿Option Strict On
Option Infer On

Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.IO
Imports System.Threading
Imports System.Net.NetworkInformation
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Reflection.TargetInvocationException
Imports System.Reflection
''' <summary>
''' TCP Chat . 
''' Test Common Model D42   
''' </summary>
''' <remarks></remarks>
Public Class mainChat
    Dim P() As Process
    Private WithEvents myChat As New TCPChat
    Private myAdapterName, myPhysicalAddress, MessageKEY, myGateway, myDNS, strHostName As String
    Private addr() As IPAddress
    Dim flagsequence1 As Boolean = False
    Dim flagsequence2 As Boolean = False
    Dim flagsequence3 As Boolean = False
    Dim flagNowSend As Boolean = False
    Public Shared socketAGVControl As New AGVTcpControl()
    Dim FlagTCP As Integer
    Dim flagcancel2 As Boolean = False
    Dim ADDGo() As Byte
    Dim strbGo As String = Nothing
    Dim strbGo2 As String = Nothing
    Dim getaddgo As String = Nothing
    Dim responsefromAGV As String = Nothing
    'Rs232 
    Private WithEvents _rs232Send As New RS232
    Private charsInlineSend As Integer = 80  ' def n start
    Private isConnectedSend As Boolean
    Private RXcountSend, TXcountSend As Integer
    Private comparamsSend() As String = RS232.DefaultParams
    Private bufferSend() As Byte

    Private WithEvents _rs232 As New RS232
    Private charsInline As Integer = 80  ' def n start
    Private isConnected As Boolean
    Private RXcount, TXcount As Integer
    Private comparams() As String = RS232.DefaultParams
    Private buffer() As Byte

    'Log File
    Dim logE As LogFile = New LogFile("D:/IprojectDB/Common_Log/Err_log", True)
    Dim log1 As LogFile = New LogFile("D:/IprojectDB/log_start_control", True)
    'Read From config File
    Private Readconfig As ComConfigure = New ComConfigure()
    'queue
    Dim Queue_signal As Integer
    Public obj As Queue(Of String) = New Queue(Of String)()
    Public obj2 As Queue(Of String) = New Queue(Of String)()
    Public objcell2 As Queue(Of String) = New Queue(Of String)()
    Public objcell3 As Queue(Of String) = New Queue(Of String)()
    'dictionary
    Dim DicCheckAddToQueue As Dictionary(Of String, String) = New Dictionary(Of String, String)

    Dim strtemp, show_result, Show_ADD, receiveadd, straddcheck, getcell, getadd, getstatus, getCradNo As String
    'function compare cell
    Dim C1 As Integer = obj2.Count
    Dim C2 As Integer = objcell2.Count
    Dim C3 As Integer = objcell3.Count

    Dim totaltimelastedC1 As String = "2"
    Dim totaltimelastedC2 As String = "4"
    Dim totaltimelastedC3 As String = "6"
    Dim timenow, stamptimeC1, stamptimeC2, stamptimeC3 As Date
    Dim GetcomparetimeC1, GetcomparetimeC2, GetcomparetimeC3 As TimeSpan
    Dim getCycletimeC1, getCycletimeC2, getCycletimeC3 As String
    Dim ResultDelaytimeC1, ResultDelaytimeC2, ResultDelaytimeC3 As Integer

    'readJSON setting
    Private ReadPCsetting2 As ReadPCsetting = New ReadPCsetting("D:\\IprojectDB\Setting\PC_Setting.json", True)
    Private ReadAGVSetting2 As ReadAGVSetting = New ReadAGVSetting("D:\\IprojectDB\Setting\AGV_Setting.json", True)
    Dim COUNT_SEND As Integer = 10
    Dim Response As String
    Dim Requestsendline As Byte
    Dim Response_Success, DequeueIndex As String

    Dim getaddsend, getcellsend As String
    'IO Variable
    Dim flagIOC1, flagIOC2, flagIOC3 As Boolean
    Dim timenowIOC1, timenowIOC2, timenowIOC3 As Date
    Dim stamptimeIOC1, stamptimeIOC2, stamptimeIOC3 As Date
    Dim GetcomparetimeIOC1, GetcomparetimeIOC2, GetcomparetimeIOC3 As TimeSpan
    Dim totaltimelastedIOC1 As String
    Dim totaltimelastedIOC2 As String
    Dim totaltimelastedIOC3 As String

    Dim IOVARC1, IOVARC2, IOVARC3 As String

#Region "Sub New"
    Public Sub New()
        ' This call is required by the designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call.
        'AddHandler BackgroundWorker1.DoWork, AddressOf BackgroundWorker1_DoWork
        'AddHanv  dler BackgroundWorker1.ProgressChanged, AddressOf BackgroundWorker1_ProgressChanged
        'AddHandler BackgroundWorker1.RunWorkerCompleted, AddressOf BackgroundWorker1_RunWorkerCompleted
        BackgroundWorker1.WorkerReportsProgress = True
        BackgroundWorker1.WorkerSupportsCancellation = True
        BackgroundWorker2.WorkerReportsProgress = True
        BackgroundWorker2.WorkerSupportsCancellation = True
        BackgroundWorker3.WorkerReportsProgress = True
        BackgroundWorker3.WorkerSupportsCancellation = True
        BackgroundWorker4.WorkerReportsProgress = True
        BackgroundWorker4.WorkerSupportsCancellation = True
        BackgroundWorker5.WorkerReportsProgress = True
        BackgroundWorker5.WorkerSupportsCancellation = True

    End Sub
#End Region
#Region "form"

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CheckProcess()
        Update_label(Now.ToShortDateString & " #" & Now.ToShortTimeString, Label25, Color.Black, Color.DeepSkyBlue)
        ReadPCsetting2.read()
        ReadAGVSetting2.read()
        ' Check data from TCP/IP ''''''''''''''''''''
        If BackgroundWorker5.IsBusy <> True Then
            BackgroundWorker5.RunWorkerAsync()
        End If
        InitialAGVStartControlThread()
        ' '''''''''''''''''''''''''''''''''''''''''''
        If _rs232Send.IsCheckConnect = False Then
            Me.comparamsSend(RS232.cP.cPort) = Readconfig.cPortSend
            Me.comparamsSend(RS232.cP.cBaud) = Readconfig.cBaudSend
            Me.comparamsSend(RS232.cP.cData) = Readconfig.cDataSend
            Me.comparamsSend(RS232.cP.cParity) = Readconfig.cParitySend
            Me.comparamsSend(RS232.cP.cStop) = Readconfig.cStopSend
            Me.comparamsSend(RS232.cP.cDelay) = Readconfig.cDelaySend
            Me.comparamsSend(RS232.cP.cThreshold) = Readconfig.cThresholdSend
            _rs232Send.connect(comparamsSend)
        End If
        If _rs232.IsCheckConnect = False Then
            Me.comparams(RS232.cP.cPort) = Readconfig.cPortRCV
            Me.comparams(RS232.cP.cBaud) = Readconfig.cBaudRCV
            Me.comparams(RS232.cP.cData) = Readconfig.cDataRCV
            Me.comparams(RS232.cP.cParity) = Readconfig.cParityRCV
            Me.comparams(RS232.cP.cStop) = Readconfig.cStopRCV
            Me.comparams(RS232.cP.cDelay) = Readconfig.cDelayRCV
            Me.comparams(RS232.cP.cThreshold) = Readconfig.cThresholdRCV
            _rs232.connect(comparams)
        End If
        strHostName = Dns.GetHostName()
        Dim ipEntry As IPHostEntry = Dns.GetHostEntry(strHostName)
        addr = ipEntry.AddressList
        Dim i As Integer
        For i = 0 To addr.Length - 1
            If addr(i).AddressFamily = AddressFamily.InterNetwork Then
                StatusLabel_adapter.Text = "host " & strHostName &
                                           String.Format(" IP: {0}", addr(i).ToString)
                Exit For
            End If
        Next
        ' *******************'Use Remote Port to send data*****************************************
        myChat.connect(Readconfig.MyIPHost, CInt(Readconfig.MyPortHost))
        ' *****************************************************************************************

        '' InputBox for start program''''''''''''''''''''
        'Dim message, title, defautValue As String
        'Dim myValue As Object
        'message = "Enter a value cell No.For Start Program "
        'title = "Set up cell use"
        'defautValue = "1"
        'myValue = InputBox(message, title, defautValue, 500, 350)
        'If myValue Is "" Then myValue = defautValue
        ''*''''''''''''''''''''''''''''''''''''''''''''
        'Requestsendline = CByte(myValue)

        Update_label(Readconfig.CmdRouteCell1, lbltimeC1, Color.Transparent, Color.Blue)
        Update_label(Readconfig.CmdTCPCell1, Label7, Color.Transparent, Color.Black)
        Update_label(Readconfig.CmdRouteCell2, lbltimeC2, Color.Transparent, Color.Blue)
        Update_label(Readconfig.CmdTCPCell2, Label10, Color.Transparent, Color.Black)
        Update_label(Readconfig.CmdRouteCell3, lbltimeC3, Color.Transparent, Color.Blue)
        Update_label(Readconfig.CmdTCPCell3, Label12, Color.Transparent, Color.Black)
        C1 = obj2.Count
        C2 = objcell2.Count
        C3 = objcell3.Count
        stamptimeC1 = Now
        stamptimeC2 = Now
        stamptimeC3 = Now

        Update_label(timenow.ToShortTimeString, lbltimeC3, Color.Transparent, Color.DeepSkyBlue)
        Update_label(C1.ToString, lblC1, Color.Transparent, Color.DeepSkyBlue)
        Update_label(C2.ToString, lblC2, Color.Transparent, Color.DeepSkyBlue)
        Update_label(C3.ToString, lblC3, Color.Transparent, Color.DeepSkyBlue)
        Update_label(totaltimelastedC1, lblCOC1, Color.Transparent, Color.DeepSkyBlue)
        Update_label(totaltimelastedC2, lblCOC2, Color.Transparent, Color.DeepSkyBlue)
        Update_label(totaltimelastedC3, lblCOC3, Color.Transparent, Color.DeepSkyBlue)
        Update_label(flagIOC1.ToString, Label15, Color.Transparent, Color.DeepSkyBlue)
        Update_label(flagIOC1.ToString, Label18, Color.Transparent, Color.DeepSkyBlue)
        Update_label(flagIOC1.ToString, Label19, Color.Transparent, Color.DeepSkyBlue)
        Update_label(stamptimeC1.ToShortTimeString, lbltimeC1, Color.Transparent, Color.DeepSkyBlue)
        Update_label(stamptimeC2.ToShortTimeString, lbltimeC2, Color.Transparent, Color.DeepSkyBlue)
        '  Update_label(stamptimeC1.ToShortTimeString, lbltimeC1, Color.Transparent, Color.DeepSkyBlue)
        Update_label(DequeueIndex & "/" & Requestsendline.ToString(), lbltimeC3, Color.Transparent, Color.DeepSkyBlue)
        UpdateStatus("", ListBox2)
        IOVARC1 = LblIO1.Text
        IOVARC2 = LblIO2.Text
        IOVARC3 = LblIO3.Text
    End Sub
    ' 
    ' clear socket connection
    '
    Private Sub mainChat_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        'myChat.disconnect()
    End Sub
    '
    '  input from Textbox
    '
    Private Sub tbinKD(ByVal sender As Object, ByVal e As KeyEventArgs)
        'If e.KeyCode = Keys.Enter Then
        '    With CType(sender, TextBox)
        '        If .Text.Length > 0 Then
        '            StatusLabel_send.Image = My.Resources.ledCornerGray
        '            '    myChat.SendData(.Text, tbx_remoteIP.Text, CInt(tbx_remotePort.Text))
        '            txtOutSend(.Text)
        '            .Text = String.Empty
        '        End If
        '    End With
        'End If
    End Sub
    '
    ' output to listbox
    '
    Public Sub txtOut(ByVal txt As String) Handles myChat.Datareceived
        Try
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim addFixsend(3) As Byte

            Dim strdata2 As String = Nothing
            Dim strdata22 As String = Nothing

            If txt <> "200" Then
                UpdateStatus("< " & txt, ListBox3)
                '   ListBox1.Items.Add("< " & txt)
                Dim delimiter() As String = {"|"}
                Dim resArray() As String = txt.Split(delimiter, StringSplitOptions.None)
                If resArray.Length = 4 Then
                    getcell = resArray(0)
                    getadd = resArray(1)
                    getstatus = resArray(2)
                    getCradNo = resArray(3)
                    Select Case getcell
                        Case "IO"
                            Select Case getadd
                                Case Readconfig.CmdTCPCell1
                                    IOVARC1 = getstatus
                                    If getstatus = "KITTING OK" Then
                                        Update_label(IOVARC1, LblIO1, Color.Green, Color.WhiteSmoke)
                                    Else
                                        Update_label(IOVARC1, LblIO1, Color.Red, Color.WhiteSmoke)
                                    End If
                                Case Readconfig.CmdTCPCell2
                                    IOVARC2 = getstatus
                                    If getstatus = "KITTING OK" Then
                                        Update_label(IOVARC2, LblIO2, Color.Green, Color.WhiteSmoke)
                                    Else
                                        Update_label(IOVARC2, LblIO2, Color.Red, Color.WhiteSmoke)
                                    End If
                                Case Readconfig.CmdTCPCell3
                                    IOVARC3 = getstatus
                                    If getstatus = "KITTING OK" Then
                                        Update_label(IOVARC3, LblIO3, Color.Green, Color.WhiteSmoke)
                                    Else
                                        Update_label(IOVARC3, LblIO3, Color.Red, Color.WhiteSmoke)
                                    End If
                            End Select
                    End Select
                End If
                getcell = ""
                getadd = ""
                getstatus = ""
                getCradNo = ""
                resArray(0) = ""
                resArray(1) = ""
                resArray(2) = ""
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
            System.Threading.Thread.Sleep(100)
        End Try
    End Sub


    Private Sub txtOutSend(ByVal txt As String)
        Try
            UpdateStatus("< " & txt, ListBox3)
        Catch ex As Exception
            Update_Log(ex.ToString())
            System.Threading.Thread.Sleep(100)
        End Try
    End Sub
    '
    '  senda data OK NOK    '
    'Private Sub sendataTCP(ByVal sendStatus As Boolean) Handles myChat.sendOK
    '    If sendStatus Then
    '        StatusLabel_send.Image = My.Resources.ledCornerGreen
    '    Else
    '        StatusLabel_send.Image = My.Resources.ledCornerRed
    '    End If
    'End Sub
    '
    ' receive data OK NOK
    '
    Private Sub rdataTCP(ByVal receiveStatus As Boolean) Handles myChat.recOK
        If receiveStatus Then
            'StatusLabel_receive.Image = My.Resources.ledCornerGreen
            'StatusLabel_adapter.Text = "local " & myChat.Local.ToString &
            '                           " remote" & myChat.Remote.ToString

        Else
            '  StatusLabel_receive.Image = My.Resources.ledCornerRed
        End If
    End Sub
    '
    ' connect
    '
    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Try
        '    myChat.connect(Readconfig.MyIPHost, CInt(Readconfig.MyIPHost))
        'Catch ex As Exception
        '    Update_Log(ex.ToString())
        '    System.Threading.Thread.Sleep(100)
        'End Try
    End Sub
    '
    ' connection status
    '
    'Private Sub connectionTCP(ByVal status As Boolean) Handles myChat.connection
    '    If status Then
    '        StatusLabel_adapter.Image = My.Resources.ledCornerGreen
    '        StatusLabel_receive.Image = My.Resources.ledCornerOrange
    '    Else
    '        StatusLabel_adapter.Image = My.Resources.ledCornerGray
    '        StatusLabel_receive.Image = My.Resources.ledCornerGray
    '        StatusLabel_send.Image = My.Resources.ledCornerGray
    '    End If
    'End Sub
#Region "TCP Chat Function"
    Private Sub TCPChat_Sender(ByVal TCPsender As String, ByVal TCPRemotePort As Integer)
        Try
            With CType(TCPsender, String)
                If TCPsender.Length > 0 Then
                    myChat.SendData(TCPsender, "127.0.0.1", TCPRemotePort)
                    TCPsender = ""
                End If
            End With
        Catch ex As Exception
            Update_Log(ex.ToString())
            System.Threading.Thread.Sleep(100)
        End Try
    End Sub

#End Region
    ' disconnect socketTCPChat_Sender
    Private Sub btnDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        myChat.disconnect()
    End Sub
    '
    '  clear listbox
    '
    Private Sub btn_clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_clear.Click
        Try
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim Card2(3) As Byte
            Dim res As Byte
            Dim strdata2 As String = Nothing
            Dim strb3 As String = Nothing
            Dim AGVName As String = Nothing
            Dim B As String
            If obj.Count <> 0 Then
                QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
                strb3 = Hex(addT(0)).PadLeft(2, "0"c) & Hex(addT(1)).PadLeft(2, "0"c) & Hex(addT(2)).PadLeft(2, "0"c) & Hex(addT(3)).PadLeft(2, "0"c)
                DicCheckAddToQueue.Remove(strdata2)
                QueueManage.deDequeue_AGV(obj, ListInQueue1)
                updateAGVQ(obj, ListInQueue1)
                Update_label("Waiting..", Label2, Color.Gray, Color.Blue)
                If ReadAGVSetting2.dicname.ContainsKey(strb3) Then
                    AGVName = ReadAGVSetting2.dicname.Item(strb3)
                End If
                show_detailAGV(B)
            Else
                show_detailAGV(B)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try

    End Sub
    Private Sub show_detailAGV(ByRef A As String)
        Try
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim Card2(3) As Byte
            Dim res As Byte
            Dim strdata2 As String = Nothing
            Dim strb3 As String = Nothing
            Dim AGVName As String = Nothing
            If obj.Count <> 0 Then
                QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
                strb3 = Hex(addT(0)).PadLeft(2, "0"c) & Hex(addT(1)).PadLeft(2, "0"c) & Hex(addT(2)).PadLeft(2, "0"c) & Hex(addT(3)).PadLeft(2, "0"c)
                If ReadAGVSetting2.dicname.ContainsKey(strb3) Then
                    AGVName = ReadAGVSetting2.dicname.Item(strb3)
                    A = strb3
                End If
                Update_label("NO:" & AGVName, Label2, Color.Gray, Color.Blue)
            Else
                Update_label("Wait AGV", Label2, Color.Gray, Color.Blue)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    'Public Sub RemoveAt(ByVal index As Integer)
    '    obj.Enqueue(obj.ElementAt(index))
    '    updateAGVQ(obj, ListInQueue1)
    'End Sub
#End Region
#Region "RS232"
#Region "RS232 Send Port "
    'End Serialport receive code
#Region "form events Send Port"
    Private countsend As Integer
    Private Sub sendToComSend() 'Handles cbxsendToCom.KeyDown
        Dim dataSend() As Byte = Nothing
        Me.TXcountSend += dataSend.Length
        Update_label(String.Format("{0:D6}", TXcountSend), lblTxCntSend, Nothing, Nothing)

    End Sub
    Public Sub Send_Packet_to_AGV(ByRef SerialS As RS232, ByRef addT As Byte(), ByVal CMD1 As Byte, ByVal CMD2 As Byte)
        Try
            '  Dim result As Long = BitConverter.ToUInt32(ArrCard, 0)
            '7E 00 10 10 00 00 13 A2 00 40 EA 52 B7 FF FE 00 00 01 00 09
            Dim FSUM As Integer
            '   FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + addT(4) + addT(5) + addT(6) + addT(7) + &HFF + &HFE + CMD1 + CMD2)
            FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + &H0 + &H13 + &HA2 + &H0 + &HFF + &HFE + CMD1 + CMD2)
            Dim byteArray As Byte() = BitConverter.GetBytes(FSUM)
            Dim h As Integer
            h = byteArray(0)

            Dim Packet() As Byte = {&H7E, &H0, &H10, &H10, &H0, &H0, &H13, &HA2, &H0, addT(0), addT(1), addT(2), addT(3), &HFF, &HFE, &H0, &H0, CMD1, CMD2, CByte(h)}
            If SerialS.IsCheckConnect() = True Then
                SerialS.SendData(Packet)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Public Sub Send_cmd_tOagv(ByRef SerialS As RS232, ByRef addT As Byte(), ByVal CMD1 As Byte, ByVal CMD2 As Byte, ByVal Value As Byte)
        Try
            '7E 00 10 10 00 00 13 A2 00 40 EA 52 B7 FF FE 00 00 03 52 01 09 
            Dim FSUM As Integer
            FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + &H0 + &H13 + &HA2 + &H0 + &HFF + &HFE + CMD1 + CMD2 + Value)
            Dim byteArray As Byte() = BitConverter.GetBytes(FSUM)
            Dim h As Integer
            h = byteArray(0)
            Dim Packet() As Byte = {&H7E, &H0, &H11, &H10, &H0, &H0, &H13, &HA2, &H0, addT(0), addT(1), addT(2), addT(3), &HFF, &HFE, &H0, &H0, CMD1, CMD2, Value, CByte(h)}
            If SerialS.IsCheckConnect() = True Then
                SerialS.SendData(Packet)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Public Sub Send_cmd_04(ByRef SerialS As RS232, ByRef addT As Byte(), ByVal CMD1 As Byte, ByRef addTSet As Byte()) 'Send_cmd_04(_rs232send,add(),02,addtset())
        '7E 00 14 10 00 00 13 A2 00 40 D5 1A 36 FF FE 00 00 04 02 FF FF FF FF D6
        Try
            Dim FSUM As Integer
            FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + &H0 + &H13 + &HA2 + &H0 + &HFF + &HFE + &H4 + CMD1 + addTSet(0) + addTSet(1) + addTSet(2) + addTSet(3))
            Dim byteArray As Byte() = BitConverter.GetBytes(FSUM)
            Dim h As Integer
            h = byteArray(0)

            Dim Packet() As Byte = {&H7E, &H0, &H14, &H10, &H0, &H0, &H13, &HA2, &H0, addT(0), addT(1), addT(2), addT(3), &HFF, &HFE, &H0, &H0, &H4, CMD1, addTSet(0), addTSet(1), addTSet(2), addTSet(3), CByte(h)}
            If SerialS.IsCheckConnect() = True Then
                SerialS.SendData(Packet)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Public Sub Send_cmd_04_01(ByRef SerialS As RS232, ByRef addT As Byte(), ByRef addTSet As Byte(), ByRef addUpTimm As Byte(), ByVal countsend As Byte, ByVal Delay_Flag As Byte) 'Send_cmd_04(_rs232send,add(),02,addtset())
        Try
            '7E 00 14 10 00 00 13 A2 00 40 D5 1A 36 FF FE 00 00 04 02 FF FF FF FF D6

            Dim FSUM As Integer
            FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + &H0 + &H13 + &HA2 + &H0 + &HFF + &HFE + &H4 + &H1 + addTSet(0) + addTSet(1) + addTSet(2) + addTSet(3) + addUpTimm(0) + addUpTimm(1) + addUpTimm(2) + addUpTimm(3) + countsend + Delay_Flag)
            Dim byteArray As Byte() = BitConverter.GetBytes(FSUM)
            Dim h As Integer
            h = byteArray(0)

            Dim Packet() As Byte = {&H7E, &H0, &H1A, &H10, &H0, &H0, &H13, &HA2, &H0, addT(0), addT(1), addT(2), addT(3), &HFF, &HFE, &H0, &H0, &H4, &H1, addTSet(0), addTSet(1), addTSet(2), addTSet(3), addUpTimm(0), addUpTimm(1), addUpTimm(2), addUpTimm(3), countsend, Delay_Flag, CByte(h)}
            If SerialS.IsCheckConnect() = True Then
                SerialS.SendData(Packet)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
#End Region
#Region "Com Port class events send Port"
    ''' <summary>
    '''  update boxes
    ''' </summary>
    ''' <param name="bufferSend">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdateSend(ByVal bufferSend() As Byte) Handles _rs232Send.Datareceived

        Me.RXcountSend += bufferSend.Length
        '  Me.lblRxCntSend.Text = String.Format("count: {0:D3}", RXcountSend)
        Update_label(String.Format("count: {0:D3}", RXcountSend), lblTxCntSend, Nothing, Nothing)
        Dim sSend As String = Encoding.ASCII.GetString(bufferSend, 0, bufferSend.Length)
        ' Me.rtbRX.ScrollToCaret()
        'TODO
        '  Me.rtbRX.AppendText(s) ' & vbCr)
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendataSend(ByVal sendStatusSend As Boolean) Handles _rs232Send.sendOK
        If sendStatusSend Then
            ' Me.statusTXsend.Image = My.Resources.ledGreen
            '  Update_bitmap(statusTXsend, My.Resources.ledGreen)
        Else
            ' Me.statusTXsend.Image = My.Resources.ledRed
            '  Update_bitmap(statusTXsend, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    ''' receive successfull
    ''' </summary>
    Private Sub rdataSend(ByVal receiveStatusSend As Boolean) Handles _rs232Send.recOK
        If receiveStatusSend Then

        Else

        End If
    End Sub

    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connectionSend(ByVal statusSend As Boolean) Handles _rs232Send.connection
        If statusSend Then
            Update_button("disconnect", btnConnectSend, Color.ForestGreen, Color.Black)
            Update_label("none", txtstatus1, Color.ForestGreen, Color.Blue)
            Me.sLabelSend(comparamsSend)
            Me.isConnectedSend = True
        Else
            Update_button("*connect*", btnConnectSend, Color.ForestGreen, Color.Black)
            Update_label("Connect", txtstatus1, Color.Red, Color.WhiteSmoke)
            Me.isConnectedSend = False
        End If
    End Sub

    Private Sub getmessageSend(ByVal msgSend As String) Handles _rs232Send.errormsg

        MsgBox(msgSend)
    End Sub

#End Region
#Region "utilities  Send Port"
    Private Sub appendBytesSend(ByVal rb As RichTextBox, ByRef dataSend() As Byte, ByRef currentLenghtSend As Integer, ByVal showHexAndAsciiSend As Boolean)
        Dim HexStringSend As String = String.Empty
        Dim CharStringSend As String = String.Empty
        Dim count As Integer = 0

        For i As Integer = 0 To dataSend.Length - 1
            HexStringSend &= String.Format(" {0:X2}", dataSend(i))
            If dataSend(i) > 31 Then
                CharStringSend &= String.Format("  {0}", Chr(dataSend(i)))
            Else
                CharStringSend &= "  ."
            End If
            count += 3

        Next

    End Sub

    Private Sub sLabelSend(ByVal comparamsSend() As String)
        Update_label(Readconfig.cPortSend, lblGetportSend, Color.Transparent, Color.Black)
    End Sub


#End Region
    Private Sub btnConnectSend_Click(sender As Object, e As EventArgs) Handles btnConnectSend.Click
        Try

            If CType(sender, Button).Text = "*connect*" Then
                Me.comparamsSend(RS232.cP.cPort) = Readconfig.cPortSend
                Me.comparamsSend(RS232.cP.cBaud) = Readconfig.cBaudSend
                Me.comparamsSend(RS232.cP.cData) = Readconfig.cDataSend
                Me.comparamsSend(RS232.cP.cParity) = Readconfig.cParitySend
                Me.comparamsSend(RS232.cP.cStop) = Readconfig.cStopSend
                Me.comparamsSend(RS232.cP.cDelay) = Readconfig.cDelaySend
                Me.comparamsSend(RS232.cP.cThreshold) = Readconfig.cThresholdSend
                _rs232Send.connect(comparamsSend)
            Else
                _rs232Send.disconnect()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
    'End Serialport send code

#End Region
#Region "RS232 Receive Port"
#Region "form events Receive Port"


    Private count As Integer

    ''' <summary>
    ''' build hex string in textbox
    ''' </summary>
    Private Sub cboEnterMessage_TextUpdate(ByVal sender As System.Object,
                                           ByVal e As System.EventArgs)


        '  If Not Me.chkTxEnterHex.Checked Then Exit Sub
        Dim cb As ToolStripComboBox = CType(sender, ToolStripComboBox)
        Dim s As String = cb.Text
        count += 1
        If count = 2 Then
            cb.Text &= " "
            count = 0
        End If
        cb.SelectionStart = cb.Text.Length

    End Sub

    Private Sub sendToCom() 'Handles cbxsendToCom.KeyDown
        Dim data() As Byte = Nothing
        _rs232.SendData(data)
        Me.TXcount += data.Length
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim Card2(3) As Byte

            Dim strdata2 As String = Nothing
            Dim strb3 As String = Nothing
            Dim AGVName As String = Nothing
            QueueManage.deDequeue_AGV(obj2, lbout)
            updateAGVQ(obj2, lbout)
            C1 = obj2.Count
            Update_label(C1.ToString, lblC1, Color.Transparent, Color.Black)
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Update_label(stamptimeC1.ToShortTimeString, lbltimeC1, Color.Transparent, Color.DeepSkyBlue)
        Update_label(stamptimeC2.ToShortTimeString, lbltimeC2, Color.Transparent, Color.DeepSkyBlue)
        Update_label(totaltimelastedIOC1, LblTIOC1, Color.Transparent, Color.Black)
        Update_label(totaltimelastedIOC2, LblTIOC2, Color.Transparent, Color.Black)
        Update_label(flagIOC1.ToString, Label15, Color.Transparent, Color.Black)
        Update_label(flagIOC2.ToString, Label18, Color.Transparent, Color.Black)

        '  Update_label(stamptimeC1.ToShortTimeString, lbltimeC1, Color.Transparent, Color.DeepSkyBlue)
        Update_label(DequeueIndex & "/" & Requestsendline.ToString(), lbltimeC3, Color.Transparent, Color.DeepSkyBlue)

        'Update_label(flagsequence1 & "," & flagsequence2 & "," & flagsequence3, Label3, Color.Transparent, Color.DeepSkyBlue)
        'Update_label(timenow.ToShortTimeString, lbltimeC3, Color.Transparent, Color.DeepSkyBlue)
        Update_label(totaltimelastedC1, lblCOC1, Color.Transparent, Color.DeepSkyBlue)
        Update_label(totaltimelastedC2, lblCOC2, Color.Transparent, Color.DeepSkyBlue)
        Update_label(totaltimelastedC3, lblCOC3, Color.Transparent, Color.DeepSkyBlue)
        Update_label(flagIOC1.ToString, Label15, Color.Transparent, Color.DeepSkyBlue)
        Update_label(flagIOC2.ToString, Label18, Color.Transparent, Color.DeepSkyBlue)
        Update_label(flagIOC3.ToString, Label19, Color.Transparent, Color.DeepSkyBlue)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            DicCheckAddToQueue.Clear()
        Catch ex As Exception
            Update_Log(ex.ToString())
            System.Threading.Thread.Sleep(100)
        End Try

    End Sub

    ''' <summary>
    ''' view hex in rx box
    ''' </summary>
    Private Sub RxShowHex_CheckedChanged(ByVal sender As System.Object,
                                         ByVal e As System.EventArgs)
        '   Me.charsInline = setRuler(Me.rtbRX, Me.chkRxShowHex.Checked)
    End Sub



    ''' <summary>
    ''' view hex in tx box
    ''' </summary>
    Private Sub chkTxShowHex_CheckedChanged(ByVal sender As System.Object,
                                         ByVal e As System.EventArgs)
        '    Me.charsInline = setRuler(Me.rtbTX, Me.chkTxShowHex.Checked)
    End Sub
    Private Sub frmMain_ResizeEnd(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.ResizeEnd
        'Me.charsInline = setRuler(rtbRX, chkRxShowHex.Checked)
        'Me.charsInline = setRuler(rtbTX, chkTxShowHex.Checked)
    End Sub
#End Region
#Region "Com Port class events Receive Port"
    ''' <summary>
    '''  update boxes
    ''' </summary>
    ''' <param name="buffer">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdate(ByVal buffer() As Byte) Handles _rs232.Datareceived
        Me.RXcount += buffer.Length
        ' Me.lblRxCnt.Text = String.Format("count: {0:D3}", RXcount)
        Update_label(String.Format("{0:D3}", RXcount), lblRXCount, Nothing, Nothing)
        Dim s As String = Encoding.ASCII.GetString(buffer, 0, buffer.Length)
        ' Me.rtbRX.ScrollToCaret()
        'TODO
        '  Me.rtbRX.AppendText(s) ' & vbCr)
        appendBytes(buffer, Me.charsInline, False)
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendata(ByVal sendStatus As Boolean) Handles _rs232.sendOK
        If sendStatus Then
            '  Me.statusTX.Image = My.Resources.ledGreen
            '  Update_bitmap(statusTX, My.Resources.ledGreen)
        Else
            '   Me.statusTX.Image = My.Resources.ledRed
            '   Update_bitmap(statusTX, My.Resources.ledRed)
        End If
    End Sub

    Private Sub btnCLRF1_Click(sender As Object, e As EventArgs) Handles btnCLRF1.Click
        flagIOC1 = False
    End Sub

    Private Sub btnCLRF2_Click(sender As Object, e As EventArgs) Handles btnCLRF2.Click
        flagIOC2 = False
    End Sub

    Private Sub btnCLRF3_Click(sender As Object, e As EventArgs) Handles btnCLRF3.Click
        flagIOC3 = False
    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        Update_label(BackgroundWorker1.IsBusy.ToString, Label17, Color.Transparent, Color.Black)
    End Sub

    ''' <summary>
    ''' receive successfull
    ''' </summary>
    Private Sub rdata(ByVal receiveStatus As Boolean) Handles _rs232.recOK
        If receiveStatus Then
            ' Me.statusRX.Image = My.Resources.ledGreen
            '  Update_bitmap(statusRX, My.Resources.ledGreen)
        Else
            ' Me.statusRX.Image = My.Resources.ledRed
            ' Update_bitmap(statusRX, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connection(ByVal status As Boolean) Handles _rs232.connection
        If status Then
            Update()
            Update_button("disconnect", btnConnectRCV, Color.ForestGreen, Color.Black)
            Update_label("Connect", status0, Color.ForestGreen, Color.Blue)
            Me.sLabel(comparams)
            Me.isConnected = True
        Else
            Update_button("*connect*", btnConnectRCV, Color.Red, Color.White)
            Update_label("none", status0, Color.Red, Color.White)
            Me.isConnected = False
            '
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        '  RemoveAt(1)
    End Sub

    ''' <summary>
    ''' exception message
    ''' </summary>
    Private Sub getmessage(ByVal msg As String) Handles _rs232.errormsg
        'Me.status0.Text = msg
        MsgBox(msg)
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim Card2(3) As Byte
            Dim strdata2 As String = Nothing
            Dim strb3 As String = Nothing
            Dim AGVName As String = Nothing

            '   QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
            ' strb3 = Hex(addT(0)).PadLeft(2, "0"c) & Hex(addT(1)).PadLeft(2, "0"c) & Hex(addT(2)).PadLeft(2, "0"c) & Hex(addT(3)).PadLeft(2, "0"c)
            ' DicCheckAddToQueue.Remove(strdata2)
            QueueManage.deDequeue_AGV(objcell2, lbout02)
            updateAGVQ(objcell2, lbout02)
            'If ReadAGVSetting2.dicname.ContainsKey(strb3) Then
            '    AGVName = ReadAGVSetting2.dicname.Item(strb3)
            'End If
            '  Update_label("NO:" & AGVName, Label2, Color.Gray, Color.Blue)
            C2 = objcell2.Count
            Update_label(C2.ToString, lblC2, Color.Transparent, Color.Black)
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Try
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim Card2(3) As Byte

            Dim strdata2 As String = Nothing
            Dim strb3 As String = Nothing
            Dim AGVName As String = Nothing
            QueueManage.deDequeue_AGV(objcell3, lbout03)
            updateAGVQ(objcell3, lbout03)
            C3 = objcell3.Count
            Update_label(C1.ToString, lblC3, Color.Transparent, Color.Black)
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Update_label(Now.ToShortDateString & " #" & Now.ToShortTimeString, Label25, Color.Black, Color.DeepSkyBlue)
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Try
            UpdateStatus("", ListBox2)
            Dim list1 As New List(Of String)(DicCheckAddToQueue.Keys)
            Dim str As String
            '   list1.Clear()
            For Each str In list1
                UpdateStatus(str, ListBox2)
            Next
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Sub btnConnectRCV_Click(sender As Object, e As EventArgs) Handles btnConnectRCV.Click
        Try

            If CType(sender, Button).Text = "*connect*" Then

                Me.comparams(RS232.cP.cPort) = Readconfig.cPortRCV
                Me.comparams(RS232.cP.cBaud) = Readconfig.cBaudRCV
                Me.comparams(RS232.cP.cData) = Readconfig.cDataRCV
                Me.comparams(RS232.cP.cParity) = Readconfig.cParityRCV
                Me.comparams(RS232.cP.cStop) = Readconfig.cStopRCV
                Me.comparams(RS232.cP.cDelay) = Readconfig.cDelayRCV
                Me.comparams(RS232.cP.cThreshold) = Readconfig.cThresholdRCV
                _rs232.connect(comparams)
            Else
                _rs232.disconnect()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub

#End Region
#Region "utilities  Receive Port"
    ''' <param name="data">data frame</param>
    ''' <param name="currentLenght">possible chars in box</param>
    ''' <param name="showHexAndAscii">determines whether also displaying Hex True</param>
    ''' <remarks></remarks>
    Private Sub appendBytes(ByRef data() As Byte, ByRef currentLenght As Integer, ByVal showHexAndAscii As Boolean)
        Try
            Dim Pac2(20) As Byte
            Dim addT2(7) As Byte

            Dim Card22(3) As Byte
            Dim res2 As Byte
            Dim strdata22 As String = Nothing

            Dim getcell As String = Nothing
            Dim HexString As String = strtemp & StringUltilities.ByteArrayToHexString(data)
            Dim CharString As String = String.Empty
            Dim s() As String = HexString.Split(New String() {" 7E"}, StringSplitOptions.RemoveEmptyEntries)
            ' Static A As Integer
            Dim objmember As Object() = Nothing
            For i = 0 To s.Length - 1
                ' Update_ToolstripStaLabel(s(i).ToString, TstaTCPSignal, Color.MistyRose)
                Dim data_S() As Byte
                Dim ADD() As Byte
                Dim Respond As Byte
                Dim card() As Byte
                Dim strb As String = Nothing
                Dim strb2 As String = Nothing
                Dim Astr As String = ""
                'Dim name As String
                'Dim index As String
                data_S = Reconvert.convert(s(i), " ")
                If data_S.Length = 20 Then
                    strtemp = ""
                    ADD = {data_S(7), data_S(8), data_S(9), data_S(10)}
                    strb = Hex(data_S(7)).PadLeft(2, "0"c) & " " & Hex(data_S(8)).PadLeft(2, "0"c) & " " & Hex(data_S(9)).PadLeft(2, "0"c) & " " & Hex(data_S(10)).PadLeft(2, "0"c)
                    strb2 = Hex(data_S(7)).PadLeft(2, "0"c) & Hex(data_S(8)).PadLeft(2, "0"c) & Hex(data_S(9)).PadLeft(2, "0"c) & Hex(data_S(10)).PadLeft(2, "0"c)
                    Show_ADD = strb2
                    Respond = data_S(16)
                    card = {data_S(18), data_S(17), &H0, &H0}
                    Response = Hex(data_S(17)) & Hex(data_S(18))
                    Dim result As Long = BitConverter.ToUInt32(card, 0)
                    show_result = result.ToString
                    receiveadd = strb
                    ' If strb <> straddcheck Then
                    'straddcheck = strb\
                    Select Case result
                        Case CLng(Readconfig.RFIDCARD)
                            If Not DicCheckAddToQueue.ContainsKey(strb) And result = CDbl(Readconfig.RFIDCARD) Then
                                DicCheckAddToQueue.Add(strb, "1")
                                QueueManage.Enqueue_AGV(obj, ListInQueue1, strb)
                                updateAGVQ(obj, ListInQueue1)
                                Send_cmd_tOagv(_rs232Send, ADD, &H4F, &H4B, &H0) 'send OK Confirm
                                show_detailAGV(Astr)
                                If BackgroundWorker1.IsBusy <> True Then
                                    Delay(0.5)
                                    BackgroundWorker1.RunWorkerAsync()
                                End If

                            ElseIf DicCheckAddToQueue.ContainsKey(strb) And result = CDbl(Readconfig.RFIDCARD_CANCEL) Then
                                Dim Pac(20) As Byte
                                Dim addT(7) As Byte
                                Dim Card2(3) As Byte
                                Dim res As Byte
                                Dim strdata2 As String = Nothing
                                Dim strb3 As String = Nothing
                                Dim AGVName As String = Nothing
                                If obj.Count <> 0 Then
                                    QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
                                    strb3 = Hex(addT(0)).PadLeft(2, "0"c) & Hex(addT(1)).PadLeft(2, "0"c) & Hex(addT(2)).PadLeft(2, "0"c) & Hex(addT(3)).PadLeft(2, "0"c)
                                    If strb = strdata2 Then
                                        DicCheckAddToQueue.Remove(strdata2)
                                        QueueManage.deDequeue_AGV(obj, ListInQueue1)
                                        updateAGVQ(obj, ListInQueue1)
                                        If ReadAGVSetting2.dicname.ContainsKey(strb3) Then
                                            AGVName = ReadAGVSetting2.dicname.Item(strb3)
                                        End If
                                        Update_label("NO:" & AGVName, Label2, Color.Gray, Color.Blue)
                                        Send_cmd_tOagv(_rs232Send, ADD, &H4F, &H4B, &H0) 'send OK Confirm
                                    Else
                                        Update_label("Wait AGV", Label2, Color.Gray, Color.Blue)
                                    End If
                                End If

                            End If
                        Case 19279 'KO

                            If BackgroundWorker1.IsBusy = True Then
                                responsefromAGV = "OK" '"KO"=19279
                            End If
                        Case 20299 'OK
                            If BackgroundWorker1.IsBusy = True Then
                                responsefromAGV = "OK"
                            End If
                        Case 20993 'R1
                            If BackgroundWorker1.IsBusy = True Then
                                responsefromAGV = "Route1"
                            End If
                        Case 20994 'R2
                            If BackgroundWorker1.IsBusy = True Then
                                responsefromAGV = "Route2"
                            End If
                        Case 20995 'R3
                            If BackgroundWorker1.IsBusy = True Then
                                responsefromAGV = "Route3"
                            End If
                        Case 16690 'A2
                            If BackgroundWorker1.IsBusy = True Then
                                responsefromAGV = "ADD"
                            End If
                        Case CLng(Readconfig.RFIDCARD_CANCEL) 'card 217
                            If ChkC03.Checked = True Then
                                QueueManage.Peek_1(obj, Pac2, strdata22, addT2, res2, Card22)
                                If strdata22 = strb And flagNowSend = True Then
                                    flagcancel2 = True
                                Else
                                    Dim ListADD As List(Of String) = obj.ToList
                                    Dim ABC As Integer
                                    For Each ABCStr As String In ListADD.ToArray()
                                        ABC = ABC + 1
                                        If ABCStr = strb Then
                                            ListADD.Remove(ABCStr)
                                            DicCheckAddToQueue.Remove(ABCStr)
                                            ABC = 0
                                        End If
                                    Next
                                    obj = New Queue(Of String)(ListADD.ToArray())
                                    updateAGVQ(obj, ListInQueue1)
                                End If
                            End If
                        Case CLng(Readconfig.RFIDCARD_CANCEL2) 'card 224
                    End Select
                    result = 0
                    card = {&H0, &H0, &H0, &H0}
                Else
                    strtemp = s(s.Length - 1)
                End If
            Next
            HexString = String.Empty
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    ''' <summary>
    ''' show status of connection
    ''' </summary>
    Private Sub sLabel(ByVal comparams() As String)
        Update_label(Readconfig.cPortRCV, lblGetportrcv, Color.Transparent, Color.Black)
    End Sub
#End Region
#End Region
#End Region
#Region "AGV TCP CONTROL"
    Private Sub TCPAVGAutoStartControl()
        Try
            Update_label("[AGV auto start: Connecting to " & socketAGVControl.config.MyIPHost2 & ":" &
                          socketAGVControl.config.MyPortHost2 & "...]", TstaTCPSignal, Color.DimGray, Color.White)
            If socketAGVControl.Connect() Then
                Update_label("[AGV auto start: Connected to " &
                    socketAGVControl.config.MyIPHost2 & ":" & socketAGVControl.config.MyPortHost2 & "]", TstaTCPSignal, Color.DimGray, Color.White)
                While True
                    Dim s As String = socketAGVControl.sr.ReadLine()
                    If s <> "200" Then
                        Try
                            Dim delimiter() As String = {"|"}
                            Dim resArray() As String = s.Split(delimiter, StringSplitOptions.None)
                            If resArray.Length = 3 Then
                                socketAGVControl.received = socketAGVControl.received + 1
                                AGVTcpControl.Master_cell = resArray(0)
                                AGVTcpControl.Master_process = resArray(1)
                                AGVTcpControl.Master_circleTime = resArray(2)
                                'test.Variable = AGVTcpControl.Master_cell
                                Update_label(socketAGVControl.received & ": " & s, TstaTCPSignal, Color.DimGray, Color.White)
                                ' timesignal = Now
                                check_XBADD_inBuffer()
                            End If
                        Catch e As NullReferenceException
                            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 1111")
                            Me.Refresh()
                        End Try
                    End If
                End While
            End If
            socketAGVControl.isTryConnecting = False
        Catch e As InvalidOperationException
            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 2222")
            Me.Refresh()
        Catch e As IOException
            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 3333")
            Me.Refresh()
        End Try
    End Sub
    Public Sub InitialAGVStartControlThread()
        If Not socketAGVControl.isTryConnecting Then
            socketAGVControl.isTryConnecting = True
            If BackgroundWorker4.IsBusy <> True Then
                BackgroundWorker4.RunWorkerAsync()
            End If
        End If
    End Sub

    Public Sub TCPAutoStartControlTimer()
        While True
            Thread.Sleep(5000)
            If Not socketAGVControl.Ping() Then
                InitialAGVStartControlThread()
            End If
            If FlagTCP = 1 Then
                FlagTCP = 0
                socketAGVControl.isTryConnecting = False
            End If
        End While
    End Sub
    Public Sub TcpAGVAutoStartReceive()
        While True
            Try
                Dim s As String = socketAGVControl.sr.ReadLine()
                ' ToolStripStatusLabel1.Text = s
                Update_label(s, TstaTCPSignal, Color.DimGray, Color.White)
            Catch e As InvalidOperationException
                log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 9999")
            End Try
        End While
    End Sub
#End Region
#Region "My Function"
#Region "check process AGV TCP CONTROL running"
    Private Sub CheckProcess()
        Try
            P = Process.GetProcessesByName("AGVControlServerConsole")
            If P.Count > 0 Then
                Exit Sub
            Else
                Process.Start("D:\IprojectDB\Setting\AGVControlServerConsole")
            End If
        Catch ex As Exception
            MessageBox.Show("Please check program connect MPC Website")
        End Try
    End Sub
#End Region
    Private Sub lOOP_Send_Common(ByVal Sendcount As Integer, ByVal addT As Byte())
        Try
            Static CountSent As Integer = Nothing
            Static CountSent2 As Integer = Nothing
            flagNowSend = True
            Do

                If CountSent = Sendcount Or flagcancel2 = True Then
                    ' flagcancel2 = False
                    CountSent = 0
                    responsefromAGV = "Route" & Requestsendline
                    Exit Do
                End If
                CountSent += 1
                Delay(0.5)
                Send_cmd_tOagv(_rs232Send, addT, &H3, &H52, Requestsendline)
                '    Loop Until receiveadd = AGVName And responsefromAGV = "Route" & Requestsendline
            Loop Until responsefromAGV = "Route" & Requestsendline
            Response_Success = responsefromAGV
            responsefromAGV = ""
            CountSent = 0
            Do
                If CountSent2 = Sendcount Or flagcancel2 = True Then
                    flagcancel2 = False
                    CountSent2 = 0
                    responsefromAGV = "OK"
                    Exit Do
                End If
                CountSent2 += 1
                Delay(0.5)
                Send_cmd_tOagv(_rs232Send, addT, &H1, &H0, &H0)
                ' Loop Until receiveadd = AGVName And responsefromAGV = "OK"
            Loop Until responsefromAGV = "OK"
            Response_Success = Response_Success & responsefromAGV
            responsefromAGV = ""
            CountSent2 = 0

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Sub Check_Success_Loop(ByVal flagchksuccess As Boolean, ByVal strdata2 As String)
        Try
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim addfixuptime(3) As Byte
            Dim addFixsend(3) As Byte
            Dim Card2(3) As Byte
            Dim res As Byte

            Dim strdata22 As String = Nothing
            Dim getcell As String = Nothing
            'Static CountSent As Integer = 0

            If Response_Success <> "Route" & Requestsendline & "OK" And flagchksuccess = True And Response_Success <> "" Then
                MessageBox.Show("ติดตรงนี่ค่าาาา")
                While True
                    If Response_Success = "Route" & Requestsendline & "OK" Then
                        If ChkCLRCLRKEY.Checked = True Then
                            DicCheckAddToQueue.Remove(strdata2)
                        End If
                        QueueManage.deDequeue_AGV(obj, ListInQueue1)
                        updateAGVQ(obj, ListInQueue1)
                        QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
                        Dim AGVName As String
                        If ReadAGVSetting2.dicname.ContainsKey(getadd) Then
                            AGVName = ReadAGVSetting2.dicname.Item(getadd)
                        End If
                        Update_label("NO:" & AGVName, Label2, Color.Gray, Color.Blue)
                        Delay(0.5)
                        Select Case DequeueIndex
                            Case "LIST1"
                                QueueManage.deDequeue_AGV(obj2, lbout)
                                updateAGVQ(obj2, lbout)
                                flagchksuccess = False
                                C1 = obj2.Count
                                Update_label(C1.ToString, lblC1, Color.Transparent, Color.Black)
                                                          '  stamptimeC1 = Now
                            Case "LIST2"
                                QueueManage.deDequeue_AGV(objcell2, lbout02)
                                updateAGVQ(objcell2, lbout02)
                                flagchksuccess = False
                                C2 = objcell2.Count
                                flagchksuccess = False
                                Update_label(C2.ToString, lblC2, Color.Transparent, Color.Black)
                                                         '   stamptimeC2 = Now
                            Case "LIST3"
                                QueueManage.deDequeue_AGV(objcell3, lbout03)
                                updateAGVQ(objcell3, lbout03)
                                C3 = objcell3.Count
                                flagchksuccess = False
                                Update_label(C3.ToString, lblC3, Color.Transparent, Color.Black)
                                '  stamptimeC3 = Now
                        End Select
                        Update_label("Waiting..", Label2, Color.Gray, Color.Blue)
                        Delay(0.5)
                        Response_Success = ""
                        DequeueIndex = ""
                        Exit While
                    End If
                End While
            ElseIf Response_Success = "Route" & Requestsendline & "OK" And flagchksuccess = True Then
                If ChkCLRCLRKEY.Checked = True Then
                    DicCheckAddToQueue.Remove(strdata2)
                End If
                QueueManage.deDequeue_AGV(obj, ListInQueue1)
                updateAGVQ(obj, ListInQueue1)
                Dim AGVName As String
                If ReadAGVSetting2.dicname.ContainsKey(getadd) Then
                    AGVName = ReadAGVSetting2.dicname.Item(getadd)
                End If
                Update_label("NO:" & AGVName, Label2, Color.Gray, Color.Blue)
                Delay(0.5)
                Select Case DequeueIndex
                    Case "LIST1"
                        QueueManage.deDequeue_AGV(obj2, lbout)
                        updateAGVQ(obj2, lbout)
                        flagchksuccess = False
                        C1 = obj2.Count
                        Update_label(C1.ToString, lblC1, Color.Transparent, Color.Black)
                                                      '  stamptimeC1 = Now
                    Case "LIST2"
                        QueueManage.deDequeue_AGV(objcell2, lbout02)
                        updateAGVQ(objcell2, lbout02)
                        flagchksuccess = False
                        C2 = objcell2.Count
                        flagchksuccess = False
                        Update_label(C2.ToString, lblC2, Color.Transparent, Color.Black)
                                                     '   stamptimeC2 = Now
                    Case "LIST3"
                        QueueManage.deDequeue_AGV(objcell3, lbout03)
                        updateAGVQ(objcell3, lbout03)
                        C3 = objcell3.Count
                        flagchksuccess = False
                        Update_label(C3.ToString, lblC3, Color.Transparent, Color.Black)
                        '  stamptimeC3 = Now
                End Select
                '  Update_label("Waiting..", Label2, Color.Gray, Color.Blue)
                ' Delay(0.5)
                Response_Success = ""
                DequeueIndex = ""
                flagchksuccess = False
                flagNowSend = False
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Sub show_detailAGV()
        Try
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim Card2(3) As Byte
            Dim res As Byte
            Dim strdata2 As String = Nothing
            Dim strb3 As String = Nothing
            Dim AGVName As String = Nothing
            If obj.Count <> 0 Then
                QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
                strb3 = Hex(addT(0)).PadLeft(2, "0"c) & Hex(addT(1)).PadLeft(2, "0"c) & Hex(addT(2)).PadLeft(2, "0"c) & Hex(addT(3)).PadLeft(2, "0"c)
                If ReadAGVSetting2.dicname.ContainsKey(strb3) Then
                    AGVName = ReadAGVSetting2.dicname.Item(strb3)
                End If
                Update_label("NO:" & AGVName, Label19, Color.Transparent, Color.Blue)
            Else
                Update_label("Wait AGV", Label19, Color.Gray, Color.Blue)
            End If
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Public Sub check_XBADD_inBuffer()
        Try
            Dim Pac(20) As Byte
            Dim addT(3) As Byte
            Dim Card(3) As Byte
            ' Dim res As Byte
            Dim strdata As String = Nothing
            '  Dim Stradd As String

            Select Case AGVTcpControl.Master_cell
                Case Readconfig.CmdTCPCell1
                    getCycletimeC1 = getCradNo
                    QueueManage.Enqueue_AGV(obj2, lbout, Readconfig.CmdTCPCell1)
                    updateAGVQ(obj2, lbout)
                    C1 = obj2.Count
                    Update_label(C1.ToString, lblC1, Color.Transparent, Color.Black)
                    If BackgroundWorker1.IsBusy <> True Then
                        Delay(0.5)
                        BackgroundWorker1.RunWorkerAsync()
                    End If
                Case Readconfig.CmdTCPCell2
                    getCycletimeC2 = getCradNo
                    QueueManage.Enqueue_AGV(objcell2, lbout02, Readconfig.CmdTCPCell2)
                    updateAGVQ(objcell2, lbout02)
                    C2 = objcell2.Count
                    Update_label(C2.ToString, lblC2, Color.Transparent, Color.Black)
                    If BackgroundWorker1.IsBusy <> True Then
                        Delay(0.5)
                        BackgroundWorker1.RunWorkerAsync()
                    End If
                Case Readconfig.CmdTCPCell3
                    getCycletimeC3 = getCradNo
                    QueueManage.Enqueue_AGV(objcell3, lbout03, Readconfig.CmdTCPCell3)
                    updateAGVQ(objcell3, lbout03)
                    C3 = objcell3.Count
                    Update_label(C3.ToString, lblC3, Color.Transparent, Color.Black)
                    If BackgroundWorker1.IsBusy <> True Then
                        Delay(0.5)
                        BackgroundWorker1.RunWorkerAsync()
                    End If
            End Select
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Sub updateAGVQ(ByRef objT As Queue(Of String), ByRef ListInQueue As ListBox)
        '    Try)
        If objT.Count <> 0 Then
            Dim arr As Object()
            arr = objT.ToArray()
            UpdateStatus("", ListInQueue)
            For i As Integer = 0 To objT.Count - 1
                UpdateStatus(arr(i).ToString, ListInQueue)
            Next
        ElseIf objT.Count = 0 Then
            ' ListInQueue.Items.Clear()
            UpdateStatus("", ListInQueue)
            '  MessageBox.Show("queue is empty")
        End If
    End Sub
#Region "Holding 3 cell"
    '    Private Sub CompareDataToSend(ByVal Cell1 As Integer, ByVal Cell2 As Integer, ByVal Cell3 As Integer)
    '        'time2 = Now
    '        'timewaitAGV = time2.Subtract(time1)
    '        'totaltime_wait_AGV = FormatNumber(timewaitAGV.Seconds)
    '        If Cell1 > Cell2 And Cell1 > Cell3 Then '1 0 0
    '            Requestsendline = CByte(Readconfig.CmdRouteCell1)
    '        ElseIf Cell2 > Cell1 And Cell2 > Cell3 Then '0 1 0
    '            Requestsendline = CByte(Readconfig.CmdRouteCell2)
    '            'ElseIf Cell3 > Cell1 And Cell3 > Cell2 Then '0 0 1
    '            '    Requestsendline = CByte(Readconfig.CmdRouteCell3)
    '        ElseIf (Cell1 < Cell2 And Cell2 = Cell3) Or (Cell1 < Cell3 And Cell2 = Cell3) Then '0 1 1
    '            timenow = Now
    '            GetcomparetimeC2 = timenow.Subtract(stamptimeC2)
    '            totaltimelastedC2 = FormatNumber(GetcomparetimeC2.Seconds)
    '            GetcomparetimeC3 = timenow.Subtract(stamptimeC3)
    '            totaltimelastedC3 = FormatNumber(GetcomparetimeC3.Seconds)
    '            If CInt(totaltimelastedC2) < CInt(totaltimelastedC3) Then
    '                Requestsendline = CByte(Readconfig.CmdRouteCell3)
    '            ElseIf CInt(totaltimelastedC2) > CInt(totaltimelastedC3) Then
    '                Requestsendline = CByte(Readconfig.CmdRouteCell2)
    '            Else
    '                Requestsendline = CByte(Readconfig.CmdRouteCell3)
    '            End If
    '        ElseIf (Cell2 < Cell1 And Cell1 = Cell3) Or (Cell2 < Cell3 And Cell1 = Cell3) Then '1 0 1
    '            timenow = Now
    '            GetcomparetimeC1 = timenow.Subtract(stamptimeC1)
    '            totaltimelastedC1 = FormatNumber(GetcomparetimeC1.Seconds)
    '            GetcomparetimeC3 = timenow.Subtract(stamptimeC3)
    '            totaltimelastedC3 = FormatNumber(GetcomparetimeC3.Seconds)
    '            If CInt(totaltimelastedC1) < CInt(totaltimelastedC3) Then
    '                Requestsendline = CByte(Readconfig.CmdRouteCell3)
    '            ElseIf CInt(totaltimelastedC1) > CInt(totaltimelastedC3) Then
    '                Requestsendline = CByte(Readconfig.CmdRouteCell1)
    '            Else
    '                Requestsendline = CByte(Readconfig.CmdRouteCell1)
    '            End If
    '        ElseIf (Cell3 < Cell1 And Cell1 = Cell2) Or (Cell3 < Cell2 And Cell1 = Cell2) Then ' 1 1 0
    '            timenow = Now
    '            GetcomparetimeC1 = timenow.Subtract(stamptimeC1)
    '            totaltimelastedC1 = FormatNumber(GetcomparetimeC1.Seconds)
    '            GetcomparetimeC2 = timenow.Subtract(stamptimeC2)
    '            totaltimelastedC2 = FormatNumber(GetcomparetimeC2.Seconds)
    '            If CInt(totaltimelastedC1) < CInt(totaltimelastedC2) Then
    '                Requestsendline = CByte(Readconfig.CmdRouteCell2)
    '            ElseIf CInt(totaltimelastedC1) > CInt(totaltimelastedC2) Then
    '                Requestsendline = CByte(Readconfig.CmdRouteCell1)
    '            Else
    '                Requestsendline = CByte(Readconfig.CmdRouteCell1)
    '            End If
    '        ElseIf Cell1 = Cell2 And Cell1 = Cell3 And Cell2 = Cell3 And Cell1 > 0 And Cell2 > 0 And Cell3 > 0 Then ' 1 1 1 
    '            timenow = Now
    '            GetcomparetimeC1 = timenow.Subtract(stamptimeC1)
    '            totaltimelastedC1 = FormatNumber(GetcomparetimeC1.Seconds)
    '            GetcomparetimeC2 = timenow.Subtract(stamptimeC2)
    '            totaltimelastedC2 = FormatNumber(GetcomparetimeC2.Seconds)
    '            GetcomparetimeC3 = timenow.Subtract(stamptimeC3)
    '            totaltimelastedC3 = FormatNumber(GetcomparetimeC3.Seconds)
    '            If CInt(totaltimelastedC1) > CInt(totaltimelastedC2) And CInt(totaltimelastedC1) > CInt(totaltimelastedC3) Then
    '                Requestsendline = CByte(Readconfig.CmdRouteCell1)
    '            ElseIf CInt(totaltimelastedC2) > CInt(totaltimelastedC1) And CInt(totaltimelastedC2) > CInt(totaltimelastedC3) Then
    '                Requestsendline = CByte(Readconfig.CmdRouteCell2)
    '            ElseIf CInt(totaltimelastedC3) > CInt(totaltimelastedC1) And CInt(totaltimelastedC3) > CInt(totaltimelastedC2) Then
    '                Requestsendline = CByte(Readconfig.CmdRouteCell3)
    '            Else
    '                Requestsendline = CByte(Readconfig.CmdRouteCell1)
    '            End If
    '            'ElseIf Cell1 = Nothing And Cell2 = Nothing And Cell3 = Nothing Then
    '            '    Requestsendline = 1
    '        Else
    '            Requestsendline = 0
    '        End If

    '    End Sub
#End Region
    Private Sub CompareDataToSend2Cell(ByVal Cell1 As Integer, ByVal Cell2 As Integer)
        If CheckBox1.Checked = True Then
            stamptimeIOC1 = Now
            If flagIOC1 = True Then
                GetcomparetimeIOC1 = stamptimeIOC1.Subtract(timenowIOC1)
                totaltimelastedIOC1 = FormatNumber(GetcomparetimeIOC1.TotalSeconds)
                If CInt(totaltimelastedIOC1) > CInt(Readconfig.TimeOutFlagIO) Then
                    ' totaltimelastedIOC1 = "0"
                    flagIOC1 = False
                End If
                Update_label(totaltimelastedIOC1, LblTIOC1, Color.Transparent, Color.Black)
            End If
            If flagIOC2 = True Then
                GetcomparetimeIOC2 = stamptimeIOC1.Subtract(timenowIOC2)
                totaltimelastedIOC2 = FormatNumber(GetcomparetimeIOC2.TotalSeconds)
                If CInt(totaltimelastedIOC2) > CInt(Readconfig.TimeOutFlagIO) Then
                    ' totaltimelastedIOC2 = "0"
                    flagIOC2 = False
                End If
                Update_label(totaltimelastedIOC2, LblTIOC2, Color.Transparent, Color.Black)
            End If
        End If
        System.Threading.Thread.Sleep(300)
        'condition 1-------------------
        If Cell1 = Cell2 And Cell1 > 0 And Cell2 > 0 Then ' 1 1 
            timenow = Now
            GetcomparetimeC1 = timenow.Subtract(stamptimeC1)
            totaltimelastedC1 = FormatNumber(GetcomparetimeC1.TotalSeconds)
            timenow = Now
            GetcomparetimeC2 = timenow.Subtract(stamptimeC2)
            totaltimelastedC2 = FormatNumber(GetcomparetimeC2.TotalSeconds)
            If CInt(totaltimelastedC1) > CInt(totaltimelastedC2) Then
                If IOVARC1 = "KITTING OK" And Cell1 > 0 And flagIOC1 = False And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell1)
                    flagIOC1 = True '111 333
                    timenowIOC1 = Now
                ElseIf IOVARC1 = "WAIT KITTING" Then
                    If Cell1 = Cell2 And Cell1 >= 0 And Cell2 >= 0 And IOVARC2 = "KITTING OK" And flagIOC2 = False And obj.Count > 0 Then ' 1 1 
                        Requestsendline = CByte(Readconfig.CmdRouteCell2)
                        flagIOC2 = True
                        timenowIOC2 = Now
                    Else
                        Requestsendline = 0
                    End If
                End If
            ElseIf CInt(totaltimelastedC2) > CInt(totaltimelastedC1) Then
                If IOVARC2 = "KITTING OK" And Cell2 > 0 And flagIOC2 = False And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell2)
                    flagIOC2 = True
                    timenowIOC2 = Now
                ElseIf IOVARC2 = "WAIT KITTING" Then
                    If Cell1 >= 0 And Cell2 >= 0 And IOVARC1 = "KITTING OK" And flagIOC1 = False And obj.Count > 0 Then ' 1 1 
                        Requestsendline = CByte(Readconfig.CmdRouteCell1)
                        flagIOC1 = True
                        timenowIOC1 = Now
                    Else
                        Requestsendline = 0
                    End If
                End If
            ElseIf CInt(totaltimelastedC2) = CInt(totaltimelastedC1) Then
                If IOVARC1 = "KITTING OK" And flagIOC1 = False And obj.Count > 0 And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell1)
                    flagIOC1 = True '3
                    timenowIOC1 = Now
                ElseIf IOVARC2 = "KITTING OK" And flagIOC2 = False And obj.Count > 0 And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell2)
                    flagIOC2 = True
                    timenowIOC2 = Now
                Else
                    Requestsendline = 0
                End If
            Else
                '  Requestsendline = CByte(Readconfig.CmdRouteCell1)
                Requestsendline = 0
            End If
            'condition 2-------------------
        ElseIf Cell1 = Cell2 And Cell1 = 0 And Cell2 = 0 Then ' 1 1 
            Requestsendline = 0
            'condition 3-------------------
        ElseIf Cell1 > Cell2 And Cell1 >= 0 And Cell2 >= 0 Then ' 1 0
            timenow = Now
            GetcomparetimeC1 = timenow.Subtract(stamptimeC1)
            totaltimelastedC1 = FormatNumber(GetcomparetimeC1.TotalSeconds)
            GetcomparetimeC2 = timenow.Subtract(stamptimeC2)
            totaltimelastedC2 = FormatNumber(GetcomparetimeC2.TotalSeconds)
            'Requestsendline = CByte(Readconfig.CmdRouteCell1)
            'flagIOC1 = True
            If CInt(totaltimelastedC1) > CInt(totaltimelastedC2) Then 'อันนี่กะด้วยย
                If IOVARC1 = "KITTING OK" And Cell1 > 0 And flagIOC1 = False And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell1)
                    flagIOC1 = True '1
                    timenowIOC1 = Now
                ElseIf IOVARC1 = "WAIT KITTING" Then
                    If Cell1 >= 0 And Cell2 > 0 And IOVARC2 = "KITTING OK" And flagIOC2 = False And obj.Count > 0 Then
                        Requestsendline = CByte(Readconfig.CmdRouteCell2)
                        flagIOC2 = True
                        timenowIOC2 = Now
                    Else
                        Requestsendline = 0
                    End If
                End If
            ElseIf CInt(totaltimelastedC2) > CInt(totaltimelastedC1) Then
                If IOVARC2 = "KITTING OK" And Cell2 > 0 And flagIOC2 = False And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell2)
                    flagIOC2 = True
                    timenowIOC2 = Now
                ElseIf IOVARC2 = "KITTING OK" And Cell2 = 0 And flagIOC1 = False And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell1)
                    flagIOC1 = True '1 3
                    timenowIOC1 = Now
                ElseIf IOVARC2 = "WAIT KITTING" Then
                    If Cell1 >= 0 And Cell2 >= 0 And IOVARC1 = "KITTING OK" And flagIOC1 = False And obj.Count > 0 Then
                        Requestsendline = CByte(Readconfig.CmdRouteCell1)
                        flagIOC1 = True '2
                        timenowIOC1 = Now
                    Else
                        Requestsendline = 0
                    End If
                End If

            ElseIf CInt(totaltimelastedC2) = CInt(totaltimelastedC1) Then
                If IOVARC1 = "KITTING OK" And flagIOC1 = False And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell1)
                    flagIOC1 = True '1 2 4
                    timenowIOC1 = Now
                ElseIf IOVARC1 = "WAIT KITTING" Then
                    If Cell1 >= 0 And Cell2 > 0 And IOVARC2 = "KITTING OK" And flagIOC2 = False And obj.Count > 0 Then
                        Requestsendline = CByte(Readconfig.CmdRouteCell2)
                        flagIOC2 = True
                        timenowIOC2 = Now
                    Else
                        Requestsendline = 0
                    End If
                End If
            Else
                Requestsendline = 0
            End If
            'condition 4-------------------
        ElseIf Cell1 < Cell2 And Cell1 >= 0 And Cell2 >= 0 Then ' 0 1 
            timenow = Now
            GetcomparetimeC1 = timenow.Subtract(stamptimeC1)
            totaltimelastedC1 = FormatNumber(GetcomparetimeC1.TotalSeconds)
            GetcomparetimeC2 = timenow.Subtract(stamptimeC2)
            totaltimelastedC2 = FormatNumber(GetcomparetimeC2.TotalSeconds)
            'Requestsendline = CByte(Readconfig.CmdRouteCell2)
            'flagIOC2 = True
            If CInt(totaltimelastedC2) > CInt(totaltimelastedC1) Then
                If IOVARC2 = "KITTING OK" And Cell2 > 0 And flagIOC2 = False And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell2)
                    flagIOC2 = True '111 3 3 3 
                    timenowIOC2 = Now
                ElseIf IOVARC2 = "WAIT KITTING" Then
                    If Cell1 > 0 And Cell2 >= 0 And IOVARC1 = "KITTING OK" And flagIOC1 = False And obj.Count > 0 Then ' 1 1 
                        Requestsendline = CByte(Readconfig.CmdRouteCell1)
                        flagIOC1 = True
                        timenowIOC1 = Now
                    Else
                        Requestsendline = 0
                    End If
                ElseIf IOVARC2 = "KITTING OK" And Cell2 <= 0 And flagIOC2 = False And obj.Count > 0 Then
                    If Cell1 > 0 And Cell2 >= 0 And IOVARC1 = "KITTING OK" And flagIOC1 = False And obj.Count > 0 Then ' 1 1 
                        Requestsendline = CByte(Readconfig.CmdRouteCell1)
                        flagIOC1 = True
                        timenowIOC1 = Now
                    Else
                        Requestsendline = 0
                    End If
                End If
            ElseIf CInt(totaltimelastedC1) > CInt(totaltimelastedC2) Then
                If IOVARC1 = "KITTING OK" And Cell1 > 0 And flagIOC1 = False And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell1)
                    flagIOC1 = True
                    timenowIOC1 = Now
                ElseIf IOVARC1 = "KITTING OK" And Cell1 = 0 And flagIOC2 = False And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell2)
                    flagIOC2 = True
                    timenowIOC2 = Now
                ElseIf IOVARC1 = "WAIT KITTING" Then
                    If Cell1 >= 0 And Cell2 > 0 And IOVARC2 = "KITTING OK" And flagIOC2 = False And obj.Count > 0 Then ' 1 1 
                        Requestsendline = CByte(Readconfig.CmdRouteCell2)
                        flagIOC2 = True
                        timenowIOC2 = Now
                    Else
                        Requestsendline = 0
                    End If
                ElseIf IOVARC1 = "KITTING OK" And Cell1 >= 0 And flagIOC1 = False Then
                    If Cell1 >= 0 And Cell2 > 0 And IOVARC2 = "KITTING OK" And flagIOC2 = False And obj.Count > 0 Then ' 1 1 
                        Requestsendline = CByte(Readconfig.CmdRouteCell2)
                        flagIOC2 = True
                        timenowIOC2 = Now
                    Else
                        Requestsendline = 0
                    End If
                End If

            ElseIf CInt(totaltimelastedC2) = CInt(totaltimelastedC1) Then ' ยังไงดีน๊าาาาาาา
                If IOVARC2 = "KITTING OK" And flagIOC2 = False And obj.Count > 0 Then
                    Requestsendline = CByte(Readconfig.CmdRouteCell2)
                    flagIOC2 = True '1
                    timenowIOC2 = Now
                ElseIf IOVARC2 = "WAIT KITTING" Then
                    If Cell1 > 0 And Cell2 > 0 And IOVARC1 = "KITTING OK" And flagIOC1 = False And obj.Count > 0 Then
                        Requestsendline = CByte(Readconfig.CmdRouteCell1)
                        flagIOC1 = True
                        timenowIOC1 = Now
                    Else
                        Requestsendline = 0
                    End If
                End If
            Else
                Requestsendline = 0
            End If
        Else
            Requestsendline = 0
        End If
    End Sub
#End Region
#Region "safety UI Update"
    Private Delegate Sub DelegateUpdateLabel(ByVal strstatusLabel As String, ByVal lbl As Label, ByVal lblcolor As Color, ByVal lblForecolor As Color)
    Private Sub Update_label(ByVal strstatusLabel As String, ByVal lbl As Label, ByVal lblcolor As Color, ByVal lblForecolor As Color)
        Try
            If InvokeRequired Then
                If strstatusLabel = "" Then
                    Invoke(Sub() lbl.Text = strstatusLabel)
                    Invoke(Sub() lbl.BackColor = lblcolor)
                    Invoke(Sub() lbl.ForeColor = lblForecolor)
                Else
                    Invoke(Sub() lbl.Text = strstatusLabel)
                    Invoke(Sub() lbl.BackColor = lblcolor)
                    Invoke(Sub() lbl.ForeColor = lblForecolor)
                End If
            Else
                If strstatusLabel = "" Then
                    lbl.Text = strstatusLabel
                    lbl.BackColor = lblcolor
                    lbl.ForeColor = lblForecolor
                Else
                    lbl.Text = strstatusLabel
                    lbl.BackColor = lblcolor
                    lbl.ForeColor = lblForecolor
                End If
            End If

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateLog(ByVal StrCSV1 As String)
    Private Sub Update_Log(ByVal StrCSV1 As String)
        '  Me.statusRXSend.Image = My.Resources.ledGreen
        Try
            If InvokeRequired Then
                Invoke(Sub() logE.Log(vbCr & StrCSV1 & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"))
            Else
                logE.Log(vbCr & StrCSV1 & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateStatus22(ByVal statusText1 As String, ByVal txt As ListBox)
    Private Sub UpdateStatus(ByVal statusText1 As String, ByVal txt As ListBox)
        Try
            If InvokeRequired Then
                If statusText1 = "" Then
                    Invoke(Sub() txt.Items.Clear())
                Else
                    Invoke(Sub() txt.Items.Add(statusText1))
                End If
            Else
                If statusText1 = "" Then
                    txt.Items.Clear()
                Else
                    txt.Items.Add(statusText1)
                End If
            End If
        Catch ex As Exception
            '  logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateTCP(ByVal TxtCell As String)
    'Private Sub SendTCP(ByVal TxtCell As String, ByVal TCPRemotePort As Integer)
    '    Try
    '        If InvokeRequired Then
    '            Invoke(Sub() TCPChat_Sender(TxtCell, TCPRemotePort))
    '        Else
    '            TCPChat_Sender(TxtCell, TCPRemotePort)
    '        End If
    '    Catch ex As Exception
    '        Update_Log(ex.ToString())
    '    End Try
    'End Sub
    Private Delegate Sub DelegateUpdateButton(ByVal strstatusbutton As String, ByVal btn1 As Button, ByVal colorB As Color, ByVal colorFore1 As Color)
    Private Sub Update_button(ByVal strstatusbutton As String, ByVal btn1 As Button, ByVal colorB As Color, ByVal colorFore1 As Color)
        '  Me.statusRXSend.Image = My.Resources.ledGreen
        Try
            If InvokeRequired Then

                Invoke(Sub() btn1.Text = strstatusbutton)
                Invoke(Sub() btn1.BackColor = colorB)
                Invoke(Sub() btn1.ForeColor = colorFore1)
            Else
                btn1.Text = strstatusbutton
                btn1.BackColor = colorB
                btn1.ForeColor = colorFore1
            End If

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
#End Region
#Region "Backgroung1"
    Private Sub BackgroundWorker1_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        Try
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim addfixuptime(3) As Byte
            Dim addFixsend(3) As Byte
            Dim Card2(3) As Byte
            Dim res As Byte
            Dim strdata2 As String = Nothing
            Dim strdata22 As String = Nothing
            Dim getcell As String = Nothing
            Static CountSent As Integer = 0
            Dim flagchksuccess As Boolean = False
again:

            ' Requestsendline = 0
            CompareDataToSend2Cell(C1, C2) 'compare request to send line
            Select Case Requestsendline
                Case 0
                    Update_label("Wait Send....", lblStaRoute, Color.CornflowerBlue, Color.White)
                    Delay(1)
                    GoTo again
                Case 1
                    Update_label("Send >>>" & Requestsendline.ToString, lblStaRoute, Color.CornflowerBlue, Color.White)
                    flagsequence1 = True
                    Select Case Readconfig.ListBoxCell1 'select from config for read data in list box
                        Case "LIST1" : QueueManage.Peek_2(obj2, strdata22)
                        Case "LIST2" : QueueManage.Peek_2(objcell2, strdata22)
                        Case "LIST3" : QueueManage.Peek_2(objcell3, strdata22)
                    End Select ' select from config for read data in list box                          
                Case 2
                    Update_label("Send >>>" & Requestsendline.ToString, lblStaRoute, Color.CornflowerBlue, Color.White)
                    flagsequence2 = True
                    Select Case Readconfig.ListBoxCell2 'select from config for read data in list box
                        Case "LIST1" : QueueManage.Peek_2(obj2, strdata22)
                        Case "LIST2" : QueueManage.Peek_2(objcell2, strdata22)
                        Case "LIST3" : QueueManage.Peek_2(objcell3, strdata22)
                    End Select ' select from config for read data in list box            
                Case 3
                    Update_label("Send >>>" & Requestsendline.ToString, lblStaRoute, Color.CornflowerBlue, Color.White)
                    flagsequence3 = True
                    Select Case Readconfig.ListBoxCell3 'select from config for read data in list box
                        Case "LIST1" : QueueManage.Peek_2(obj2, strdata22)
                        Case "LIST2" : QueueManage.Peek_2(objcell2, strdata22)
                        Case "LIST3" : QueueManage.Peek_2(objcell3, strdata22)
                    End Select ' select from config for read data in list box            
            End Select

#Region "Hold"
            While True
                If obj.Count > 0 Then
                    If flagsequence1 = True Or flagsequence2 = True Or flagsequence3 = True Then

                        QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
                        Select Case Requestsendline
                            Case 1
                                DequeueIndex = Readconfig.ListBoxCell1
                                Select Case strdata22
                                    Case Readconfig.CmdTCPCell1
                                        stamptimeC1 = Now
                                        strdata22 = ""
                                        lOOP_Send_Common(CInt(Readconfig.SendCount), addT)
                                        Update_label(" ", Label18, Color.Transparent, Color.Pink)
                                        flagchksuccess = True
                                        flagsequence1 = False
                                    Case Readconfig.CmdTCPCell2
                                        stamptimeC2 = Now
                                        strdata22 = ""
                                        lOOP_Send_Common(CInt(Readconfig.SendCount), addT)
                                        flagchksuccess = True
                                        flagsequence2 = False
                                    Case Readconfig.CmdTCPCell3
                                        stamptimeC3 = Now
                                        strdata22 = ""
                                        lOOP_Send_Common(CInt(Readconfig.SendCount), addT)
                                        flagchksuccess = True
                                        flagsequence3 = False
                                End Select
                                Check_Success_Loop(flagchksuccess, strdata2)
                            Case 2
                                DequeueIndex = Readconfig.ListBoxCell2
                                Select Case strdata22
                                    Case Readconfig.CmdTCPCell1
                                        stamptimeC1 = Now
                                        lOOP_Send_Common(CInt(Readconfig.SendCount), addT)
                                        strdata22 = ""
                                        flagchksuccess = True
                                        flagsequence1 = False
                                    Case Readconfig.CmdTCPCell2
                                        stamptimeC2 = Now
                                        lOOP_Send_Common(CInt(Readconfig.SendCount), addT)
                                        strdata22 = ""
                                        flagchksuccess = True
                                        flagsequence2 = False
                                    Case Readconfig.CmdTCPCell3
                                        stamptimeC3 = Now
                                        strdata22 = ""
                                        flagchksuccess = True
                                        flagsequence3 = False
                                End Select
                                Check_Success_Loop(flagchksuccess, strdata2)

                            Case 3
                                DequeueIndex = Readconfig.ListBoxCell3
                                Select Case strdata22
                                    Case Readconfig.CmdTCPCell1
                                        stamptimeC1 = Now
                                        lOOP_Send_Common(CInt(Readconfig.SendCount), addT)
                                        strdata22 = ""
                                        flagchksuccess = True
                                        flagsequence1 = False
                                    Case Readconfig.CmdTCPCell2
                                        stamptimeC2 = Now
                                        lOOP_Send_Common(CInt(Readconfig.SendCount), addT)

                                        strdata22 = ""
                                        flagchksuccess = True
                                        flagsequence2 = False
                                    Case Readconfig.CmdTCPCell3
                                        stamptimeC3 = Now
                                        strdata22 = ""
                                        flagchksuccess = True
                                        flagsequence3 = False
                                End Select
                                Check_Success_Loop(flagchksuccess, strdata2)
                        End Select
                        Update_label("Wait next...", lblStaRoute, Color.CornflowerBlue, Color.White)
                    ElseIf (obj.Count > 0 And obj2.Count = 0 And objcell2.Count = 0 And objcell3.Count = 0) Then
                        While True
                            If obj2.Count > 0 Or objcell2.Count > 0 Or objcell3.Count > 0 Then
                                Update_label("Wait next...", lblStaRoute, Color.CornflowerBlue, Color.White)
                                GoTo again
                            End If
                        End While
                    ElseIf (obj2.Count > 0 Or objcell2.Count > 0 Or objcell3.Count > 0 And obj.Count = 0) Then
                        While True
                            If obj.Count > 0 Then
                                Update_label("Wait next...", lblStaRoute, Color.CornflowerBlue, Color.White)
                                GoTo again
                            End If
                        End While
                    End If
                    If obj.Count > 0 Then
                        GoTo again
                    Else
                        Exit While
                    End If
                ElseIf obj.Count <= 0 Then
                    Update_label("Wait next...", lblStaRoute, Color.CornflowerBlue, Color.White)
                    Exit While
                End If
            End While
        Catch ex As Exception
            Update_Log(ex.ToString())
            System.Threading.Thread.Sleep(100)
        End Try
    End Sub

    Private Sub BackgroundWorker1_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
    End Sub
#End Region
#End Region
    Private Sub BackgroundWorker4_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker4.DoWork
        TCPAutoStartControlTimer()
    End Sub

    Private Sub BackgroundWorker5_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker5.DoWork
        TCPAVGAutoStartControl()
    End Sub



End Class


