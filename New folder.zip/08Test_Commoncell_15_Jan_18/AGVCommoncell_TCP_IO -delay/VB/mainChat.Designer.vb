﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainChat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lbout = New System.Windows.Forms.ListBox()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.StatusLabel_adapter = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusLabel_send = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusLabel_receive = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer5 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.LblIO1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.SplitContainer7 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer6 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel7 = New System.Windows.Forms.TableLayoutPanel()
        Me.lbout02 = New System.Windows.Forms.ListBox()
        Me.LblIO2 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel8 = New System.Windows.Forms.TableLayoutPanel()
        Me.LblIO3 = New System.Windows.Forms.Label()
        Me.lbout03 = New System.Windows.Forms.ListBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel9 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.ListInQueue1 = New System.Windows.Forms.ListBox()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.TableLayoutPanel10 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblC3 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblC2 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lbltimeC1 = New System.Windows.Forms.Label()
        Me.lbltimeC2 = New System.Windows.Forms.Label()
        Me.lbltimeC3 = New System.Windows.Forms.Label()
        Me.lblC1 = New System.Windows.Forms.Label()
        Me.lblCOC1 = New System.Windows.Forms.Label()
        Me.lblCOC2 = New System.Windows.Forms.Label()
        Me.lblCOC3 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.LblTIOC1 = New System.Windows.Forms.Label()
        Me.LblTIOC2 = New System.Windows.Forms.Label()
        Me.LblTIOC3 = New System.Windows.Forms.Label()
        Me.TstaTCPSignal = New System.Windows.Forms.Label()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.lblStaRoute = New System.Windows.Forms.Label()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.ChkOK = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.btnCLRF3 = New System.Windows.Forms.Button()
        Me.btnCLRF2 = New System.Windows.Forms.Button()
        Me.btnCLRF1 = New System.Windows.Forms.Button()
        Me.ChkCLRCLRKEY = New System.Windows.Forms.CheckBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.ChkC03 = New System.Windows.Forms.CheckBox()
        Me.ChkC01 = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btn_clear = New System.Windows.Forms.Button()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblGetportrcv = New System.Windows.Forms.Label()
        Me.lblRXCount = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnConnectRCV = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.status0 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblGetportSend = New System.Windows.Forms.Label()
        Me.lblTxCntSend = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnConnectSend = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtstatus1 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorker2 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker3 = New System.ComponentModel.BackgroundWorker()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.BackgroundWorker4 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker5 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker6 = New System.ComponentModel.BackgroundWorker()
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer5 = New System.Windows.Forms.Timer(Me.components)
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.SplitContainer5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer5.Panel1.SuspendLayout()
        Me.SplitContainer5.Panel2.SuspendLayout()
        Me.SplitContainer5.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        CType(Me.SplitContainer7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer7.Panel1.SuspendLayout()
        Me.SplitContainer7.Panel2.SuspendLayout()
        Me.SplitContainer7.SuspendLayout()
        CType(Me.SplitContainer6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer6.Panel1.SuspendLayout()
        Me.SplitContainer6.Panel2.SuspendLayout()
        Me.SplitContainer6.SuspendLayout()
        Me.TableLayoutPanel7.SuspendLayout()
        Me.TableLayoutPanel8.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel9.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.TableLayoutPanel10.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        CType(Me.SplitContainer4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbout
        '
        Me.lbout.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lbout.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbout.Font = New System.Drawing.Font("Courier New", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbout.FormattingEnabled = True
        Me.lbout.ItemHeight = 23
        Me.lbout.Location = New System.Drawing.Point(3, 28)
        Me.lbout.Name = "lbout"
        Me.lbout.Size = New System.Drawing.Size(123, 81)
        Me.lbout.TabIndex = 0
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusLabel_adapter, Me.StatusLabel_send, Me.StatusLabel_receive})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 720)
        Me.StatusStrip1.MinimumSize = New System.Drawing.Size(361, 22)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(480, 22)
        Me.StatusStrip1.TabIndex = 12
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'StatusLabel_adapter
        '
        Me.StatusLabel_adapter.BorderStyle = System.Windows.Forms.Border3DStyle.Raised
        Me.StatusLabel_adapter.Image = Global.AGVCommonCell.My.Resources.Resources.ledCornerGray
        Me.StatusLabel_adapter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.StatusLabel_adapter.Name = "StatusLabel_adapter"
        Me.StatusLabel_adapter.Size = New System.Drawing.Size(96, 17)
        Me.StatusLabel_adapter.Text = "adapter name"
        Me.StatusLabel_adapter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'StatusLabel_send
        '
        Me.StatusLabel_send.AutoSize = False
        Me.StatusLabel_send.Image = Global.AGVCommonCell.My.Resources.Resources.ledCornerGray
        Me.StatusLabel_send.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.StatusLabel_send.Name = "StatusLabel_send"
        Me.StatusLabel_send.Size = New System.Drawing.Size(70, 17)
        Me.StatusLabel_send.Text = "send data"
        '
        'StatusLabel_receive
        '
        Me.StatusLabel_receive.AutoSize = False
        Me.StatusLabel_receive.Image = Global.AGVCommonCell.My.Resources.Resources.ledCornerGray
        Me.StatusLabel_receive.Name = "StatusLabel_receive"
        Me.StatusLabel_receive.Size = New System.Drawing.Size(70, 17)
        Me.StatusLabel_receive.Text = "receive"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer4)
        Me.SplitContainer1.Size = New System.Drawing.Size(480, 720)
        Me.SplitContainer1.SplitterDistance = 583
        Me.SplitContainer1.TabIndex = 13
        '
        'SplitContainer2
        '
        Me.SplitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.SplitContainer5)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.TableLayoutPanel3)
        Me.SplitContainer2.Size = New System.Drawing.Size(478, 581)
        Me.SplitContainer2.SplitterDistance = 239
        Me.SplitContainer2.TabIndex = 3
        '
        'SplitContainer5
        '
        Me.SplitContainer5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer5.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer5.Name = "SplitContainer5"
        Me.SplitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer5.Panel1
        '
        Me.SplitContainer5.Panel1.Controls.Add(Me.TableLayoutPanel6)
        '
        'SplitContainer5.Panel2
        '
        Me.SplitContainer5.Panel2.Controls.Add(Me.SplitContainer7)
        Me.SplitContainer5.Size = New System.Drawing.Size(235, 577)
        Me.SplitContainer5.SplitterDistance = 112
        Me.SplitContainer5.TabIndex = 2
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.ColumnCount = 2
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.89362!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.10638!))
        Me.TableLayoutPanel6.Controls.Add(Me.LblIO1, 1, 1)
        Me.TableLayoutPanel6.Controls.Add(Me.lbout, 0, 1)
        Me.TableLayoutPanel6.Controls.Add(Me.Label8, 0, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.Label11, 1, 0)
        Me.TableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel6.Font = New System.Drawing.Font("Courier New", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 2
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 87.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(235, 112)
        Me.TableLayoutPanel6.TabIndex = 0
        '
        'LblIO1
        '
        Me.LblIO1.AutoSize = True
        Me.LblIO1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblIO1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblIO1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblIO1.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblIO1.Location = New System.Drawing.Point(132, 25)
        Me.LblIO1.Name = "LblIO1"
        Me.LblIO1.Size = New System.Drawing.Size(100, 87)
        Me.LblIO1.TabIndex = 14
        Me.LblIO1.Text = "WAIT KITTING"
        Me.LblIO1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Gold
        Me.Label8.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(3, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(123, 25)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "#Signal"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Gold
        Me.Label11.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(132, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(100, 25)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "# IO Status"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SplitContainer7
        '
        Me.SplitContainer7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer7.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer7.Name = "SplitContainer7"
        Me.SplitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer7.Panel1
        '
        Me.SplitContainer7.Panel1.Controls.Add(Me.SplitContainer6)
        '
        'SplitContainer7.Panel2
        '
        Me.SplitContainer7.Panel2.Controls.Add(Me.TableLayoutPanel1)
        Me.SplitContainer7.Size = New System.Drawing.Size(235, 461)
        Me.SplitContainer7.SplitterDistance = 225
        Me.SplitContainer7.TabIndex = 3
        '
        'SplitContainer6
        '
        Me.SplitContainer6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer6.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer6.Name = "SplitContainer6"
        Me.SplitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer6.Panel1
        '
        Me.SplitContainer6.Panel1.Controls.Add(Me.TableLayoutPanel7)
        '
        'SplitContainer6.Panel2
        '
        Me.SplitContainer6.Panel2.Controls.Add(Me.TableLayoutPanel8)
        Me.SplitContainer6.Size = New System.Drawing.Size(235, 225)
        Me.SplitContainer6.SplitterDistance = 110
        Me.SplitContainer6.TabIndex = 2
        '
        'TableLayoutPanel7
        '
        Me.TableLayoutPanel7.ColumnCount = 2
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.89362!))
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.10638!))
        Me.TableLayoutPanel7.Controls.Add(Me.lbout02, 0, 1)
        Me.TableLayoutPanel7.Controls.Add(Me.LblIO2, 1, 1)
        Me.TableLayoutPanel7.Controls.Add(Me.Label13, 0, 0)
        Me.TableLayoutPanel7.Controls.Add(Me.Label20, 1, 0)
        Me.TableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel7.Font = New System.Drawing.Font("Courier New", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel7.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel7.Name = "TableLayoutPanel7"
        Me.TableLayoutPanel7.RowCount = 2
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 81.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel7.Size = New System.Drawing.Size(235, 110)
        Me.TableLayoutPanel7.TabIndex = 0
        '
        'lbout02
        '
        Me.lbout02.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lbout02.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbout02.Font = New System.Drawing.Font("Courier New", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbout02.FormattingEnabled = True
        Me.lbout02.ItemHeight = 23
        Me.lbout02.Location = New System.Drawing.Point(3, 32)
        Me.lbout02.Name = "lbout02"
        Me.lbout02.Size = New System.Drawing.Size(123, 75)
        Me.lbout02.TabIndex = 16
        '
        'LblIO2
        '
        Me.LblIO2.AutoSize = True
        Me.LblIO2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblIO2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblIO2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblIO2.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblIO2.Location = New System.Drawing.Point(132, 29)
        Me.LblIO2.Name = "LblIO2"
        Me.LblIO2.Size = New System.Drawing.Size(100, 81)
        Me.LblIO2.TabIndex = 15
        Me.LblIO2.Text = "WAIT KITTING"
        Me.LblIO2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Label13.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(3, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(123, 29)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "#Signal"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Label20.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(132, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(100, 29)
        Me.Label20.TabIndex = 8
        Me.Label20.Text = "# IO Status"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel8
        '
        Me.TableLayoutPanel8.ColumnCount = 2
        Me.TableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.46809!))
        Me.TableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.53191!))
        Me.TableLayoutPanel8.Controls.Add(Me.LblIO3, 1, 1)
        Me.TableLayoutPanel8.Controls.Add(Me.lbout03, 0, 1)
        Me.TableLayoutPanel8.Controls.Add(Me.Label21, 0, 0)
        Me.TableLayoutPanel8.Controls.Add(Me.Label22, 1, 0)
        Me.TableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel8.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel8.Name = "TableLayoutPanel8"
        Me.TableLayoutPanel8.RowCount = 2
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 82.0!))
        Me.TableLayoutPanel8.Size = New System.Drawing.Size(235, 111)
        Me.TableLayoutPanel8.TabIndex = 0
        '
        'LblIO3
        '
        Me.LblIO3.AutoSize = True
        Me.LblIO3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.LblIO3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblIO3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblIO3.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblIO3.Location = New System.Drawing.Point(131, 29)
        Me.LblIO3.Name = "LblIO3"
        Me.LblIO3.Size = New System.Drawing.Size(101, 82)
        Me.LblIO3.TabIndex = 15
        Me.LblIO3.Text = "WAIT KITTING"
        Me.LblIO3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbout03
        '
        Me.lbout03.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbout03.Font = New System.Drawing.Font("Courier New", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbout03.FormattingEnabled = True
        Me.lbout03.ItemHeight = 23
        Me.lbout03.Location = New System.Drawing.Point(3, 32)
        Me.lbout03.Name = "lbout03"
        Me.lbout03.Size = New System.Drawing.Size(122, 76)
        Me.lbout03.TabIndex = 7
        '
        'Label21
        '
        Me.Label21.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.PaleGreen
        Me.Label21.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(3, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(122, 29)
        Me.Label21.TabIndex = 8
        Me.Label21.Text = "#Signal"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label22
        '
        Me.Label22.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.PaleGreen
        Me.Label22.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(131, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(101, 29)
        Me.Label22.TabIndex = 9
        Me.Label22.Text = "# IO Status"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel9, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 59.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 155.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(235, 232)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label2.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(4, 1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(227, 59)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "*****"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel9
        '
        Me.TableLayoutPanel9.ColumnCount = 1
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel9.Controls.Add(Me.Label23, 0, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.ListInQueue1, 0, 1)
        Me.TableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel9.Location = New System.Drawing.Point(4, 64)
        Me.TableLayoutPanel9.Name = "TableLayoutPanel9"
        Me.TableLayoutPanel9.RowCount = 2
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 123.0!))
        Me.TableLayoutPanel9.Size = New System.Drawing.Size(227, 164)
        Me.TableLayoutPanel9.TabIndex = 5
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label23.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label23.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label23.Location = New System.Drawing.Point(3, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(221, 41)
        Me.Label23.TabIndex = 9
        Me.Label23.Text = "# AGV Stand By"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ListInQueue1
        '
        Me.ListInQueue1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ListInQueue1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListInQueue1.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListInQueue1.FormattingEnabled = True
        Me.ListInQueue1.ItemHeight = 22
        Me.ListInQueue1.Location = New System.Drawing.Point(3, 44)
        Me.ListInQueue1.Name = "ListInQueue1"
        Me.ListInQueue1.Size = New System.Drawing.Size(221, 117)
        Me.ListInQueue1.TabIndex = 1
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 1
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Label3, 0, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.ListBox2, 0, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.TableLayoutPanel10, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label25, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.lblStaRoute, 0, 2)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 5
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 83.53553!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 127.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(231, 577)
        Me.TableLayoutPanel3.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label3.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(3, 404)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(225, 46)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "Keys Index"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ListBox2
        '
        Me.ListBox2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ListBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBox2.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 22
        Me.ListBox2.Location = New System.Drawing.Point(3, 453)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(225, 121)
        Me.ListBox2.TabIndex = 20
        '
        'TableLayoutPanel10
        '
        Me.TableLayoutPanel10.ColumnCount = 1
        Me.TableLayoutPanel10.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel10.Controls.Add(Me.TableLayoutPanel4, 0, 3)
        Me.TableLayoutPanel10.Controls.Add(Me.TstaTCPSignal, 0, 0)
        Me.TableLayoutPanel10.Controls.Add(Me.ListBox3, 0, 2)
        Me.TableLayoutPanel10.Controls.Add(Me.Label24, 0, 1)
        Me.TableLayoutPanel10.Controls.Add(Me.Label27, 0, 5)
        Me.TableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel10.Location = New System.Drawing.Point(3, 32)
        Me.TableLayoutPanel10.Name = "TableLayoutPanel10"
        Me.TableLayoutPanel10.RowCount = 6
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.46597!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 78.53403!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 118.0!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 11.0!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43.0!))
        Me.TableLayoutPanel10.Size = New System.Drawing.Size(225, 311)
        Me.TableLayoutPanel10.TabIndex = 21
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel4.ColumnCount = 6
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.87069!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.88675!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.24255!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 63.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.lblC3, 1, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label12, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.lblC2, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label10, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label7, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.lbltimeC1, 2, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.lbltimeC2, 2, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.lbltimeC3, 2, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.lblC1, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.lblCOC1, 3, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.lblCOC2, 3, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.lblCOC3, 3, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label15, 4, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label18, 4, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label19, 4, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.LblTIOC1, 5, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.LblTIOC2, 5, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.LblTIOC3, 5, 2)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(3, 141)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 3
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(219, 112)
        Me.TableLayoutPanel4.TabIndex = 4
        '
        'lblC3
        '
        Me.lblC3.AutoSize = True
        Me.lblC3.BackColor = System.Drawing.Color.Transparent
        Me.lblC3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblC3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblC3.Location = New System.Drawing.Point(32, 75)
        Me.lblC3.Name = "lblC3"
        Me.lblC3.Size = New System.Drawing.Size(16, 36)
        Me.lblC3.TabIndex = 21
        Me.lblC3.Text = "RR"
        Me.lblC3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label12
        '
        Me.Label12.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(4, 75)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(21, 36)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "Count Cell3:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblC2
        '
        Me.lblC2.AutoSize = True
        Me.lblC2.BackColor = System.Drawing.Color.Transparent
        Me.lblC2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblC2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblC2.Location = New System.Drawing.Point(32, 38)
        Me.lblC2.Name = "lblC2"
        Me.lblC2.Size = New System.Drawing.Size(16, 36)
        Me.lblC2.TabIndex = 19
        Me.lblC2.Text = "RR"
        Me.lblC2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label10
        '
        Me.Label10.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(4, 38)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(21, 36)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Count Cell2:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(4, 1)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(21, 36)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Count Cell1:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbltimeC1
        '
        Me.lbltimeC1.AutoSize = True
        Me.lbltimeC1.BackColor = System.Drawing.Color.Transparent
        Me.lbltimeC1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltimeC1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltimeC1.Location = New System.Drawing.Point(55, 1)
        Me.lbltimeC1.Name = "lbltimeC1"
        Me.lbltimeC1.Size = New System.Drawing.Size(13, 36)
        Me.lbltimeC1.TabIndex = 22
        Me.lbltimeC1.Text = "----"
        Me.lbltimeC1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbltimeC2
        '
        Me.lbltimeC2.AutoSize = True
        Me.lbltimeC2.BackColor = System.Drawing.Color.Transparent
        Me.lbltimeC2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltimeC2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltimeC2.Location = New System.Drawing.Point(55, 38)
        Me.lbltimeC2.Name = "lbltimeC2"
        Me.lbltimeC2.Size = New System.Drawing.Size(13, 36)
        Me.lbltimeC2.TabIndex = 23
        Me.lbltimeC2.Text = "----"
        Me.lbltimeC2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbltimeC3
        '
        Me.lbltimeC3.AutoSize = True
        Me.lbltimeC3.BackColor = System.Drawing.Color.Transparent
        Me.lbltimeC3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbltimeC3.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltimeC3.Location = New System.Drawing.Point(55, 75)
        Me.lbltimeC3.Name = "lbltimeC3"
        Me.lbltimeC3.Size = New System.Drawing.Size(13, 36)
        Me.lbltimeC3.TabIndex = 24
        Me.lbltimeC3.Text = "----"
        Me.lbltimeC3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblC1
        '
        Me.lblC1.AutoSize = True
        Me.lblC1.BackColor = System.Drawing.Color.Transparent
        Me.lblC1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblC1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblC1.Location = New System.Drawing.Point(32, 1)
        Me.lblC1.Name = "lblC1"
        Me.lblC1.Size = New System.Drawing.Size(16, 36)
        Me.lblC1.TabIndex = 17
        Me.lblC1.Text = "RR"
        Me.lblC1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCOC1
        '
        Me.lblCOC1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCOC1.AutoSize = True
        Me.lblCOC1.Location = New System.Drawing.Point(75, 1)
        Me.lblCOC1.Name = "lblCOC1"
        Me.lblCOC1.Size = New System.Drawing.Size(34, 36)
        Me.lblCOC1.TabIndex = 25
        Me.lblCOC1.Text = "****"
        Me.lblCOC1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCOC2
        '
        Me.lblCOC2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCOC2.AutoSize = True
        Me.lblCOC2.Location = New System.Drawing.Point(75, 38)
        Me.lblCOC2.Name = "lblCOC2"
        Me.lblCOC2.Size = New System.Drawing.Size(34, 36)
        Me.lblCOC2.TabIndex = 26
        Me.lblCOC2.Text = "****"
        Me.lblCOC2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCOC3
        '
        Me.lblCOC3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblCOC3.AutoSize = True
        Me.lblCOC3.Location = New System.Drawing.Point(75, 75)
        Me.lblCOC3.Name = "lblCOC3"
        Me.lblCOC3.Size = New System.Drawing.Size(34, 36)
        Me.lblCOC3.TabIndex = 27
        Me.lblCOC3.Text = "****"
        Me.lblCOC3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(116, 1)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(34, 36)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "****"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label18
        '
        Me.Label18.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(116, 38)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(34, 36)
        Me.Label18.TabIndex = 29
        Me.Label18.Text = "****"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(116, 75)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(34, 36)
        Me.Label19.TabIndex = 30
        Me.Label19.Text = "****"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblTIOC1
        '
        Me.LblTIOC1.AutoSize = True
        Me.LblTIOC1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblTIOC1.Font = New System.Drawing.Font("Courier New", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTIOC1.Location = New System.Drawing.Point(157, 1)
        Me.LblTIOC1.Name = "LblTIOC1"
        Me.LblTIOC1.Size = New System.Drawing.Size(58, 36)
        Me.LblTIOC1.TabIndex = 31
        Me.LblTIOC1.Text = "LblTIOC1"
        '
        'LblTIOC2
        '
        Me.LblTIOC2.AutoSize = True
        Me.LblTIOC2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblTIOC2.Font = New System.Drawing.Font("Courier New", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTIOC2.Location = New System.Drawing.Point(157, 38)
        Me.LblTIOC2.Name = "LblTIOC2"
        Me.LblTIOC2.Size = New System.Drawing.Size(58, 36)
        Me.LblTIOC2.TabIndex = 32
        Me.LblTIOC2.Text = "LblTIOC2"
        '
        'LblTIOC3
        '
        Me.LblTIOC3.AutoSize = True
        Me.LblTIOC3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblTIOC3.Font = New System.Drawing.Font("Courier New", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTIOC3.Location = New System.Drawing.Point(157, 75)
        Me.LblTIOC3.Name = "LblTIOC3"
        Me.LblTIOC3.Size = New System.Drawing.Size(58, 36)
        Me.LblTIOC3.TabIndex = 33
        Me.LblTIOC3.Text = "LblTIOC3"
        '
        'TstaTCPSignal
        '
        Me.TstaTCPSignal.AutoSize = True
        Me.TstaTCPSignal.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TstaTCPSignal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TstaTCPSignal.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TstaTCPSignal.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TstaTCPSignal.Location = New System.Drawing.Point(3, 0)
        Me.TstaTCPSignal.Name = "TstaTCPSignal"
        Me.TstaTCPSignal.Size = New System.Drawing.Size(219, 26)
        Me.TstaTCPSignal.TabIndex = 10
        Me.TstaTCPSignal.Text = "[00000.C0-0|###|00]"
        Me.TstaTCPSignal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ListBox3
        '
        Me.ListBox3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBox3.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.ItemHeight = 14
        Me.ListBox3.Location = New System.Drawing.Point(3, 44)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(219, 91)
        Me.ListBox3.TabIndex = 11
        '
        'Label24
        '
        Me.Label24.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.Label24.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(3, 26)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(219, 15)
        Me.Label24.TabIndex = 12
        Me.Label24.Text = "# TCP Receive Record"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(3, 267)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(45, 13)
        Me.Label27.TabIndex = 13
        Me.Label27.Text = "Label27"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label25.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label25.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label25.Location = New System.Drawing.Point(3, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(225, 29)
        Me.Label25.TabIndex = 22
        Me.Label25.Text = "Date#Time"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStaRoute
        '
        Me.lblStaRoute.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblStaRoute.AutoSize = True
        Me.lblStaRoute.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Bold)
        Me.lblStaRoute.Location = New System.Drawing.Point(3, 346)
        Me.lblStaRoute.Name = "lblStaRoute"
        Me.lblStaRoute.Size = New System.Drawing.Size(225, 58)
        Me.lblStaRoute.TabIndex = 23
        Me.lblStaRoute.Text = "*****"
        Me.lblStaRoute.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer4.Name = "SplitContainer4"
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.SplitContainer3)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.TableLayoutPanel2)
        Me.SplitContainer4.Size = New System.Drawing.Size(478, 131)
        Me.SplitContainer4.SplitterDistance = 346
        Me.SplitContainer4.TabIndex = 13
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.NumericUpDown2)
        Me.SplitContainer3.Panel1.Controls.Add(Me.CheckBox4)
        Me.SplitContainer3.Panel1.Controls.Add(Me.CheckBox3)
        Me.SplitContainer3.Panel1.Controls.Add(Me.Button5)
        Me.SplitContainer3.Panel1.Controls.Add(Me.NumericUpDown1)
        Me.SplitContainer3.Panel1.Controls.Add(Me.CheckBox2)
        Me.SplitContainer3.Panel1.Controls.Add(Me.ChkOK)
        Me.SplitContainer3.Panel1.Controls.Add(Me.CheckBox1)
        Me.SplitContainer3.Panel1.Controls.Add(Me.btnCLRF3)
        Me.SplitContainer3.Panel1.Controls.Add(Me.btnCLRF2)
        Me.SplitContainer3.Panel1.Controls.Add(Me.btnCLRF1)
        Me.SplitContainer3.Panel1.Controls.Add(Me.ChkCLRCLRKEY)
        Me.SplitContainer3.Panel1.Controls.Add(Me.Label26)
        Me.SplitContainer3.Panel1.Controls.Add(Me.Button4)
        Me.SplitContainer3.Panel1.Controls.Add(Me.Button3)
        Me.SplitContainer3.Panel1.Controls.Add(Me.Button2)
        Me.SplitContainer3.Panel1.Controls.Add(Me.ChkC03)
        Me.SplitContainer3.Panel1.Controls.Add(Me.ChkC01)
        Me.SplitContainer3.Panel1.Controls.Add(Me.Button1)
        Me.SplitContainer3.Panel1.Controls.Add(Me.btn_clear)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.TableLayoutPanel5)
        Me.SplitContainer3.Size = New System.Drawing.Size(346, 131)
        Me.SplitContainer3.SplitterDistance = 224
        Me.SplitContainer3.TabIndex = 13
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.BackColor = System.Drawing.Color.Transparent
        Me.CheckBox3.Location = New System.Drawing.Point(180, 106)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(33, 17)
        Me.CheckBox3.TabIndex = 30
        Me.CheckBox3.Text = "C"
        Me.CheckBox3.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(173, 76)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(45, 23)
        Me.Button5.TabIndex = 29
        Me.Button5.Text = "save"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(182, 3)
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(39, 20)
        Me.NumericUpDown1.TabIndex = 28
        Me.NumericUpDown1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.BackColor = System.Drawing.Color.Transparent
        Me.CheckBox2.Checked = True
        Me.CheckBox2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.Location = New System.Drawing.Point(163, 22)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(54, 16)
        Me.CheckBox2.TabIndex = 27
        Me.CheckBox2.Text = "DELAY"
        Me.CheckBox2.UseVisualStyleBackColor = False
        '
        'ChkOK
        '
        Me.ChkOK.AutoSize = True
        Me.ChkOK.Location = New System.Drawing.Point(87, 25)
        Me.ChkOK.Name = "ChkOK"
        Me.ChkOK.Size = New System.Drawing.Size(60, 17)
        Me.ChkOK.TabIndex = 26
        Me.ChkOK.Text = "ChkOK"
        Me.ChkOK.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.BackColor = System.Drawing.Color.Transparent
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Location = New System.Drawing.Point(5, 25)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(88, 17)
        Me.CheckBox1.TabIndex = 25
        Me.CheckBox1.Text = "CLR FLag IO"
        Me.CheckBox1.UseVisualStyleBackColor = False
        '
        'btnCLRF3
        '
        Me.btnCLRF3.BackColor = System.Drawing.Color.DarkTurquoise
        Me.btnCLRF3.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCLRF3.Location = New System.Drawing.Point(119, 77)
        Me.btnCLRF3.Name = "btnCLRF3"
        Me.btnCLRF3.Size = New System.Drawing.Size(50, 22)
        Me.btnCLRF3.TabIndex = 24
        Me.btnCLRF3.Text = "CLR F3"
        Me.btnCLRF3.UseVisualStyleBackColor = False
        '
        'btnCLRF2
        '
        Me.btnCLRF2.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.btnCLRF2.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCLRF2.Location = New System.Drawing.Point(66, 77)
        Me.btnCLRF2.Name = "btnCLRF2"
        Me.btnCLRF2.Size = New System.Drawing.Size(50, 22)
        Me.btnCLRF2.TabIndex = 23
        Me.btnCLRF2.Text = "CLR F2"
        Me.btnCLRF2.UseVisualStyleBackColor = False
        '
        'btnCLRF1
        '
        Me.btnCLRF1.BackColor = System.Drawing.Color.Gold
        Me.btnCLRF1.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCLRF1.Location = New System.Drawing.Point(12, 77)
        Me.btnCLRF1.Name = "btnCLRF1"
        Me.btnCLRF1.Size = New System.Drawing.Size(50, 22)
        Me.btnCLRF1.TabIndex = 22
        Me.btnCLRF1.Text = "CLR F1"
        Me.btnCLRF1.UseVisualStyleBackColor = False
        '
        'ChkCLRCLRKEY
        '
        Me.ChkCLRCLRKEY.AutoSize = True
        Me.ChkCLRCLRKEY.BackColor = System.Drawing.Color.Transparent
        Me.ChkCLRCLRKEY.Checked = True
        Me.ChkCLRCLRKEY.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkCLRCLRKEY.Location = New System.Drawing.Point(137, 2)
        Me.ChkCLRCLRKEY.Name = "ChkCLRCLRKEY"
        Me.ChkCLRCLRKEY.Size = New System.Drawing.Size(40, 17)
        Me.ChkCLRCLRKEY.TabIndex = 21
        Me.ChkCLRCLRKEY.Text = "CK"
        Me.ChkCLRCLRKEY.UseVisualStyleBackColor = False
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(0, 2)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(51, 13)
        Me.Label26.TabIndex = 20
        Me.Label26.Text = "Manual ::"
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.DarkTurquoise
        Me.Button4.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(120, 101)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(50, 22)
        Me.Button4.TabIndex = 19
        Me.Button4.Text = "CLR S3"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Button3.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(67, 101)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(50, 22)
        Me.Button3.TabIndex = 18
        Me.Button3.Text = "CLR S2"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(11, 49)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(40, 26)
        Me.Button2.TabIndex = 17
        Me.Button2.Text = "CLR KEY"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'ChkC03
        '
        Me.ChkC03.AutoSize = True
        Me.ChkC03.BackColor = System.Drawing.Color.Transparent
        Me.ChkC03.Checked = True
        Me.ChkC03.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkC03.Location = New System.Drawing.Point(95, 2)
        Me.ChkC03.Name = "ChkC03"
        Me.ChkC03.Size = New System.Drawing.Size(45, 17)
        Me.ChkC03.TabIndex = 15
        Me.ChkC03.Text = "C03"
        Me.ChkC03.UseVisualStyleBackColor = False
        '
        'ChkC01
        '
        Me.ChkC01.AutoSize = True
        Me.ChkC01.BackColor = System.Drawing.Color.Transparent
        Me.ChkC01.Location = New System.Drawing.Point(55, 2)
        Me.ChkC01.Name = "ChkC01"
        Me.ChkC01.Size = New System.Drawing.Size(45, 17)
        Me.ChkC01.TabIndex = 14
        Me.ChkC01.Text = "C01"
        Me.ChkC01.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Gold
        Me.Button1.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(13, 101)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(50, 22)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "CLR S1"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'btn_clear
        '
        Me.btn_clear.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_clear.Location = New System.Drawing.Point(55, 49)
        Me.btn_clear.Name = "btn_clear"
        Me.btn_clear.Size = New System.Drawing.Size(92, 26)
        Me.btn_clear.TabIndex = 12
        Me.btn_clear.Text = "clear AGV First Queue"
        Me.btn_clear.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel5.ColumnCount = 2
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.Label1, 0, 2)
        Me.TableLayoutPanel5.Controls.Add(Me.lblGetportrcv, 1, 2)
        Me.TableLayoutPanel5.Controls.Add(Me.lblRXCount, 1, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.Label4, 0, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.btnConnectRCV, 1, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.Label14, 0, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.status0, 1, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label17, 0, 0)
        Me.TableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 4
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(118, 131)
        Me.TableLayoutPanel5.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 25)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Com NO."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblGetportrcv
        '
        Me.lblGetportrcv.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblGetportrcv.AutoSize = True
        Me.lblGetportrcv.BackColor = System.Drawing.Color.Transparent
        Me.lblGetportrcv.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGetportrcv.Location = New System.Drawing.Point(56, 53)
        Me.lblGetportrcv.Name = "lblGetportrcv"
        Me.lblGetportrcv.Size = New System.Drawing.Size(58, 25)
        Me.lblGetportrcv.TabIndex = 13
        Me.lblGetportrcv.Text = "com1"
        Me.lblGetportrcv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRXCount
        '
        Me.lblRXCount.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblRXCount.AutoSize = True
        Me.lblRXCount.BackColor = System.Drawing.Color.Transparent
        Me.lblRXCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRXCount.Location = New System.Drawing.Point(56, 27)
        Me.lblRXCount.Name = "lblRXCount"
        Me.lblRXCount.Size = New System.Drawing.Size(58, 25)
        Me.lblRXCount.TabIndex = 11
        Me.lblRXCount.Text = "00000"
        Me.lblRXCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(4, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 25)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "RX Count:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnConnectRCV
        '
        Me.btnConnectRCV.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnConnectRCV.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConnectRCV.Location = New System.Drawing.Point(56, 82)
        Me.btnConnectRCV.Name = "btnConnectRCV"
        Me.btnConnectRCV.Size = New System.Drawing.Size(58, 45)
        Me.btnConnectRCV.TabIndex = 3
        Me.btnConnectRCV.Text = "*connect*"
        Me.btnConnectRCV.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.LightGray
        Me.Label14.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(4, 79)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(45, 51)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "[1]RCV PORT:"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'status0
        '
        Me.status0.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.status0.AutoSize = True
        Me.status0.BackColor = System.Drawing.Color.Transparent
        Me.status0.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.status0.Location = New System.Drawing.Point(56, 1)
        Me.status0.Name = "status0"
        Me.status0.Size = New System.Drawing.Size(58, 25)
        Me.status0.TabIndex = 14
        Me.status0.Text = "null"
        Me.status0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(4, 1)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(45, 25)
        Me.Label17.TabIndex = 15
        Me.Label17.Text = "Status:"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Label9, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.lblGetportSend, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.lblTxCntSend, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label5, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.btnConnectSend, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Label6, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.txtstatus1, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label16, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 4
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(128, 131)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(4, 53)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(50, 25)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Com NO."
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblGetportSend
        '
        Me.lblGetportSend.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblGetportSend.AutoSize = True
        Me.lblGetportSend.BackColor = System.Drawing.Color.Transparent
        Me.lblGetportSend.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGetportSend.Location = New System.Drawing.Point(61, 53)
        Me.lblGetportSend.Name = "lblGetportSend"
        Me.lblGetportSend.Size = New System.Drawing.Size(63, 25)
        Me.lblGetportSend.TabIndex = 13
        Me.lblGetportSend.Text = "com1"
        Me.lblGetportSend.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTxCntSend
        '
        Me.lblTxCntSend.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTxCntSend.AutoSize = True
        Me.lblTxCntSend.BackColor = System.Drawing.Color.Transparent
        Me.lblTxCntSend.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTxCntSend.Location = New System.Drawing.Point(61, 27)
        Me.lblTxCntSend.Name = "lblTxCntSend"
        Me.lblTxCntSend.Size = New System.Drawing.Size(63, 25)
        Me.lblTxCntSend.TabIndex = 11
        Me.lblTxCntSend.Text = "00000"
        Me.lblTxCntSend.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 25)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "RX Count:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnConnectSend
        '
        Me.btnConnectSend.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnConnectSend.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConnectSend.Location = New System.Drawing.Point(61, 82)
        Me.btnConnectSend.Name = "btnConnectSend"
        Me.btnConnectSend.Size = New System.Drawing.Size(63, 45)
        Me.btnConnectSend.TabIndex = 3
        Me.btnConnectSend.Text = "*connect*"
        Me.btnConnectSend.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.LightGray
        Me.Label6.Font = New System.Drawing.Font("Arial", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(4, 79)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(50, 51)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "[2SEND PORT:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtstatus1
        '
        Me.txtstatus1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtstatus1.AutoSize = True
        Me.txtstatus1.BackColor = System.Drawing.Color.Transparent
        Me.txtstatus1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstatus1.Location = New System.Drawing.Point(61, 1)
        Me.txtstatus1.Name = "txtstatus1"
        Me.txtstatus1.Size = New System.Drawing.Size(63, 25)
        Me.txtstatus1.TabIndex = 14
        Me.txtstatus1.Text = "null"
        Me.txtstatus1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(4, 1)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(50, 25)
        Me.Label16.TabIndex = 15
        Me.Label16.Text = "Status:"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'BackgroundWorker1
        '
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 2000
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 60000
        '
        'Timer3
        '
        Me.Timer3.Enabled = True
        Me.Timer3.Interval = 1000
        '
        'BackgroundWorker4
        '
        '
        'BackgroundWorker5
        '
        '
        'Timer4
        '
        Me.Timer4.Enabled = True
        '
        'Timer5
        '
        Me.Timer5.Enabled = True
        Me.Timer5.Interval = 1000
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.BackColor = System.Drawing.Color.Transparent
        Me.CheckBox4.Checked = True
        Me.CheckBox4.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox4.Location = New System.Drawing.Point(164, 58)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(59, 16)
        Me.CheckBox4.TabIndex = 31
        Me.CheckBox4.Text = "DELAY2"
        Me.CheckBox4.UseVisualStyleBackColor = False
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.Location = New System.Drawing.Point(182, 39)
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(38, 20)
        Me.NumericUpDown2.TabIndex = 32
        Me.NumericUpDown2.Value = New Decimal(New Integer() {2, 0, 0, 0})
        '
        'mainChat
        '
        Me.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(480, 742)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Name = "mainChat"
        Me.Text = "TCP Chat V1.0 -AGV Common Cell -2017"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.SplitContainer5.Panel1.ResumeLayout(False)
        Me.SplitContainer5.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer5.ResumeLayout(False)
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.TableLayoutPanel6.PerformLayout()
        Me.SplitContainer7.Panel1.ResumeLayout(False)
        Me.SplitContainer7.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer7.ResumeLayout(False)
        Me.SplitContainer6.Panel1.ResumeLayout(False)
        Me.SplitContainer6.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer6.ResumeLayout(False)
        Me.TableLayoutPanel7.ResumeLayout(False)
        Me.TableLayoutPanel7.PerformLayout()
        Me.TableLayoutPanel8.ResumeLayout(False)
        Me.TableLayoutPanel8.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.TableLayoutPanel9.ResumeLayout(False)
        Me.TableLayoutPanel9.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.TableLayoutPanel10.ResumeLayout(False)
        Me.TableLayoutPanel10.PerformLayout()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer4.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.PerformLayout()
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.TableLayoutPanel5.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbout As System.Windows.Forms.ListBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents StatusLabel_adapter As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusLabel_send As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusLabel_receive As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents btn_clear As System.Windows.Forms.Button
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents SplitContainer4 As SplitContainer
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Label9 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents lblGetportSend As Label
    Friend WithEvents lblTxCntSend As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents btnConnectSend As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents txtstatus1 As Label
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents ListInQueue1 As ListBox
    Friend WithEvents SplitContainer3 As SplitContainer
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents lblGetportrcv As Label
    Friend WithEvents lblRXCount As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents btnConnectRCV As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents status0 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents Button1 As Button
    Friend WithEvents ChkC03 As CheckBox
    Friend WithEvents ChkC01 As CheckBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents Button2 As Button
    Friend WithEvents lbout03 As ListBox
    Friend WithEvents SplitContainer5 As SplitContainer
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
    Friend WithEvents SplitContainer6 As SplitContainer
    Friend WithEvents TableLayoutPanel7 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel8 As TableLayoutPanel
    Friend WithEvents Label8 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents SplitContainer7 As SplitContainer
    Friend WithEvents Label13 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents LblIO1 As Label
    Friend WithEvents LblIO2 As Label
    Friend WithEvents LblIO3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents Label23 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents BackgroundWorker2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker3 As System.ComponentModel.BackgroundWorker
    Friend WithEvents lbout02 As ListBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Label26 As Label
    Friend WithEvents ChkCLRCLRKEY As CheckBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Timer3 As Timer
    Friend WithEvents btnCLRF3 As Button
    Friend WithEvents btnCLRF2 As Button
    Friend WithEvents btnCLRF1 As Button
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents lblStaRoute As Label
    Friend WithEvents ChkOK As CheckBox
    Friend WithEvents BackgroundWorker4 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker5 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker6 As System.ComponentModel.BackgroundWorker
    Friend WithEvents Timer4 As Timer
    Friend WithEvents TableLayoutPanel10 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents lblC3 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblC2 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lbltimeC1 As Label
    Friend WithEvents lbltimeC2 As Label
    Friend WithEvents lbltimeC3 As Label
    Friend WithEvents lblC1 As Label
    Friend WithEvents lblCOC1 As Label
    Friend WithEvents lblCOC2 As Label
    Friend WithEvents lblCOC3 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents LblTIOC1 As Label
    Friend WithEvents LblTIOC2 As Label
    Friend WithEvents LblTIOC3 As Label
    Friend WithEvents TstaTCPSignal As Label
    Friend WithEvents ListBox3 As ListBox
    Friend WithEvents Label24 As Label
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents Button5 As Button
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Timer5 As Timer
    Friend WithEvents NumericUpDown2 As NumericUpDown
    Friend WithEvents CheckBox4 As CheckBox
End Class
