﻿Option Explicit On
Option Strict On

'Imports System.Windows.Forms.Label
Public Class Form2
    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        If ToolStripTextBox1.Text = "http://pdem-db-test:1111/?m1=maps" Then
            Exit Sub
        End If
        WebBrowser1.Navigate(ToolStripTextBox1.Text)
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        WebBrowser1.Navigate(ToolStripTextBox1.Text)
        '  Me.AutoSizeMode = CType(True, AutoSizeMode)
    End Sub
End Class
