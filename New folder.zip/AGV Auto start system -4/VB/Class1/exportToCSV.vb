﻿Public Class exportToCSV
    Shared Sub export(ByVal dgv As DataGridView)
        Try
            Dim StrExport As String = ""
            For Each C As DataGridViewColumn In dgv.Columns
                StrExport &= """" & C.HeaderText & ""","
            Next
            StrExport = StrExport.Substring(0, StrExport.Length - 1)
            StrExport &= Environment.NewLine

            For Each R As DataGridViewRow In dgv.Rows
                For Each C As DataGridViewCell In R.Cells
                    If Not C.Value Is Nothing Then
                        StrExport &= """" & C.Value.ToString & ""","
                    Else
                        StrExport &= """" & "" & ""","
                    End If
                Next
                StrExport = StrExport.Substring(0, StrExport.Length - 1)
                StrExport &= Environment.NewLine
            Next
            '   File.AppendText(path & "_" & (DateTime.Now.ToShortDateString().Replace("/", "-")) & ".txt")
            Dim tw As IO.TextWriter = New IO.StreamWriter("D:\IprojectDB\Start Record\" & (DateTime.Now.ToShortDateString().Replace("/", "-")) & ".csv")
            tw.Write(StrExport)
            tw.Close()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub
End Class
