﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.toolstripRX = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel5 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnClearReceiveBox = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnSaveFileFromRxBox = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblRxCnt = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.statusRX = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.toolstripComPort = New System.Windows.Forms.ToolStrip()
        Me.statusC = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.toolstripRX.SuspendLayout()
        Me.toolstripComPort.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'toolstripRX
        '
        Me.toolstripRX.Dock = System.Windows.Forms.DockStyle.None
        Me.toolstripRX.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel5, Me.ToolStripSeparator2, Me.btnClearReceiveBox, Me.ToolStripSeparator3, Me.btnSaveFileFromRxBox, Me.ToolStripSeparator9, Me.lblRxCnt, Me.ToolStripSeparator10, Me.statusRX, Me.ToolStripSeparator11})
        Me.toolstripRX.Location = New System.Drawing.Point(0, 25)
        Me.toolstripRX.Name = "toolstripRX"
        Me.toolstripRX.Size = New System.Drawing.Size(247, 25)
        Me.toolstripRX.TabIndex = 182
        Me.toolstripRX.Text = "ToolStrip2"
        '
        'ToolStripLabel5
        '
        Me.ToolStripLabel5.Name = "ToolStripLabel5"
        Me.ToolStripLabel5.Size = New System.Drawing.Size(69, 22)
        Me.ToolStripLabel5.Text = "Receive box"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'btnClearReceiveBox
        '
        Me.btnClearReceiveBox.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnClearReceiveBox.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnClearReceiveBox.Name = "btnClearReceiveBox"
        Me.btnClearReceiveBox.Size = New System.Drawing.Size(23, 22)
        Me.btnClearReceiveBox.ToolTipText = "clear received box"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'btnSaveFileFromRxBox
        '
        Me.btnSaveFileFromRxBox.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnSaveFileFromRxBox.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnSaveFileFromRxBox.Name = "btnSaveFileFromRxBox"
        Me.btnSaveFileFromRxBox.Size = New System.Drawing.Size(23, 22)
        Me.btnSaveFileFromRxBox.ToolTipText = "save output to textfile"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'lblRxCnt
        '
        Me.lblRxCnt.Name = "lblRxCnt"
        Me.lblRxCnt.Size = New System.Drawing.Size(37, 22)
        Me.lblRxCnt.Text = "00000"
        Me.lblRxCnt.ToolTipText = "count bytes received"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 25)
        '
        'statusRX
        '
        Me.statusRX.AutoSize = False
        Me.statusRX.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.statusRX.Name = "statusRX"
        Me.statusRX.Size = New System.Drawing.Size(53, 22)
        Me.statusRX.Text = "status"
        Me.statusRX.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.statusRX.ToolTipText = "receive status"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(6, 25)
        '
        'toolstripComPort
        '
        Me.toolstripComPort.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.statusC, Me.ToolStripTextBox1, Me.ToolStripButton1})
        Me.toolstripComPort.Location = New System.Drawing.Point(0, 0)
        Me.toolstripComPort.Name = "toolstripComPort"
        Me.toolstripComPort.Size = New System.Drawing.Size(859, 25)
        Me.toolstripComPort.TabIndex = 180
        Me.toolstripComPort.Text = "ToolStrip1"
        '
        'statusC
        '
        Me.statusC.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.statusC.Name = "statusC"
        Me.statusC.Size = New System.Drawing.Size(0, 22)
        Me.statusC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.statusC.ToolTipText = "connection state"
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(400, 25)
        Me.ToolStripTextBox1.Text = "http://pdem-db-test:1111/?m1=maps"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton1.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(31, 22)
        Me.ToolStripButton1.Text = "GO!"
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 25)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(859, 331)
        Me.WebBrowser1.TabIndex = 184
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(859, 356)
        Me.PictureBox1.TabIndex = 183
        Me.PictureBox1.TabStop = False
        '
        'Form2
        '
        Me.AllowDrop = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange
        Me.ClientSize = New System.Drawing.Size(859, 356)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.toolstripRX)
        Me.Controls.Add(Me.toolstripComPort)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form2"
        Me.toolstripRX.ResumeLayout(False)
        Me.toolstripRX.PerformLayout()
        Me.toolstripComPort.ResumeLayout(False)
        Me.toolstripComPort.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Timer1 As Timer
    Friend WithEvents toolstripRX As ToolStrip
    Friend WithEvents ToolStripLabel5 As ToolStripLabel
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents btnClearReceiveBox As ToolStripButton
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents btnSaveFileFromRxBox As ToolStripButton
    Friend WithEvents ToolStripSeparator9 As ToolStripSeparator
    Friend WithEvents lblRxCnt As ToolStripLabel
    Friend WithEvents ToolStripSeparator10 As ToolStripSeparator
    Friend WithEvents statusRX As ToolStripLabel
    Friend WithEvents ToolStripSeparator11 As ToolStripSeparator
    Friend WithEvents toolstripComPort As ToolStrip
    Friend WithEvents statusC As ToolStripLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents WebBrowser1 As WebBrowser
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents ToolStripButton1 As ToolStripButton
End Class
