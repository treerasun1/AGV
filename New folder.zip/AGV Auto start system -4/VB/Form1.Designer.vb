﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.tstexport = New System.Windows.Forms.ToolStripButton()
        Me.tstrun = New System.Windows.Forms.ToolStripButton()
        Me.tstaddmc = New System.Windows.Forms.ToolStripDropDownButton()
        Me.ADDMACHINEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ADDERRNAMEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ADDPositionDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PositionSetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PositionTableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REFRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MANUALCONTROLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tstsetting = New System.Windows.Forms.ToolStripDropDownButton()
        Me.SizePictureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.Size1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Size2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.trtxtSizeHW = New System.Windows.Forms.ToolStripMenuItem()
        Me.trtxtSizeH = New System.Windows.Forms.ToolStripTextBox()
        Me.trtxtSizeW = New System.Windows.Forms.ToolStripTextBox()
        Me.ENTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SETTIMEAUTOSTARTLOOPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.txttooltimeloop = New System.Windows.Forms.ToolStripTextBox()
        Me.tbtSETTIMESecToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CHANGLAOUTPICTUREToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(3, 3)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(1326, 710)
        Me.SplitContainer1.SplitterDistance = 426
        Me.SplitContainer1.TabIndex = 36
        '
        'SplitContainer2
        '
        Me.SplitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.ToolStrip1)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.Button2)
        Me.SplitContainer2.Size = New System.Drawing.Size(426, 710)
        Me.SplitContainer2.SplitterDistance = 130
        Me.SplitContainer2.TabIndex = 0
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.BackColor = System.Drawing.Color.Gainsboro
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tstexport, Me.tstrun, Me.tstaddmc, Me.tstsetting})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(422, 63)
        Me.ToolStrip1.TabIndex = 35
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'tstexport
        '
        Me.tstexport.AutoSize = False
        Me.tstexport.Image = CType(resources.GetObject("tstexport.Image"), System.Drawing.Image)
        Me.tstexport.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tstexport.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tstexport.Name = "tstexport"
        Me.tstexport.Size = New System.Drawing.Size(101, 60)
        Me.tstexport.Text = "Export Data"
        Me.tstexport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tstrun
        '
        Me.tstrun.AutoSize = False
        Me.tstrun.Image = CType(resources.GetObject("tstrun.Image"), System.Drawing.Image)
        Me.tstrun.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tstrun.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tstrun.Name = "tstrun"
        Me.tstrun.Size = New System.Drawing.Size(101, 60)
        Me.tstrun.Text = "Autostart"
        Me.tstrun.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tstaddmc
        '
        Me.tstaddmc.AutoSize = False
        Me.tstaddmc.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ADDMACHINEToolStripMenuItem, Me.ADDERRNAMEToolStripMenuItem, Me.ADDPositionDataToolStripMenuItem, Me.REFRToolStripMenuItem, Me.MANUALCONTROLToolStripMenuItem})
        Me.tstaddmc.Image = CType(resources.GetObject("tstaddmc.Image"), System.Drawing.Image)
        Me.tstaddmc.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tstaddmc.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tstaddmc.Name = "tstaddmc"
        Me.tstaddmc.Size = New System.Drawing.Size(101, 60)
        Me.tstaddmc.Text = "Add DATA"
        Me.tstaddmc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.tstaddmc.ToolTipText = "Add machine"
        '
        'ADDMACHINEToolStripMenuItem
        '
        Me.ADDMACHINEToolStripMenuItem.Name = "ADDMACHINEToolStripMenuItem"
        Me.ADDMACHINEToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.ADDMACHINEToolStripMenuItem.Text = "ADD  ADDRESS"
        '
        'ADDERRNAMEToolStripMenuItem
        '
        Me.ADDERRNAMEToolStripMenuItem.Name = "ADDERRNAMEToolStripMenuItem"
        Me.ADDERRNAMEToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.ADDERRNAMEToolStripMenuItem.Text = "SET ERR MESSAGE"
        '
        'ADDPositionDataToolStripMenuItem
        '
        Me.ADDPositionDataToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PositionSetToolStripMenuItem, Me.PositionTableToolStripMenuItem})
        Me.ADDPositionDataToolStripMenuItem.Name = "ADDPositionDataToolStripMenuItem"
        Me.ADDPositionDataToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.ADDPositionDataToolStripMenuItem.Text = "SET POSITION "
        '
        'PositionSetToolStripMenuItem
        '
        Me.PositionSetToolStripMenuItem.Name = "PositionSetToolStripMenuItem"
        Me.PositionSetToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.PositionSetToolStripMenuItem.Text = "Position Set"
        '
        'PositionTableToolStripMenuItem
        '
        Me.PositionTableToolStripMenuItem.Name = "PositionTableToolStripMenuItem"
        Me.PositionTableToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.PositionTableToolStripMenuItem.Text = "Position Table"
        '
        'REFRToolStripMenuItem
        '
        Me.REFRToolStripMenuItem.Name = "REFRToolStripMenuItem"
        Me.REFRToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.REFRToolStripMenuItem.Text = "REFRESH  VALUE"
        '
        'MANUALCONTROLToolStripMenuItem
        '
        Me.MANUALCONTROLToolStripMenuItem.Name = "MANUALCONTROLToolStripMenuItem"
        Me.MANUALCONTROLToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.MANUALCONTROLToolStripMenuItem.Text = "MANUAL  CONTROL"
        '
        'tstsetting
        '
        Me.tstsetting.AutoSize = False
        Me.tstsetting.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SizePictureToolStripMenuItem, Me.SETTIMEAUTOSTARTLOOPToolStripMenuItem, Me.CHANGLAOUTPICTUREToolStripMenuItem})
        Me.tstsetting.Image = CType(resources.GetObject("tstsetting.Image"), System.Drawing.Image)
        Me.tstsetting.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tstsetting.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tstsetting.Name = "tstsetting"
        Me.tstsetting.Size = New System.Drawing.Size(101, 60)
        Me.tstsetting.Text = "Setting"
        Me.tstsetting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'SizePictureToolStripMenuItem
        '
        Me.SizePictureToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator1, Me.ToolStripSeparator2, Me.Size1ToolStripMenuItem, Me.Size2ToolStripMenuItem, Me.trtxtSizeHW})
        Me.SizePictureToolStripMenuItem.Name = "SizePictureToolStripMenuItem"
        Me.SizePictureToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.SizePictureToolStripMenuItem.Text = "SET PICTURE SIZE"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(159, 6)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(159, 6)
        '
        'Size1ToolStripMenuItem
        '
        Me.Size1ToolStripMenuItem.Name = "Size1ToolStripMenuItem"
        Me.Size1ToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.Size1ToolStripMenuItem.Text = "size1(1920X1049)"
        '
        'Size2ToolStripMenuItem
        '
        Me.Size2ToolStripMenuItem.Name = "Size2ToolStripMenuItem"
        Me.Size2ToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.Size2ToolStripMenuItem.Text = "size2 (  )"
        '
        'trtxtSizeHW
        '
        Me.trtxtSizeHW.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.trtxtSizeH, Me.trtxtSizeW, Me.ENTToolStripMenuItem})
        Me.trtxtSizeHW.Name = "trtxtSizeHW"
        Me.trtxtSizeHW.Size = New System.Drawing.Size(162, 22)
        Me.trtxtSizeHW.Text = "Other"
        '
        'trtxtSizeH
        '
        Me.trtxtSizeH.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.trtxtSizeH.Name = "trtxtSizeH"
        Me.trtxtSizeH.Size = New System.Drawing.Size(100, 23)
        Me.trtxtSizeH.Tag = ""
        '
        'trtxtSizeW
        '
        Me.trtxtSizeW.BackColor = System.Drawing.Color.Silver
        Me.trtxtSizeW.Name = "trtxtSizeW"
        Me.trtxtSizeW.Size = New System.Drawing.Size(100, 23)
        '
        'ENTToolStripMenuItem
        '
        Me.ENTToolStripMenuItem.Name = "ENTToolStripMenuItem"
        Me.ENTToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.ENTToolStripMenuItem.Text = "ENT"
        '
        'SETTIMEAUTOSTARTLOOPToolStripMenuItem
        '
        Me.SETTIMEAUTOSTARTLOOPToolStripMenuItem.BackColor = System.Drawing.Color.LawnGreen
        Me.SETTIMEAUTOSTARTLOOPToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.txttooltimeloop, Me.tbtSETTIMESecToolStripMenuItem})
        Me.SETTIMEAUTOSTARTLOOPToolStripMenuItem.Name = "SETTIMEAUTOSTARTLOOPToolStripMenuItem"
        Me.SETTIMEAUTOSTARTLOOPToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.SETTIMEAUTOSTARTLOOPToolStripMenuItem.Text = "SET TIME AUTO START LOOP"
        '
        'txttooltimeloop
        '
        Me.txttooltimeloop.BackColor = System.Drawing.Color.LimeGreen
        Me.txttooltimeloop.Name = "txttooltimeloop"
        Me.txttooltimeloop.Size = New System.Drawing.Size(100, 23)
        Me.txttooltimeloop.Text = "70"
        '
        'tbtSETTIMESecToolStripMenuItem
        '
        Me.tbtSETTIMESecToolStripMenuItem.Name = "tbtSETTIMESecToolStripMenuItem"
        Me.tbtSETTIMESecToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.tbtSETTIMESecToolStripMenuItem.Text = "SET TIME (Sec.)"
        '
        'CHANGLAOUTPICTUREToolStripMenuItem
        '
        Me.CHANGLAOUTPICTUREToolStripMenuItem.Name = "CHANGLAOUTPICTUREToolStripMenuItem"
        Me.CHANGLAOUTPICTUREToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.CHANGLAOUTPICTUREToolStripMenuItem.Text = "CHANG LAOUT PICTURE"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1340, 742)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.SplitContainer1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1332, 716)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "AGV Control"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Panel1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1332, 716)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "AGV Up Time"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1326, 710)
        Me.Panel1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(6, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Open Form"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(291, 44)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 0
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1340, 742)
        Me.Controls.Add(Me.TabControl1)
        Me.IsMdiContainer = True
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents tstexport As ToolStripButton
    Friend WithEvents tstrun As ToolStripButton
    Friend WithEvents tstaddmc As ToolStripDropDownButton
    Friend WithEvents ADDMACHINEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ADDERRNAMEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ADDPositionDataToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PositionSetToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PositionTableToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents REFRToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MANUALCONTROLToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents tstsetting As ToolStripDropDownButton
    Friend WithEvents SizePictureToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents Size1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Size2ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents trtxtSizeHW As ToolStripMenuItem
    Friend WithEvents trtxtSizeH As ToolStripTextBox
    Friend WithEvents trtxtSizeW As ToolStripTextBox
    Friend WithEvents ENTToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SETTIMEAUTOSTARTLOOPToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents txttooltimeloop As ToolStripTextBox
    Friend WithEvents tbtSETTIMESecToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CHANGLAOUTPICTUREToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
