﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Timer1 As System.Windows.Forms.Timer
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.toolstripComPort = New System.Windows.Forms.ToolStrip()
        Me.btnConnect = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.Label1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblRxCnt = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.Label2 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblTxCnt = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.ToolStrip4 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripSeparator22 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel9 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator32 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator33 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel8 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel11 = New System.Windows.Forms.ToolStripLabel()
        Me.lblcycletime = New System.Windows.Forms.ToolStripLabel()
        Me.StatusStrip3 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripSeparator23 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.TstrCell = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator24 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator16 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator25 = New System.Windows.Forms.ToolStripSeparator()
        Me.tstrCard = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator26 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblIO03 = New System.Windows.Forms.ToolStripLabel()
        Me.TstrCycleCount = New System.Windows.Forms.ToolStripLabel()
        Me.StatusStrip4 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.txtstatus2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.btnConnectIO = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator17 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator21 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel4 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel5 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator27 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblRxCntIO = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator28 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel10 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator29 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblTxCntIO = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator30 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator31 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.StatusStrip2 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.txtstatus1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btnConnectSend = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator19 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel6 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator18 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblRxCntSend = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator20 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel3 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblTxCntsend = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.status0 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.StatusStrip6 = New System.Windows.Forms.StatusStrip()
        Me.lblReceive = New System.Windows.Forms.ToolStripStatusLabel()
        Me.T1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.T2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.ListInQueue1 = New System.Windows.Forms.ListBox()
        Me.lblsignal = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblIO02 = New System.Windows.Forms.Label()
        Me.lblIO01 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblA5 = New System.Windows.Forms.Label()
        Me.lblA6 = New System.Windows.Forms.Label()
        Me.lblA7 = New System.Windows.Forms.Label()
        Me.lblA8 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblA1 = New System.Windows.Forms.Label()
        Me.lblA2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblA3 = New System.Windows.Forms.Label()
        Me.lblA4 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.StatusStrip5 = New System.Windows.Forms.StatusStrip()
        Me.TstaTCPSignal = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.mnuTxBox = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CopyTx = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteTx = New System.Windows.Forms.ToolStripMenuItem()
        Me.CutTx = New System.Windows.Forms.ToolStripMenuItem()
        Me.SendLine = New System.Windows.Forms.ToolStripMenuItem()
        Me.SendSelect = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker2 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker3 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker4 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker5 = New System.ComponentModel.BackgroundWorker()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.FileTool = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadConfig = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveConfig = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tcboselect = New System.Windows.Forms.ToolStripComboBox()
        Me.cboComPort = New System.Windows.Forms.ToolStripComboBox()
        Me.cboBaudrate = New System.Windows.Forms.ToolStripComboBox()
        Me.cboDataBits = New System.Windows.Forms.ToolStripComboBox()
        Me.cboParity = New System.Windows.Forms.ToolStripComboBox()
        Me.cboStopbits = New System.Windows.Forms.ToolStripComboBox()
        Me.cboDelay = New System.Windows.Forms.ToolStripComboBox()
        Me.cboThreshold = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitTool = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionsTool = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReceiveboxFontToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LargeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MediumToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SmallToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFormToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnSettime = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetTimeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetValueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DelayFinalSendToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DelayBeforeResendToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.toolstripComPort.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.ToolStrip4.SuspendLayout()
        Me.StatusStrip3.SuspendLayout()
        Me.StatusStrip4.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.StatusStrip2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.StatusStrip6.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.StatusStrip5.SuspendLayout()
        Me.mnuTxBox.SuspendLayout()
        Me.Menu1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Timer1.Enabled = True
        Timer1.Interval = 500
        AddHandler Timer1.Tick, AddressOf Me.Timer1_Tick
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'toolstripComPort
        '
        Me.toolstripComPort.BackColor = System.Drawing.Color.Transparent
        Me.toolstripComPort.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnConnect, Me.ToolStripSeparator10, Me.ToolStripSeparator12, Me.Label1, Me.ToolStripSeparator9, Me.lblRxCnt, Me.ToolStripSeparator11, Me.Label2, Me.ToolStripSeparator6, Me.lblTxCnt, Me.ToolStripSeparator7, Me.ToolStripSeparator1})
        Me.toolstripComPort.Location = New System.Drawing.Point(3, 16)
        Me.toolstripComPort.Name = "toolstripComPort"
        Me.toolstripComPort.Size = New System.Drawing.Size(347, 25)
        Me.toolstripComPort.TabIndex = 0
        Me.toolstripComPort.Text = "ToolStrip1"
        '
        'btnConnect
        '
        Me.btnConnect.BackColor = System.Drawing.Color.DarkGray
        Me.btnConnect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnConnect.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(64, 22)
        Me.btnConnect.Text = "*connect*"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 25)
        '
        'Label1
        '
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 22)
        Me.Label1.Text = "RX"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'lblRxCnt
        '
        Me.lblRxCnt.BackColor = System.Drawing.Color.Transparent
        Me.lblRxCnt.Name = "lblRxCnt"
        Me.lblRxCnt.Size = New System.Drawing.Size(37, 22)
        Me.lblRxCnt.Text = "00000"
        Me.lblRxCnt.ToolTipText = "count bytes received"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(6, 25)
        '
        'Label2
        '
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(21, 22)
        Me.Label2.Text = "TX"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'lblTxCnt
        '
        Me.lblTxCnt.Name = "lblTxCnt"
        Me.lblTxCnt.Size = New System.Drawing.Size(37, 22)
        Me.lblTxCnt.Text = "00000"
        Me.lblTxCnt.ToolTipText = "count sent bytes"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.ForeColor = System.Drawing.Color.Red
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 24)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.ToolStrip4)
        Me.SplitContainer1.Panel1.Controls.Add(Me.StatusStrip3)
        Me.SplitContainer1.Panel1.Controls.Add(Me.StatusStrip4)
        Me.SplitContainer1.Panel1.Controls.Add(Me.ToolStrip2)
        Me.SplitContainer1.Panel1.Controls.Add(Me.GroupBox1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(355, 718)
        Me.SplitContainer1.SplitterDistance = 233
        Me.SplitContainer1.TabIndex = 3
        '
        'ToolStrip4
        '
        Me.ToolStrip4.AutoSize = False
        Me.ToolStrip4.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator22, Me.ToolStripLabel2, Me.ToolStripSeparator2, Me.ToolStripSeparator4, Me.ToolStripLabel9, Me.ToolStripSeparator32, Me.ToolStripSeparator33, Me.ToolStripLabel8, Me.ToolStripSeparator5, Me.ToolStripLabel11, Me.lblcycletime})
        Me.ToolStrip4.Location = New System.Drawing.Point(0, 215)
        Me.ToolStrip4.Name = "ToolStrip4"
        Me.ToolStrip4.Size = New System.Drawing.Size(353, 15)
        Me.ToolStrip4.TabIndex = 1
        Me.ToolStrip4.Text = "ToolStrip4"
        '
        'ToolStripSeparator22
        '
        Me.ToolStripSeparator22.Name = "ToolStripSeparator22"
        Me.ToolStripSeparator22.Size = New System.Drawing.Size(6, 15)
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.AutoSize = False
        Me.ToolStripLabel2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(100, 12)
        Me.ToolStripLabel2.Text = "Cell"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 15)
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 15)
        '
        'ToolStripLabel9
        '
        Me.ToolStripLabel9.AutoSize = False
        Me.ToolStripLabel9.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel9.Name = "ToolStripLabel9"
        Me.ToolStripLabel9.Size = New System.Drawing.Size(60, 12)
        Me.ToolStripLabel9.Text = "RFID Card"
        '
        'ToolStripSeparator32
        '
        Me.ToolStripSeparator32.Name = "ToolStripSeparator32"
        Me.ToolStripSeparator32.Size = New System.Drawing.Size(6, 15)
        '
        'ToolStripSeparator33
        '
        Me.ToolStripSeparator33.Name = "ToolStripSeparator33"
        Me.ToolStripSeparator33.Size = New System.Drawing.Size(6, 15)
        '
        'ToolStripLabel8
        '
        Me.ToolStripLabel8.AutoSize = False
        Me.ToolStripLabel8.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel8.Name = "ToolStripLabel8"
        Me.ToolStripLabel8.Size = New System.Drawing.Size(60, 12)
        Me.ToolStripLabel8.Text = "Reset"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 15)
        '
        'ToolStripLabel11
        '
        Me.ToolStripLabel11.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel11.Name = "ToolStripLabel11"
        Me.ToolStripLabel11.Size = New System.Drawing.Size(64, 12)
        Me.ToolStripLabel11.Text = " Cycle time:"
        '
        'lblcycletime
        '
        Me.lblcycletime.AutoSize = False
        Me.lblcycletime.Name = "lblcycletime"
        Me.lblcycletime.Size = New System.Drawing.Size(30, 15)
        Me.lblcycletime.Text = "--"
        '
        'StatusStrip3
        '
        Me.StatusStrip3.AutoSize = False
        Me.StatusStrip3.BackColor = System.Drawing.Color.Transparent
        Me.StatusStrip3.Dock = System.Windows.Forms.DockStyle.Top
        Me.StatusStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator23, Me.ToolStripSeparator8, Me.TstrCell, Me.ToolStripSeparator24, Me.ToolStripSeparator16, Me.ToolStripSeparator25, Me.tstrCard, Me.ToolStripSeparator26, Me.lblIO03, Me.TstrCycleCount})
        Me.StatusStrip3.Location = New System.Drawing.Point(0, 165)
        Me.StatusStrip3.Name = "StatusStrip3"
        Me.StatusStrip3.Size = New System.Drawing.Size(353, 50)
        Me.StatusStrip3.TabIndex = 2
        Me.StatusStrip3.Text = "StatusStrip3"
        '
        'ToolStripSeparator23
        '
        Me.ToolStripSeparator23.Name = "ToolStripSeparator23"
        Me.ToolStripSeparator23.Size = New System.Drawing.Size(6, 50)
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 50)
        '
        'TstrCell
        '
        Me.TstrCell.AccessibleRole = System.Windows.Forms.AccessibleRole.Alert
        Me.TstrCell.AutoSize = False
        Me.TstrCell.BackColor = System.Drawing.Color.Transparent
        Me.TstrCell.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.TstrCell.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TstrCell.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.TstrCell.Name = "TstrCell"
        Me.TstrCell.Size = New System.Drawing.Size(100, 48)
        Me.TstrCell.Text = "D76-0"
        '
        'ToolStripSeparator24
        '
        Me.ToolStripSeparator24.Name = "ToolStripSeparator24"
        Me.ToolStripSeparator24.Size = New System.Drawing.Size(6, 50)
        '
        'ToolStripSeparator16
        '
        Me.ToolStripSeparator16.Name = "ToolStripSeparator16"
        Me.ToolStripSeparator16.Size = New System.Drawing.Size(6, 50)
        '
        'ToolStripSeparator25
        '
        Me.ToolStripSeparator25.Name = "ToolStripSeparator25"
        Me.ToolStripSeparator25.Size = New System.Drawing.Size(6, 50)
        '
        'tstrCard
        '
        Me.tstrCard.AutoSize = False
        Me.tstrCard.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tstrCard.Name = "tstrCard"
        Me.tstrCard.Size = New System.Drawing.Size(60, 48)
        Me.tstrCard.Text = "210"
        '
        'ToolStripSeparator26
        '
        Me.ToolStripSeparator26.Name = "ToolStripSeparator26"
        Me.ToolStripSeparator26.Size = New System.Drawing.Size(6, 50)
        '
        'lblIO03
        '
        Me.lblIO03.AutoSize = False
        Me.lblIO03.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIO03.Name = "lblIO03"
        Me.lblIO03.Size = New System.Drawing.Size(60, 48)
        Me.lblIO03.Text = "R"
        '
        'TstrCycleCount
        '
        Me.TstrCycleCount.AutoSize = False
        Me.TstrCycleCount.BackColor = System.Drawing.Color.SeaShell
        Me.TstrCycleCount.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TstrCycleCount.ForeColor = System.Drawing.Color.MediumBlue
        Me.TstrCycleCount.Name = "TstrCycleCount"
        Me.TstrCycleCount.Size = New System.Drawing.Size(90, 48)
        Me.TstrCycleCount.Text = "0"
        '
        'StatusStrip4
        '
        Me.StatusStrip4.BackColor = System.Drawing.Color.Silver
        Me.StatusStrip4.Dock = System.Windows.Forms.DockStyle.Top
        Me.StatusStrip4.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel3, Me.txtstatus2})
        Me.StatusStrip4.Location = New System.Drawing.Point(0, 143)
        Me.StatusStrip4.Name = "StatusStrip4"
        Me.StatusStrip4.Size = New System.Drawing.Size(353, 22)
        Me.StatusStrip4.TabIndex = 5
        Me.StatusStrip4.Text = "StatusStrip4"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(64, 17)
        Me.ToolStripStatusLabel3.Text = "[3]IO Port :"
        '
        'txtstatus2
        '
        Me.txtstatus2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstatus2.ForeColor = System.Drawing.Color.Blue
        Me.txtstatus2.Name = "txtstatus2"
        Me.txtstatus2.Size = New System.Drawing.Size(161, 17)
        Me.txtstatus2.Text = "-Please Click Connect button!!"
        '
        'ToolStrip2
        '
        Me.ToolStrip2.BackColor = System.Drawing.Color.Transparent
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnConnectIO, Me.ToolStripSeparator17, Me.ToolStripSeparator21, Me.ToolStripLabel4, Me.ToolStripLabel5, Me.ToolStripSeparator27, Me.lblRxCntIO, Me.ToolStripSeparator28, Me.ToolStripLabel10, Me.ToolStripSeparator29, Me.lblTxCntIO, Me.ToolStripSeparator30, Me.ToolStripSeparator31, Me.ToolStripButton1})
        Me.ToolStrip2.Location = New System.Drawing.Point(0, 118)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(353, 25)
        Me.ToolStrip2.TabIndex = 4
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'btnConnectIO
        '
        Me.btnConnectIO.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btnConnectIO.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnConnectIO.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnConnectIO.Name = "btnConnectIO"
        Me.btnConnectIO.Size = New System.Drawing.Size(64, 22)
        Me.btnConnectIO.Text = "*connect*"
        '
        'ToolStripSeparator17
        '
        Me.ToolStripSeparator17.Name = "ToolStripSeparator17"
        Me.ToolStripSeparator17.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator21
        '
        Me.ToolStripSeparator21.Name = "ToolStripSeparator21"
        Me.ToolStripSeparator21.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel4
        '
        Me.ToolStripLabel4.Name = "ToolStripLabel4"
        Me.ToolStripLabel4.Size = New System.Drawing.Size(0, 22)
        '
        'ToolStripLabel5
        '
        Me.ToolStripLabel5.Name = "ToolStripLabel5"
        Me.ToolStripLabel5.Size = New System.Drawing.Size(21, 22)
        Me.ToolStripLabel5.Text = "RX"
        '
        'ToolStripSeparator27
        '
        Me.ToolStripSeparator27.Name = "ToolStripSeparator27"
        Me.ToolStripSeparator27.Size = New System.Drawing.Size(6, 25)
        '
        'lblRxCntIO
        '
        Me.lblRxCntIO.Name = "lblRxCntIO"
        Me.lblRxCntIO.Size = New System.Drawing.Size(37, 22)
        Me.lblRxCntIO.Text = "00000"
        Me.lblRxCntIO.ToolTipText = "count bytes received"
        '
        'ToolStripSeparator28
        '
        Me.ToolStripSeparator28.Name = "ToolStripSeparator28"
        Me.ToolStripSeparator28.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel10
        '
        Me.ToolStripLabel10.Name = "ToolStripLabel10"
        Me.ToolStripLabel10.Size = New System.Drawing.Size(21, 22)
        Me.ToolStripLabel10.Text = "TX"
        '
        'ToolStripSeparator29
        '
        Me.ToolStripSeparator29.Name = "ToolStripSeparator29"
        Me.ToolStripSeparator29.Size = New System.Drawing.Size(6, 25)
        '
        'lblTxCntIO
        '
        Me.lblTxCntIO.Name = "lblTxCntIO"
        Me.lblTxCntIO.Size = New System.Drawing.Size(37, 22)
        Me.lblTxCntIO.Text = "00000"
        Me.lblTxCntIO.ToolTipText = "count sent bytes"
        '
        'ToolStripSeparator30
        '
        Me.ToolStripSeparator30.Name = "ToolStripSeparator30"
        Me.ToolStripSeparator30.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator31
        '
        Me.ToolStripSeparator31.Name = "ToolStripSeparator31"
        Me.ToolStripSeparator31.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton1.Text = "ToolStripButton1"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.StatusStrip2)
        Me.GroupBox1.Controls.Add(Me.ToolStrip1)
        Me.GroupBox1.Controls.Add(Me.StatusStrip1)
        Me.GroupBox1.Controls.Add(Me.toolstripComPort)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(353, 118)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'StatusStrip2
        '
        Me.StatusStrip2.BackColor = System.Drawing.Color.Silver
        Me.StatusStrip2.Dock = System.Windows.Forms.DockStyle.Top
        Me.StatusStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel2, Me.txtstatus1})
        Me.StatusStrip2.Location = New System.Drawing.Point(3, 88)
        Me.StatusStrip2.Name = "StatusStrip2"
        Me.StatusStrip2.Size = New System.Drawing.Size(347, 22)
        Me.StatusStrip2.TabIndex = 3
        Me.StatusStrip2.Text = "StatusStrip2"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(78, 17)
        Me.ToolStripStatusLabel2.Text = "[2]Send Port :"
        '
        'txtstatus1
        '
        Me.txtstatus1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstatus1.ForeColor = System.Drawing.Color.Blue
        Me.txtstatus1.Name = "txtstatus1"
        Me.txtstatus1.Size = New System.Drawing.Size(161, 17)
        Me.txtstatus1.Text = "-Please Click Connect button!!"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnConnectSend, Me.ToolStripSeparator19, Me.ToolStripSeparator3, Me.ToolStripLabel6, Me.ToolStripLabel1, Me.ToolStripSeparator18, Me.lblRxCntSend, Me.ToolStripSeparator20, Me.ToolStripLabel3, Me.ToolStripSeparator13, Me.lblTxCntsend, Me.ToolStripSeparator14, Me.ToolStripSeparator15})
        Me.ToolStrip1.Location = New System.Drawing.Point(3, 63)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(347, 25)
        Me.ToolStrip1.TabIndex = 2
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btnConnectSend
        '
        Me.btnConnectSend.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btnConnectSend.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnConnectSend.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnConnectSend.Name = "btnConnectSend"
        Me.btnConnectSend.Size = New System.Drawing.Size(64, 22)
        Me.btnConnectSend.Text = "*connect*"
        '
        'ToolStripSeparator19
        '
        Me.ToolStripSeparator19.Name = "ToolStripSeparator19"
        Me.ToolStripSeparator19.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel6
        '
        Me.ToolStripLabel6.Name = "ToolStripLabel6"
        Me.ToolStripLabel6.Size = New System.Drawing.Size(0, 22)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(21, 22)
        Me.ToolStripLabel1.Text = "RX"
        '
        'ToolStripSeparator18
        '
        Me.ToolStripSeparator18.Name = "ToolStripSeparator18"
        Me.ToolStripSeparator18.Size = New System.Drawing.Size(6, 25)
        '
        'lblRxCntSend
        '
        Me.lblRxCntSend.Name = "lblRxCntSend"
        Me.lblRxCntSend.Size = New System.Drawing.Size(37, 22)
        Me.lblRxCntSend.Text = "00000"
        Me.lblRxCntSend.ToolTipText = "count bytes received"
        '
        'ToolStripSeparator20
        '
        Me.ToolStripSeparator20.Name = "ToolStripSeparator20"
        Me.ToolStripSeparator20.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel3
        '
        Me.ToolStripLabel3.Name = "ToolStripLabel3"
        Me.ToolStripLabel3.Size = New System.Drawing.Size(21, 22)
        Me.ToolStripLabel3.Text = "TX"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(6, 25)
        '
        'lblTxCntsend
        '
        Me.lblTxCntsend.Name = "lblTxCntsend"
        Me.lblTxCntsend.Size = New System.Drawing.Size(37, 22)
        Me.lblTxCntsend.Text = "00000"
        Me.lblTxCntsend.ToolTipText = "count sent bytes"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator15
        '
        Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
        Me.ToolStripSeparator15.Size = New System.Drawing.Size(6, 25)
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.Silver
        Me.StatusStrip1.Dock = System.Windows.Forms.DockStyle.Top
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.status0})
        Me.StatusStrip1.Location = New System.Drawing.Point(3, 41)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(347, 22)
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(89, 17)
        Me.ToolStripStatusLabel1.Text = "[1]Receive port:"
        '
        'status0
        '
        Me.status0.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.status0.ForeColor = System.Drawing.Color.Blue
        Me.status0.Name = "status0"
        Me.status0.Size = New System.Drawing.Size(161, 17)
        Me.status0.Text = "-Please Click Connect button!!"
        '
        'SplitContainer2
        '
        Me.SplitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.Label8)
        Me.SplitContainer2.Panel1.Controls.Add(Me.CheckBox2)
        Me.SplitContainer2.Panel1.Controls.Add(Me.Button4)
        Me.SplitContainer2.Panel1.Controls.Add(Me.CheckBox1)
        Me.SplitContainer2.Panel1.Controls.Add(Me.Label7)
        Me.SplitContainer2.Panel1.Controls.Add(Me.StatusStrip6)
        Me.SplitContainer2.Panel1.Controls.Add(Me.Button2)
        Me.SplitContainer2.Panel1.Controls.Add(Me.Button1)
        Me.SplitContainer2.Panel1.Controls.Add(Me.Button3)
        Me.SplitContainer2.Panel1.Controls.Add(Me.ListInQueue1)
        Me.SplitContainer2.Panel1.Controls.Add(Me.lblsignal)
        Me.SplitContainer2.Panel1.Controls.Add(Me.Label19)
        Me.SplitContainer2.Panel1.Controls.Add(Me.lblIO02)
        Me.SplitContainer2.Panel1.Controls.Add(Me.lblIO01)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.TableLayoutPanel1)
        Me.SplitContainer2.Panel2.Controls.Add(Me.StatusStrip5)
        Me.SplitContainer2.Size = New System.Drawing.Size(355, 481)
        Me.SplitContainer2.SplitterDistance = 394
        Me.SplitContainer2.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(252, 145)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 13)
        Me.Label8.TabIndex = 136
        Me.Label8.Text = "Label8"
        '
        'CheckBox2
        '
        Me.CheckBox2.BackColor = System.Drawing.Color.Transparent
        Me.CheckBox2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CheckBox2.Location = New System.Drawing.Point(160, 8)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(67, 21)
        Me.CheckBox2.TabIndex = 135
        Me.CheckBox2.Text = "Not use"
        Me.CheckBox2.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 42.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.Location = New System.Drawing.Point(255, 8)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(73, 81)
        Me.Button4.TabIndex = 134
        Me.Button4.Text = "-"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.UseVisualStyleBackColor = False
        '
        'CheckBox1
        '
        Me.CheckBox1.BackColor = System.Drawing.Color.Transparent
        Me.CheckBox1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CheckBox1.Location = New System.Drawing.Point(27, 8)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(114, 21)
        Me.CheckBox1.TabIndex = 132
        Me.CheckBox1.Text = "Use Check time "
        Me.CheckBox1.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.LightGray
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(27, 100)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(217, 127)
        Me.Label7.TabIndex = 131
        Me.Label7.Text = "Kitting Daisha"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'StatusStrip6
        '
        Me.StatusStrip6.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel5, Me.lblReceive, Me.T1, Me.T2})
        Me.StatusStrip6.Location = New System.Drawing.Point(0, 370)
        Me.StatusStrip6.Name = "StatusStrip6"
        Me.StatusStrip6.Size = New System.Drawing.Size(353, 22)
        Me.StatusStrip6.TabIndex = 130
        Me.StatusStrip6.Text = "StatusStrip6"
        '
        'lblReceive
        '
        Me.lblReceive.Name = "lblReceive"
        Me.lblReceive.Size = New System.Drawing.Size(60, 17)
        Me.lblReceive.Text = "lblReceive"
        '
        'T1
        '
        Me.T1.Name = "T1"
        Me.T1.Size = New System.Drawing.Size(20, 17)
        Me.T1.Text = "T1"
        '
        'T2
        '
        Me.T2.Name = "T2"
        Me.T2.Size = New System.Drawing.Size(20, 17)
        Me.T2.Text = "T2"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(26, 37)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(222, 51)
        Me.Button2.TabIndex = 129
        Me.Button2.Text = "Signal:"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(278, 311)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(49, 54)
        Me.Button1.TabIndex = 128
        Me.Button1.Text = "Cancel" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "1st"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(233, 311)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(39, 54)
        Me.Button3.TabIndex = 126
        Me.Button3.Text = "CLR" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Data"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'ListInQueue1
        '
        Me.ListInQueue1.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.ListInQueue1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListInQueue1.FormattingEnabled = True
        Me.ListInQueue1.ItemHeight = 25
        Me.ListInQueue1.Location = New System.Drawing.Point(27, 311)
        Me.ListInQueue1.Name = "ListInQueue1"
        Me.ListInQueue1.Size = New System.Drawing.Size(200, 54)
        Me.ListInQueue1.TabIndex = 125
        '
        'lblsignal
        '
        Me.lblsignal.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblsignal.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsignal.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblsignal.Location = New System.Drawing.Point(81, -86)
        Me.lblsignal.Name = "lblsignal"
        Me.lblsignal.Size = New System.Drawing.Size(139, 58)
        Me.lblsignal.TabIndex = 120
        Me.lblsignal.Text = "Request Start"
        Me.lblsignal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.LightGray
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label19.Location = New System.Drawing.Point(28, 237)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(299, 65)
        Me.Label19.TabIndex = 121
        Me.Label19.Text = "-:-"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblIO02
        '
        Me.lblIO02.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblIO02.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblIO02.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIO02.Location = New System.Drawing.Point(255, 181)
        Me.lblIO02.Name = "lblIO02"
        Me.lblIO02.Size = New System.Drawing.Size(72, 45)
        Me.lblIO02.TabIndex = 1
        Me.lblIO02.Text = "S2"
        Me.lblIO02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblIO01
        '
        Me.lblIO01.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblIO01.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblIO01.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIO01.Location = New System.Drawing.Point(255, 102)
        Me.lblIO01.Name = "lblIO01"
        Me.lblIO01.Size = New System.Drawing.Size(72, 43)
        Me.lblIO01.TabIndex = 0
        Me.lblIO01.Text = "S1"
        Me.lblIO01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.lblA5, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA6, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA7, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA8, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label13, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA1, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA2, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA3, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA4, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label12, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 2, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(353, 79)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'lblA5
        '
        Me.lblA5.AutoSize = True
        Me.lblA5.Location = New System.Drawing.Point(268, 1)
        Me.lblA5.Name = "lblA5"
        Me.lblA5.Size = New System.Drawing.Size(10, 13)
        Me.lblA5.TabIndex = 12
        Me.lblA5.Text = "-"
        '
        'lblA6
        '
        Me.lblA6.AutoSize = True
        Me.lblA6.Location = New System.Drawing.Point(268, 19)
        Me.lblA6.Name = "lblA6"
        Me.lblA6.Size = New System.Drawing.Size(10, 13)
        Me.lblA6.TabIndex = 13
        Me.lblA6.Text = "-"
        '
        'lblA7
        '
        Me.lblA7.AutoSize = True
        Me.lblA7.Location = New System.Drawing.Point(268, 37)
        Me.lblA7.Name = "lblA7"
        Me.lblA7.Size = New System.Drawing.Size(10, 13)
        Me.lblA7.TabIndex = 14
        Me.lblA7.Text = "-"
        '
        'lblA8
        '
        Me.lblA8.AutoSize = True
        Me.lblA8.Location = New System.Drawing.Point(268, 58)
        Me.lblA8.Name = "lblA8"
        Me.lblA8.Size = New System.Drawing.Size(10, 13)
        Me.lblA8.TabIndex = 15
        Me.lblA8.Text = "-"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(180, 19)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(29, 12)
        Me.Label13.TabIndex = 10
        Me.Label13.Text = "RAdd"
        '
        'lblA1
        '
        Me.lblA1.AutoSize = True
        Me.lblA1.Location = New System.Drawing.Point(92, 1)
        Me.lblA1.Name = "lblA1"
        Me.lblA1.Size = New System.Drawing.Size(10, 13)
        Me.lblA1.TabIndex = 4
        Me.lblA1.Text = "-"
        '
        'lblA2
        '
        Me.lblA2.AutoSize = True
        Me.lblA2.Location = New System.Drawing.Point(92, 19)
        Me.lblA2.Name = "lblA2"
        Me.lblA2.Size = New System.Drawing.Size(10, 13)
        Me.lblA2.TabIndex = 7
        Me.lblA2.Text = "-"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 1)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "BG1,2:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 19)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "BG3,4:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, 37)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 12)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "FST,FC:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 58)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Card,Count:"
        '
        'lblA3
        '
        Me.lblA3.AutoSize = True
        Me.lblA3.Location = New System.Drawing.Point(92, 37)
        Me.lblA3.Name = "lblA3"
        Me.lblA3.Size = New System.Drawing.Size(10, 13)
        Me.lblA3.TabIndex = 5
        Me.lblA3.Text = "-"
        '
        'lblA4
        '
        Me.lblA4.AutoSize = True
        Me.lblA4.Location = New System.Drawing.Point(92, 58)
        Me.lblA4.Name = "lblA4"
        Me.lblA4.Size = New System.Drawing.Size(10, 13)
        Me.lblA4.TabIndex = 6
        Me.lblA4.Text = "-"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(180, 37)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(37, 12)
        Me.Label14.TabIndex = 11
        Me.Label14.Text = "224Add"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(180, 58)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(37, 12)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "217Add"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(180, 1)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(61, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "AddChk/Q:"
        '
        'StatusStrip5
        '
        Me.StatusStrip5.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TstaTCPSignal, Me.ToolStripStatusLabel4})
        Me.StatusStrip5.Location = New System.Drawing.Point(0, 59)
        Me.StatusStrip5.Name = "StatusStrip5"
        Me.StatusStrip5.Size = New System.Drawing.Size(353, 22)
        Me.StatusStrip5.TabIndex = 0
        Me.StatusStrip5.Text = "StatusStrip5"
        '
        'TstaTCPSignal
        '
        Me.TstaTCPSignal.Name = "TstaTCPSignal"
        Me.TstaTCPSignal.Size = New System.Drawing.Size(67, 17)
        Me.TstaTCPSignal.Text = "Signal Rcv::"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(22, 17)
        Me.ToolStripStatusLabel4.Text = "IO:"
        '
        'mnuTxBox
        '
        Me.mnuTxBox.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyTx, Me.PasteTx, Me.CutTx, Me.SendLine, Me.SendSelect})
        Me.mnuTxBox.Name = "MenuTxBox"
        Me.mnuTxBox.Size = New System.Drawing.Size(150, 114)
        '
        'CopyTx
        '
        Me.CopyTx.Image = Global.comTerm.My.Resources.Resources.Copy
        Me.CopyTx.Name = "CopyTx"
        Me.CopyTx.Size = New System.Drawing.Size(149, 22)
        Me.CopyTx.Text = "Copy"
        '
        'PasteTx
        '
        Me.PasteTx.Image = Global.comTerm.My.Resources.Resources.Paste
        Me.PasteTx.Name = "PasteTx"
        Me.PasteTx.Size = New System.Drawing.Size(149, 22)
        Me.PasteTx.Text = "Paste"
        '
        'CutTx
        '
        Me.CutTx.Image = Global.comTerm.My.Resources.Resources.Clipboard_Cut
        Me.CutTx.Name = "CutTx"
        Me.CutTx.Size = New System.Drawing.Size(149, 22)
        Me.CutTx.Text = "Cut"
        '
        'SendLine
        '
        Me.SendLine.Image = Global.comTerm.My.Resources.Resources.Arrow1_Right
        Me.SendLine.Name = "SendLine"
        Me.SendLine.Size = New System.Drawing.Size(149, 22)
        Me.SendLine.Text = "send line"
        '
        'SendSelect
        '
        Me.SendSelect.Image = Global.comTerm.My.Resources.Resources.Arrow2_Right
        Me.SendSelect.Name = "SendSelect"
        Me.SendSelect.Size = New System.Drawing.Size(149, 22)
        Me.SendSelect.Text = "send selection"
        '
        'BackgroundWorker1
        '
        '
        'BackgroundWorker2
        '
        '
        'BackgroundWorker4
        '
        '
        'BackgroundWorker5
        '
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 500
        '
        'FileTool
        '
        Me.FileTool.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadConfig, Me.SaveConfig, Me.ExitTool})
        Me.FileTool.Name = "FileTool"
        Me.FileTool.Size = New System.Drawing.Size(37, 20)
        Me.FileTool.Text = "File"
        '
        'LoadConfig
        '
        Me.LoadConfig.Image = Global.comTerm.My.Resources.Resources.Disk
        Me.LoadConfig.Name = "LoadConfig"
        Me.LoadConfig.Size = New System.Drawing.Size(137, 22)
        Me.LoadConfig.Text = "Load config"
        '
        'SaveConfig
        '
        Me.SaveConfig.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tcboselect, Me.cboComPort, Me.cboBaudrate, Me.cboDataBits, Me.cboParity, Me.cboStopbits, Me.cboDelay, Me.cboThreshold, Me.ToolStripMenuItem1})
        Me.SaveConfig.Image = Global.comTerm.My.Resources.Resources.Disk_download
        Me.SaveConfig.Name = "SaveConfig"
        Me.SaveConfig.Size = New System.Drawing.Size(137, 22)
        Me.SaveConfig.Text = "save config"
        '
        'Tcboselect
        '
        Me.Tcboselect.Items.AddRange(New Object() {"Receive Comport", "Send Comport"})
        Me.Tcboselect.Name = "Tcboselect"
        Me.Tcboselect.Size = New System.Drawing.Size(121, 23)
        Me.Tcboselect.Text = "<Select one>"
        '
        'cboComPort
        '
        Me.cboComPort.AutoSize = False
        Me.cboComPort.MergeAction = System.Windows.Forms.MergeAction.MatchOnly
        Me.cboComPort.Name = "cboComPort"
        Me.cboComPort.Size = New System.Drawing.Size(100, 23)
        Me.cboComPort.Text = "<Port>"
        '
        'cboBaudrate
        '
        Me.cboBaudrate.AutoSize = False
        Me.cboBaudrate.DropDownWidth = 50
        Me.cboBaudrate.Items.AddRange(New Object() {"2400", "4800", "9600", "19200", "38400", "115200"})
        Me.cboBaudrate.Name = "cboBaudrate"
        Me.cboBaudrate.Size = New System.Drawing.Size(100, 23)
        Me.cboBaudrate.Text = "<Baud>"
        '
        'cboDataBits
        '
        Me.cboDataBits.AutoSize = False
        Me.cboDataBits.Items.AddRange(New Object() {"7", "8"})
        Me.cboDataBits.Name = "cboDataBits"
        Me.cboDataBits.Size = New System.Drawing.Size(100, 23)
        Me.cboDataBits.Text = "<data>"
        '
        'cboParity
        '
        Me.cboParity.AutoSize = False
        Me.cboParity.Items.AddRange(New Object() {"None", "Even", "Mark", "Odd", "Space"})
        Me.cboParity.Name = "cboParity"
        Me.cboParity.Size = New System.Drawing.Size(100, 23)
        Me.cboParity.Text = "<Parity>"
        '
        'cboStopbits
        '
        Me.cboStopbits.AutoSize = False
        Me.cboStopbits.DropDownWidth = 50
        Me.cboStopbits.Items.AddRange(New Object() {"None", "One", "Two"})
        Me.cboStopbits.Name = "cboStopbits"
        Me.cboStopbits.Size = New System.Drawing.Size(100, 23)
        Me.cboStopbits.Text = "<Stop>"
        '
        'cboDelay
        '
        Me.cboDelay.AutoSize = False
        Me.cboDelay.Items.AddRange(New Object() {"1", "2", "5", "10", "20", "50", "100", "200", "500", "1000"})
        Me.cboDelay.Name = "cboDelay"
        Me.cboDelay.Size = New System.Drawing.Size(100, 23)
        Me.cboDelay.Text = "<Delay>"
        Me.cboDelay.ToolTipText = "Datareceived handle delay"
        '
        'cboThreshold
        '
        Me.cboThreshold.AutoSize = False
        Me.cboThreshold.Items.AddRange(New Object() {"1", "2", "5", "10", "20", "50", "100", "200", "500", "1000"})
        Me.cboThreshold.Name = "cboThreshold"
        Me.cboThreshold.Size = New System.Drawing.Size(100, 23)
        Me.cboThreshold.Text = "<thresh>"
        Me.cboThreshold.ToolTipText = ".receivedBytesThreshold property"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.BackColor = System.Drawing.Color.Silver
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(181, 22)
        Me.ToolStripMenuItem1.Text = "Save Data"
        '
        'ExitTool
        '
        Me.ExitTool.Image = Global.comTerm.My.Resources.Resources.Standby
        Me.ExitTool.Name = "ExitTool"
        Me.ExitTool.Size = New System.Drawing.Size(137, 22)
        Me.ExitTool.Text = "Exit"
        '
        'OptionsTool
        '
        Me.OptionsTool.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReceiveboxFontToolStripMenuItem, Me.OpenFormToolStripMenuItem, Me.btnSettime, Me.ToolStripMenuItem4, Me.ResetTimeToolStripMenuItem, Me.ResetValueToolStripMenuItem, Me.DelayFinalSendToolStripMenuItem, Me.DelayBeforeResendToolStripMenuItem})
        Me.OptionsTool.Name = "OptionsTool"
        Me.OptionsTool.Size = New System.Drawing.Size(61, 20)
        Me.OptionsTool.Text = "Options"
        '
        'ReceiveboxFontToolStripMenuItem
        '
        Me.ReceiveboxFontToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LargeToolStripMenuItem, Me.MediumToolStripMenuItem, Me.SmallToolStripMenuItem})
        Me.ReceiveboxFontToolStripMenuItem.Name = "ReceiveboxFontToolStripMenuItem"
        Me.ReceiveboxFontToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ReceiveboxFontToolStripMenuItem.Text = "font"
        '
        'LargeToolStripMenuItem
        '
        Me.LargeToolStripMenuItem.Name = "LargeToolStripMenuItem"
        Me.LargeToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.LargeToolStripMenuItem.Text = "Large"
        '
        'MediumToolStripMenuItem
        '
        Me.MediumToolStripMenuItem.Name = "MediumToolStripMenuItem"
        Me.MediumToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.MediumToolStripMenuItem.Text = "Medium"
        '
        'SmallToolStripMenuItem
        '
        Me.SmallToolStripMenuItem.Name = "SmallToolStripMenuItem"
        Me.SmallToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.SmallToolStripMenuItem.Text = "Small"
        '
        'OpenFormToolStripMenuItem
        '
        Me.OpenFormToolStripMenuItem.Name = "OpenFormToolStripMenuItem"
        Me.OpenFormToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.OpenFormToolStripMenuItem.Text = "open form"
        '
        'btnSettime
        '
        Me.btnSettime.Name = "btnSettime"
        Me.btnSettime.Size = New System.Drawing.Size(181, 22)
        Me.btnSettime.Text = "Set time"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(181, 22)
        Me.ToolStripMenuItem4.Text = "Set cycle time"
        '
        'ResetTimeToolStripMenuItem
        '
        Me.ResetTimeToolStripMenuItem.Name = "ResetTimeToolStripMenuItem"
        Me.ResetTimeToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ResetTimeToolStripMenuItem.Text = "Reset time"
        '
        'ResetValueToolStripMenuItem
        '
        Me.ResetValueToolStripMenuItem.Name = "ResetValueToolStripMenuItem"
        Me.ResetValueToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ResetValueToolStripMenuItem.Text = "Reset Value"
        '
        'DelayFinalSendToolStripMenuItem
        '
        Me.DelayFinalSendToolStripMenuItem.Name = "DelayFinalSendToolStripMenuItem"
        Me.DelayFinalSendToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DelayFinalSendToolStripMenuItem.Text = "Delay Final Send"
        '
        'DelayBeforeResendToolStripMenuItem
        '
        Me.DelayBeforeResendToolStripMenuItem.Name = "DelayBeforeResendToolStripMenuItem"
        Me.DelayBeforeResendToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DelayBeforeResendToolStripMenuItem.Text = "Delay Before Resend"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(12, 20)
        '
        'Menu1
        '
        Me.Menu1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileTool, Me.OptionsTool, Me.ToolStripMenuItem3})
        Me.Menu1.Location = New System.Drawing.Point(0, 0)
        Me.Menu1.Name = "Menu1"
        Me.Menu1.Size = New System.Drawing.Size(355, 24)
        Me.Menu1.TabIndex = 2
        Me.Menu1.Text = "MenuStrip1"
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(20, 17)
        Me.ToolStripStatusLabel5.Text = "T2"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(355, 742)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.Menu1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.Menu1
        Me.MinimumSize = New System.Drawing.Size(330, 500)
        Me.Name = "frmMain"
        Me.Text = "AGV Control -"
        Me.toolstripComPort.ResumeLayout(False)
        Me.toolstripComPort.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.ToolStrip4.ResumeLayout(False)
        Me.ToolStrip4.PerformLayout()
        Me.StatusStrip3.ResumeLayout(False)
        Me.StatusStrip3.PerformLayout()
        Me.StatusStrip4.ResumeLayout(False)
        Me.StatusStrip4.PerformLayout()
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.StatusStrip2.ResumeLayout(False)
        Me.StatusStrip2.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.PerformLayout()
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.Panel2.PerformLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.StatusStrip6.ResumeLayout(False)
        Me.StatusStrip6.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.StatusStrip5.ResumeLayout(False)
        Me.StatusStrip5.PerformLayout()
        Me.mnuTxBox.ResumeLayout(False)
        Me.Menu1.ResumeLayout(False)
        Me.Menu1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents toolstripComPort As System.Windows.Forms.ToolStrip
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents mnuTxBox As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CopyTx As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteTx As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CutTx As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendLine As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendSelect As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents Label2 As ToolStripLabel
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents lblTxCnt As ToolStripLabel
    Friend WithEvents ToolStripSeparator7 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator12 As ToolStripSeparator
    Friend WithEvents Label1 As ToolStripLabel
    Friend WithEvents ToolStripSeparator9 As ToolStripSeparator
    Friend WithEvents lblRxCnt As ToolStripLabel
    Friend WithEvents ToolStripSeparator10 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator11 As ToolStripSeparator
    Friend WithEvents btnConnect As ToolStripButton
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btnConnectSend As ToolStripButton
    Friend WithEvents ToolStripSeparator19 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents ToolStripLabel6 As ToolStripLabel
    Friend WithEvents ToolStripSeparator18 As ToolStripSeparator
    Friend WithEvents lblRxCntSend As ToolStripLabel
    Friend WithEvents ToolStripSeparator20 As ToolStripSeparator
    Friend WithEvents ToolStripLabel3 As ToolStripLabel
    Friend WithEvents ToolStripSeparator13 As ToolStripSeparator
    Friend WithEvents lblTxCntsend As ToolStripLabel
    Friend WithEvents ToolStripSeparator14 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator15 As ToolStripSeparator
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents ToolStrip4 As ToolStrip
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents ToolStripLabel8 As ToolStripLabel
    Friend WithEvents ToolStripLabel9 As ToolStripLabel
    Friend WithEvents ToolStripLabel11 As ToolStripLabel
    Friend WithEvents lblcycletime As ToolStripLabel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator22 As ToolStripSeparator
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents status0 As ToolStripStatusLabel
    Friend WithEvents StatusStrip3 As StatusStrip
    Friend WithEvents ToolStripSeparator23 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator8 As ToolStripSeparator
    Friend WithEvents TstrCell As ToolStripLabel
    Friend WithEvents ToolStripSeparator24 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator16 As ToolStripSeparator
    Friend WithEvents lblIO03 As ToolStripLabel
    Friend WithEvents ToolStripSeparator25 As ToolStripSeparator
    Friend WithEvents tstrCard As ToolStripLabel
    Friend WithEvents ToolStripSeparator26 As ToolStripSeparator
    Friend WithEvents TstrCycleCount As ToolStripLabel
    Friend WithEvents StatusStrip2 As StatusStrip
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents txtstatus1 As ToolStripStatusLabel
    Friend WithEvents StatusStrip4 As StatusStrip
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents txtstatus2 As ToolStripStatusLabel
    Friend WithEvents ToolStrip2 As ToolStrip
    Friend WithEvents btnConnectIO As ToolStripButton
    Friend WithEvents ToolStripSeparator17 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator21 As ToolStripSeparator
    Friend WithEvents ToolStripLabel4 As ToolStripLabel
    Friend WithEvents ToolStripLabel5 As ToolStripLabel
    Friend WithEvents ToolStripSeparator27 As ToolStripSeparator
    Friend WithEvents lblRxCntIO As ToolStripLabel
    Friend WithEvents ToolStripSeparator28 As ToolStripSeparator
    Friend WithEvents ToolStripLabel10 As ToolStripLabel
    Friend WithEvents ToolStripSeparator29 As ToolStripSeparator
    Friend WithEvents lblTxCntIO As ToolStripLabel
    Friend WithEvents ToolStripSeparator30 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator31 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator32 As ToolStripSeparator
    Friend WithEvents lblIO02 As Label
    Friend WithEvents lblIO01 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents ListInQueue1 As ListBox
    Friend WithEvents lblsignal As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker3 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker4 As System.ComponentModel.BackgroundWorker
    Friend WithEvents StatusStrip5 As StatusStrip
    Friend WithEvents TstaTCPSignal As ToolStripStatusLabel
    Friend WithEvents BackgroundWorker5 As System.ComponentModel.BackgroundWorker
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents lblA5 As Label
    Friend WithEvents lblA6 As Label
    Friend WithEvents lblA7 As Label
    Friend WithEvents lblA8 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lblA1 As Label
    Friend WithEvents lblA2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblA3 As Label
    Friend WithEvents lblA4 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Timer2 As Timer
    Friend WithEvents ToolStripStatusLabel4 As ToolStripStatusLabel
    Friend WithEvents Button1 As Button
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents FileTool As ToolStripMenuItem
    Friend WithEvents LoadConfig As ToolStripMenuItem
    Friend WithEvents SaveConfig As ToolStripMenuItem
    Friend WithEvents Tcboselect As ToolStripComboBox
    Friend WithEvents cboComPort As ToolStripComboBox
    Friend WithEvents cboBaudrate As ToolStripComboBox
    Friend WithEvents cboDataBits As ToolStripComboBox
    Friend WithEvents cboParity As ToolStripComboBox
    Friend WithEvents cboStopbits As ToolStripComboBox
    Friend WithEvents cboDelay As ToolStripComboBox
    Friend WithEvents cboThreshold As ToolStripComboBox
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ExitTool As ToolStripMenuItem
    Friend WithEvents OptionsTool As ToolStripMenuItem
    Friend WithEvents ReceiveboxFontToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LargeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MediumToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SmallToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenFormToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents Menu1 As MenuStrip
    Friend WithEvents btnSettime As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents Button2 As Button
    Friend WithEvents ResetTimeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StatusStrip6 As StatusStrip
    Friend WithEvents lblReceive As ToolStripStatusLabel
    Friend WithEvents Label7 As Label
    Friend WithEvents ResetValueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents DelayFinalSendToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents T1 As ToolStripStatusLabel
    Friend WithEvents ToolStripSeparator33 As ToolStripSeparator
    Friend WithEvents Button4 As Button
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents Label8 As Label
    Friend WithEvents DelayBeforeResendToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents T2 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel5 As ToolStripStatusLabel
End Class
