﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            If myfindform("Form2") = False Then
                Dim frm As Form2
                frm = New Form2
                frm.TopLevel = False
                frm.Parent = Me.Panel1
                frm.Show()
                frm.BringToFront()
            End If
            checkifrunning()

            'Process.Start("D:\IprojectDB\Setting\comTerm.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString())
        End Try
    End Sub

    Function myfindform(ByVal frm As String) As Boolean
        For Each ctl As Control In Me.SplitContainer1.Panel2.Controls
            If ctl.Name.ToUpper = frm.ToUpper Then
                ctl.Show()
                ctl.BringToFront()
                Return True
            End If
        Next
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If myfindform("Form2") = False Then
            Dim frm As Form2
            frm = New Form2
            frm.TopLevel = False
            frm.Parent = Me.Panel1
            frm.Show()
            frm.BringToFront()
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' If myfindform("frmMain") = False Then

        Try
            Dim frm As frmMain
            frm = New frmMain
            frm.TopLevel = False
            frm.Parent = Me.SplitContainer1.Panel2
            frm.Show()
            frm.BringToFront()
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString())
        End Try
        '' End If


    End Sub
    Dim A() As Process
    Private Sub checkifrunning()
        A = Process.GetProcessesByName("AGVControlServerConsole")
        If A.Count <= 0 Then
            Process.Start("D:\IprojectDB\Setting\AGVControlServerConsole.exe")
        End If
    End Sub
End Class