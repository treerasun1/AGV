﻿Imports System.IO

Public Class ComConfigure
    '{"COM1", "9600", "8", "None", "One", "1", "1"}
    Public boxtype As String = "TYPE1"
    Public Concept As String = "HejunKa"
    Public CellNo As String = "D76-0"
    Public CardNo As String = "210"
    Public CardNoCancel As String = "217"
    Public CardNoCancelSignal As String = "217"

    Public cPortSend As String = "COM1"
    Public cBaudSend As String = "9600"
    Public cDataSend As String = "8"
    Public cParitySend As String = "None"
    Public cStopSend As String = "One"
    Public cDelaySend As String = "1"
    Public cThresholdSend As String = "1"

    Public cPortRcv As String = "COM1"
    Public cBaudRcv As String = "9600"
    Public cDataRcv As String = "8"
    Public cParityRcv As String = "None"
    Public cStopRcv As String = "One"
    Public cDelayRcv As String = "1"
    Public cThresholdRcv As String = "1"

    Public cPortIO As String = "COM1"
    Public cBaudIO As String = "9600"
    Public cDataIO As String = "8"
    Public cParityIO As String = "None"
    Public cStopIO As String = "One"
    Public cDelayIO As String = "1"
    Public cThresholdIO As String = "1"


    Public SendCount As String = "20"
    Public IOValue As String = "00"
    Public RstValue As String = "0"
    Public Emer As String = "4"
    Public SWGreen As String = "3"
    Public Sensor1 As String = "2"
    Public Sensor2 As String = "1"
    Public LoopTimeSend As String = "500"
    Public DelayTimeBeforeSend As String = "1"

    Public colorFrm As String = "pink"
    Public colorLabel As String = "lightgreen"
    Public ColorFront As String = "Black"

    Public path As String = "D:\IprojectDB\setting\Comport"
    Private file_name As String = path & CellNo & ".conf"
    Public Sub New()
        ReadConfig(path & CellNo & ".conf")
    End Sub
    Public Sub CreateConfig(ByVal Filename As String)
        Filename = path & CellNo & ".conf"
        Dim file As StreamWriter = New StreamWriter(Filename)
        file.WriteLine("Box Type=" & boxtype)
        file.WriteLine("Concept=" & Concept)
        file.WriteLine("Cell NO=" & CellNo)
        file.WriteLine("Card NO=" & CardNo)
        file.WriteLine("Card Cancel=" & CardNoCancel)
        file.WriteLine("Card Cancel Signal=" & CardNoCancelSignal)
        file.WriteLine("PortNameSend=" & cPortSend)
        file.WriteLine("BaudrateSend=" & cBaudSend)
        file.WriteLine("DataSend=" & cDataSend)
        file.WriteLine("ParitySend=" & cParitySend)
        file.WriteLine("StopSend=" & cStopSend)
        file.WriteLine("DelaySend=" & cDelaySend)
        file.WriteLine("ThresholdSend=" & cThresholdSend)

        file.WriteLine("PortNameRcv=" & cPortRcv)
        file.WriteLine("BaudrateRcv=" & cBaudRcv)
        file.WriteLine("DataRcv=" & cDataRcv)
        file.WriteLine("ParityRcv=" & cParityRcv)
        file.WriteLine("StopRcv=" & cStopRcv)
        file.WriteLine("DelayRcv=" & cDelayRcv)
        file.WriteLine("ThresholdRcv=" & cThresholdRcv)

        file.WriteLine("PortNameIO=" & cPortIO)
        file.WriteLine("BaudrateIO=" & cBaudIO)
        file.WriteLine("DataIO=" & cDataIO)
        file.WriteLine("ParityIO=" & cParityIO)
        file.WriteLine("StopIO=" & cStopIO)
        file.WriteLine("DelayIO=" & cDelayIO)
        file.WriteLine("ThresholdIO=" & cThresholdIO)

        file.WriteLine("IO Value=" & IOValue)
        file.WriteLine("Reset Value=" & RstValue)
        file.WriteLine("Emer=" & Emer)
        file.WriteLine("SWGreen=" & SWGreen)
        file.WriteLine("Sensor1=" & Sensor1)
        file.WriteLine("Sensor2=" & Sensor2)
        file.WriteLine("Delay Time Before Send=" & DelayTimeBeforeSend)
        file.WriteLine("Loop Time Send=" & LoopTimeSend)
        file.WriteLine("Form Color=" & colorFrm)
        file.WriteLine("Label Color=" & colorLabel)
        file.WriteLine("Front Color=" & ColorFront)
        '  file.WriteLine("Package log=" & packageLog)
        file.Close()
    End Sub

    Public Sub ReadConfig(ByVal Filename As String)
        'Dim File As StreamReader
        'Dim line As String
        Try
            For Each line As String In File.ReadLines(Filename)
                Dim s() As String = line.Split("="c)
                If s(0) = "Box Type" Then
                    boxtype = s(1)
                ElseIf s(0) = "Concept" Then
                    Concept = s(1)
                ElseIf s(0) = "Cell NO" Then
                    CellNo = s(1)
                ElseIf s(0) = "Card NO" Then
                    CardNo = s(1)
                ElseIf s(0) = "Card Cancel" Then
                    CardNoCancel = s(1)
                ElseIf s(0) = "Card Cancel Signal" Then
                    CardNoCancelSignal = s(1)
                ElseIf s(0) = "PortNameSend" Then
                    cPortSend = s(1)
                ElseIf s(0) = "BaudrateSend" Then
                    cBaudSend = s(1)
                ElseIf s(0) = "DataSend" Then
                    cDataSend = s(1)
                ElseIf s(0) = "ParitySend" Then
                    cParitySend = s(1)
                ElseIf s(0) = "StopSend" Then
                    cStopSend = s(1)
                ElseIf s(0) = "DelaySend" Then
                    cDelaySend = s(1)
                ElseIf s(0) = "ThresholdSend" Then
                    cThresholdSend = s(1)
                ElseIf s(0) = "PortNameRcv" Then
                    cPortRcv = s(1)
                ElseIf s(0) = "BaudrateRcv" Then
                    cBaudRcv = s(1)
                ElseIf s(0) = "DataRcv" Then
                    cDataRcv = s(1)
                ElseIf s(0) = "ParityRcv" Then
                    cParityRcv = s(1)
                ElseIf s(0) = "StopRcv" Then
                    cStopRcv = s(1)
                ElseIf s(0) = "DelayRcv" Then
                    cDelayRcv = s(1)
                ElseIf s(0) = "ThresholdRcv" Then
                    cThresholdRcv = s(1)
                ElseIf s(0) = "PortNameIO" Then
                    cPortIO = s(1)
                ElseIf s(0) = "BaudrateIO" Then
                    cBaudRcv = s(1)
                ElseIf s(0) = "DataIO" Then
                    cDataIO = s(1)
                ElseIf s(0) = "ParityIO" Then
                    cParityIO = s(1)
                ElseIf s(0) = "StopIO" Then
                    cStopIO = s(1)
                ElseIf s(0) = "DelayIO" Then
                    cDelayIO = s(1)
                ElseIf s(0) = "ThresholdIO" Then
                    cThresholdIO = s(1)
                ElseIf s(0) = "IO Value" Then
                    IOValue = s(1)
                ElseIf s(0) = "Rst Value" Then
                    RstValue = s(1)
                ElseIf s(0) = "Emer" Then
                    Emer = s(1)
                ElseIf s(0) = "SWGreen" Then
                    SWGreen = s(1)
                ElseIf s(0) = "Sensor1" Then
                    Sensor1 = s(1)
                ElseIf s(0) = "Sensor2" Then
                    Sensor2 = s(1)
                ElseIf s(0) = "CountSend" Then
                    SendCount = s(1)
                ElseIf s(0) = "Delay Time Before Send" Then
                    DelayTimeBeforeSend = s(1)
                ElseIf s(0) = "Loop Time Send" Then
                    LoopTimeSend = s(1)
                ElseIf s(0) = "Form Color" Then
                    colorFrm = s(1)
                ElseIf s(0) = "Label Color" Then
                    colorLabel = s(1)
                ElseIf s(0) = "Front Color" Then
                    ColorFront = s(1)
                End If
            Next line

        Catch e As FileNotFoundException

            CreateConfig(file_name)
            '//Console.WriteLine("Error: File not found.");

        Finally

        End Try
    End Sub
End Class
