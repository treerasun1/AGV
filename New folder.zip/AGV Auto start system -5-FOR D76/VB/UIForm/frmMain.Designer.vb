﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Timer1 As System.Windows.Forms.Timer
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.toolstripComPort = New System.Windows.Forms.ToolStrip()
        Me.btnConnect = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.Label1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblRxCnt = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.Label2 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblTxCnt = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.StatusStrip7 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripSeparator22 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel7 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator24 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel9 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator26 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel13 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel16 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator32 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel17 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator33 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel18 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator34 = New System.Windows.Forms.ToolStripSeparator()
        Me.StatusStrip3 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripSeparator23 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblIO03 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator25 = New System.Windows.Forms.ToolStripSeparator()
        Me.TstrCycleCount = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.TstrRCV = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.TstrSend = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.TstrIO = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator16 = New System.Windows.Forms.ToolStripSeparator()
        Me.TstrCell = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.ToolStrip3 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.TstrCard = New System.Windows.Forms.ToolStripLabel()
        Me.StatusStrip2 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.txtstatus1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.btnConnectIO = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator17 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator21 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel4 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel5 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator27 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblRxCntIO = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator28 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel10 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator29 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblTxCntIO = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator30 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator31 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.StatusStrip4 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.txtstatus2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.status0 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btnConnectSend = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator19 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel6 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator18 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblRxCntSend = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator20 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel3 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.lblTxCntsend = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel8 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblIO01 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblIO02 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.ListInQueue1 = New System.Windows.Forms.ListBox()
        Me.TableLayoutPanel7 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel9 = New System.Windows.Forms.TableLayoutPanel()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.lblsignal = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblA5 = New System.Windows.Forms.Label()
        Me.lblA6 = New System.Windows.Forms.Label()
        Me.lblA7 = New System.Windows.Forms.Label()
        Me.lblA8 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblA1 = New System.Windows.Forms.Label()
        Me.lblA2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblA3 = New System.Windows.Forms.Label()
        Me.lblA4 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.StatusStrip5 = New System.Windows.Forms.StatusStrip()
        Me.TstaTCPSignal = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusStrip6 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel6 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblReceive = New System.Windows.Forms.ToolStripStatusLabel()
        Me.T1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.T2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.mnuTxBox = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CopyTx = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteTx = New System.Windows.Forms.ToolStripMenuItem()
        Me.CutTx = New System.Windows.Forms.ToolStripMenuItem()
        Me.SendLine = New System.Windows.Forms.ToolStripMenuItem()
        Me.SendSelect = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker2 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker3 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker4 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker5 = New System.ComponentModel.BackgroundWorker()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.FileTool = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadConfig = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveConfig = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tcboselect = New System.Windows.Forms.ToolStripComboBox()
        Me.cboComPort = New System.Windows.Forms.ToolStripComboBox()
        Me.cboBaudrate = New System.Windows.Forms.ToolStripComboBox()
        Me.cboDataBits = New System.Windows.Forms.ToolStripComboBox()
        Me.cboParity = New System.Windows.Forms.ToolStripComboBox()
        Me.cboStopbits = New System.Windows.Forms.ToolStripComboBox()
        Me.cboDelay = New System.Windows.Forms.ToolStripComboBox()
        Me.cboThreshold = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitTool = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionsTool = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReceiveboxFontToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LargeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MediumToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SmallToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFormToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnSettime = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetTimeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetValueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DelayFinalSendToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DelayBeforeResendToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu1 = New System.Windows.Forms.MenuStrip()
        Me.Label9 = New System.Windows.Forms.Label()
        Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.toolstripComPort.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.StatusStrip7.SuspendLayout()
        Me.StatusStrip3.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.ToolStrip3.SuspendLayout()
        Me.StatusStrip2.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.StatusStrip4.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.TableLayoutPanel8.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.TableLayoutPanel7.SuspendLayout()
        Me.TableLayoutPanel9.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.StatusStrip5.SuspendLayout()
        Me.StatusStrip6.SuspendLayout()
        Me.mnuTxBox.SuspendLayout()
        Me.Menu1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Timer1.Enabled = True
        Timer1.Interval = 500
        AddHandler Timer1.Tick, AddressOf Me.Timer1_Tick
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'toolstripComPort
        '
        Me.toolstripComPort.BackColor = System.Drawing.Color.Transparent
        Me.toolstripComPort.Dock = System.Windows.Forms.DockStyle.Fill
        Me.toolstripComPort.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnConnect, Me.ToolStripSeparator10, Me.ToolStripSeparator12, Me.Label1, Me.ToolStripSeparator9, Me.lblRxCnt, Me.ToolStripSeparator11, Me.Label2, Me.ToolStripSeparator6, Me.lblTxCnt, Me.ToolStripSeparator7, Me.ToolStripSeparator1})
        Me.toolstripComPort.Location = New System.Drawing.Point(3, 26)
        Me.toolstripComPort.Name = "toolstripComPort"
        Me.toolstripComPort.Size = New System.Drawing.Size(354, 30)
        Me.toolstripComPort.TabIndex = 0
        Me.toolstripComPort.Text = "ToolStrip1"
        '
        'btnConnect
        '
        Me.btnConnect.BackColor = System.Drawing.Color.DarkGray
        Me.btnConnect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnConnect.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(64, 27)
        Me.btnConnect.Text = "*connect*"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 30)
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 30)
        '
        'Label1
        '
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 27)
        Me.Label1.Text = "RX"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 30)
        '
        'lblRxCnt
        '
        Me.lblRxCnt.BackColor = System.Drawing.Color.Transparent
        Me.lblRxCnt.Name = "lblRxCnt"
        Me.lblRxCnt.Size = New System.Drawing.Size(37, 27)
        Me.lblRxCnt.Text = "00000"
        Me.lblRxCnt.ToolTipText = "count bytes received"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(6, 30)
        '
        'Label2
        '
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(21, 27)
        Me.Label2.Text = "TX"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 30)
        '
        'lblTxCnt
        '
        Me.lblTxCnt.Name = "lblTxCnt"
        Me.lblTxCnt.Size = New System.Drawing.Size(37, 27)
        Me.lblTxCnt.Text = "00000"
        Me.lblTxCnt.ToolTipText = "count sent bytes"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 30)
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.ForeColor = System.Drawing.Color.Red
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 30)
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 24)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.TabControl1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(376, 757)
        Me.SplitContainer1.SplitterDistance = 244
        Me.SplitContainer1.TabIndex = 3
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.ShowToolTips = True
        Me.TabControl1.Size = New System.Drawing.Size(374, 242)
        Me.TabControl1.TabIndex = 6
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Transparent
        Me.TabPage1.Controls.Add(Me.TableLayoutPanel2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(366, 216)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Visible"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.StatusStrip7, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.StatusStrip3, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.TstrCell, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 3
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.60465!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.39535!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(360, 210)
        Me.TableLayoutPanel2.TabIndex = 3
        '
        'StatusStrip7
        '
        Me.StatusStrip7.AutoSize = False
        Me.StatusStrip7.BackColor = System.Drawing.Color.Transparent
        Me.StatusStrip7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StatusStrip7.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator22, Me.ToolStripLabel7, Me.ToolStripSeparator24, Me.ToolStripLabel9, Me.ToolStripSeparator26, Me.ToolStripLabel13, Me.ToolStripSeparator2, Me.ToolStripLabel16, Me.ToolStripSeparator32, Me.ToolStripLabel17, Me.ToolStripSeparator33, Me.ToolStripLabel18, Me.ToolStripSeparator34})
        Me.StatusStrip7.Location = New System.Drawing.Point(3, 186)
        Me.StatusStrip7.Name = "StatusStrip7"
        Me.StatusStrip7.Size = New System.Drawing.Size(354, 21)
        Me.StatusStrip7.TabIndex = 4
        Me.StatusStrip7.Text = "StatusStrip7"
        '
        'ToolStripSeparator22
        '
        Me.ToolStripSeparator22.Name = "ToolStripSeparator22"
        Me.ToolStripSeparator22.Size = New System.Drawing.Size(6, 21)
        '
        'ToolStripLabel7
        '
        Me.ToolStripLabel7.AutoSize = False
        Me.ToolStripLabel7.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel7.Name = "ToolStripLabel7"
        Me.ToolStripLabel7.Size = New System.Drawing.Size(38, 19)
        Me.ToolStripLabel7.Text = "Reset"
        '
        'ToolStripSeparator24
        '
        Me.ToolStripSeparator24.Name = "ToolStripSeparator24"
        Me.ToolStripSeparator24.Size = New System.Drawing.Size(6, 21)
        '
        'ToolStripLabel9
        '
        Me.ToolStripLabel9.AutoSize = False
        Me.ToolStripLabel9.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel9.Name = "ToolStripLabel9"
        Me.ToolStripLabel9.Size = New System.Drawing.Size(52, 19)
        Me.ToolStripLabel9.Text = " Cycle time:"
        '
        'ToolStripSeparator26
        '
        Me.ToolStripSeparator26.Name = "ToolStripSeparator26"
        Me.ToolStripSeparator26.Size = New System.Drawing.Size(6, 21)
        '
        'ToolStripLabel13
        '
        Me.ToolStripLabel13.AutoSize = False
        Me.ToolStripLabel13.Name = "ToolStripLabel13"
        Me.ToolStripLabel13.Size = New System.Drawing.Size(14, 19)
        Me.ToolStripLabel13.Text = "--"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 21)
        '
        'ToolStripLabel16
        '
        Me.ToolStripLabel16.ActiveLinkColor = System.Drawing.Color.Red
        Me.ToolStripLabel16.AutoSize = False
        Me.ToolStripLabel16.BackColor = System.Drawing.Color.Silver
        Me.ToolStripLabel16.Name = "ToolStripLabel16"
        Me.ToolStripLabel16.Size = New System.Drawing.Size(65, 19)
        Me.ToolStripLabel16.Text = "Receive Port"
        '
        'ToolStripSeparator32
        '
        Me.ToolStripSeparator32.Name = "ToolStripSeparator32"
        Me.ToolStripSeparator32.Size = New System.Drawing.Size(6, 21)
        '
        'ToolStripLabel17
        '
        Me.ToolStripLabel17.AutoSize = False
        Me.ToolStripLabel17.BackColor = System.Drawing.Color.Silver
        Me.ToolStripLabel17.Name = "ToolStripLabel17"
        Me.ToolStripLabel17.Size = New System.Drawing.Size(65, 19)
        Me.ToolStripLabel17.Text = "Send Port"
        '
        'ToolStripSeparator33
        '
        Me.ToolStripSeparator33.Name = "ToolStripSeparator33"
        Me.ToolStripSeparator33.Size = New System.Drawing.Size(6, 21)
        '
        'ToolStripLabel18
        '
        Me.ToolStripLabel18.AutoSize = False
        Me.ToolStripLabel18.BackColor = System.Drawing.Color.Silver
        Me.ToolStripLabel18.Name = "ToolStripLabel18"
        Me.ToolStripLabel18.Size = New System.Drawing.Size(65, 19)
        Me.ToolStripLabel18.Text = "IO Port"
        '
        'ToolStripSeparator34
        '
        Me.ToolStripSeparator34.Name = "ToolStripSeparator34"
        Me.ToolStripSeparator34.Size = New System.Drawing.Size(6, 21)
        '
        'StatusStrip3
        '
        Me.StatusStrip3.AutoSize = False
        Me.StatusStrip3.BackColor = System.Drawing.Color.Transparent
        Me.StatusStrip3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StatusStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator23, Me.lblIO03, Me.ToolStripSeparator25, Me.TstrCycleCount, Me.ToolStripSeparator4, Me.TstrRCV, Me.ToolStripSeparator5, Me.TstrSend, Me.ToolStripSeparator8, Me.TstrIO, Me.ToolStripSeparator16})
        Me.StatusStrip3.Location = New System.Drawing.Point(3, 128)
        Me.StatusStrip3.Name = "StatusStrip3"
        Me.StatusStrip3.Size = New System.Drawing.Size(354, 55)
        Me.StatusStrip3.TabIndex = 2
        Me.StatusStrip3.Text = "StatusStrip3"
        '
        'ToolStripSeparator23
        '
        Me.ToolStripSeparator23.Name = "ToolStripSeparator23"
        Me.ToolStripSeparator23.Size = New System.Drawing.Size(6, 55)
        '
        'lblIO03
        '
        Me.lblIO03.AutoSize = False
        Me.lblIO03.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIO03.Name = "lblIO03"
        Me.lblIO03.Size = New System.Drawing.Size(39, 53)
        Me.lblIO03.Text = "R"
        '
        'ToolStripSeparator25
        '
        Me.ToolStripSeparator25.Name = "ToolStripSeparator25"
        Me.ToolStripSeparator25.Size = New System.Drawing.Size(6, 55)
        '
        'TstrCycleCount
        '
        Me.TstrCycleCount.AutoSize = False
        Me.TstrCycleCount.BackColor = System.Drawing.Color.SeaShell
        Me.TstrCycleCount.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TstrCycleCount.ForeColor = System.Drawing.Color.MediumBlue
        Me.TstrCycleCount.Name = "TstrCycleCount"
        Me.TstrCycleCount.Size = New System.Drawing.Size(70, 53)
        Me.TstrCycleCount.Text = "0"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 55)
        '
        'TstrRCV
        '
        Me.TstrRCV.AutoSize = False
        Me.TstrRCV.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TstrRCV.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.TstrRCV.Name = "TstrRCV"
        Me.TstrRCV.Size = New System.Drawing.Size(65, 53)
        Me.TstrRCV.Text = "RCV"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 55)
        '
        'TstrSend
        '
        Me.TstrSend.AutoSize = False
        Me.TstrSend.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TstrSend.Name = "TstrSend"
        Me.TstrSend.Size = New System.Drawing.Size(65, 53)
        Me.TstrSend.Text = "SEND"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 55)
        '
        'TstrIO
        '
        Me.TstrIO.AutoSize = False
        Me.TstrIO.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TstrIO.Name = "TstrIO"
        Me.TstrIO.Size = New System.Drawing.Size(65, 53)
        Me.TstrIO.Text = "IO"
        '
        'ToolStripSeparator16
        '
        Me.ToolStripSeparator16.Name = "ToolStripSeparator16"
        Me.ToolStripSeparator16.Size = New System.Drawing.Size(6, 55)
        '
        'TstrCell
        '
        Me.TstrCell.AutoSize = True
        Me.TstrCell.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TstrCell.Font = New System.Drawing.Font("Arial Narrow", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TstrCell.Location = New System.Drawing.Point(6, 3)
        Me.TstrCell.Name = "TstrCell"
        Me.TstrCell.Size = New System.Drawing.Size(348, 122)
        Me.TstrCell.TabIndex = 3
        Me.TstrCell.Text = "Cell  Use"
        Me.TstrCell.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Transparent
        Me.TabPage2.Controls.Add(Me.TableLayoutPanel3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(366, 216)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Connection"
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble
        Me.TableLayoutPanel3.ColumnCount = 1
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.ToolStrip3, 0, 6)
        Me.TableLayoutPanel3.Controls.Add(Me.StatusStrip2, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.toolstripComPort, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.ToolStrip2, 0, 5)
        Me.TableLayoutPanel3.Controls.Add(Me.StatusStrip4, 0, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.StatusStrip1, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.ToolStrip1, 0, 3)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 7
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(360, 210)
        Me.TableLayoutPanel3.TabIndex = 6
        '
        'ToolStrip3
        '
        Me.ToolStrip3.BackColor = System.Drawing.Color.Transparent
        Me.ToolStrip3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ToolStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel2, Me.TstrCard})
        Me.ToolStrip3.Location = New System.Drawing.Point(3, 171)
        Me.ToolStrip3.Name = "ToolStrip3"
        Me.ToolStrip3.Size = New System.Drawing.Size(354, 36)
        Me.ToolStrip3.TabIndex = 6
        Me.ToolStrip3.Text = "ToolStrip3"
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(0, 33)
        '
        'TstrCard
        '
        Me.TstrCard.Name = "TstrCard"
        Me.TstrCard.Size = New System.Drawing.Size(52, 33)
        Me.TstrCard.Text = "TstrCard"
        '
        'StatusStrip2
        '
        Me.StatusStrip2.BackColor = System.Drawing.Color.Silver
        Me.StatusStrip2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StatusStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel2, Me.txtstatus1})
        Me.StatusStrip2.Location = New System.Drawing.Point(3, 59)
        Me.StatusStrip2.Name = "StatusStrip2"
        Me.StatusStrip2.Size = New System.Drawing.Size(354, 20)
        Me.StatusStrip2.TabIndex = 3
        Me.StatusStrip2.Text = "StatusStrip2"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(78, 15)
        Me.ToolStripStatusLabel2.Text = "[2]Send Port :"
        '
        'txtstatus1
        '
        Me.txtstatus1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstatus1.ForeColor = System.Drawing.Color.Blue
        Me.txtstatus1.Name = "txtstatus1"
        Me.txtstatus1.Size = New System.Drawing.Size(161, 15)
        Me.txtstatus1.Text = "-Please Click Connect button!!"
        '
        'ToolStrip2
        '
        Me.ToolStrip2.BackColor = System.Drawing.Color.Transparent
        Me.ToolStrip2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnConnectIO, Me.ToolStripSeparator17, Me.ToolStripSeparator21, Me.ToolStripLabel4, Me.ToolStripLabel5, Me.ToolStripSeparator27, Me.lblRxCntIO, Me.ToolStripSeparator28, Me.ToolStripLabel10, Me.ToolStripSeparator29, Me.lblTxCntIO, Me.ToolStripSeparator30, Me.ToolStripSeparator31, Me.ToolStripButton1})
        Me.ToolStrip2.Location = New System.Drawing.Point(3, 138)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(354, 30)
        Me.ToolStrip2.TabIndex = 4
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'btnConnectIO
        '
        Me.btnConnectIO.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btnConnectIO.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnConnectIO.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnConnectIO.Name = "btnConnectIO"
        Me.btnConnectIO.Size = New System.Drawing.Size(64, 27)
        Me.btnConnectIO.Text = "*connect*"
        '
        'ToolStripSeparator17
        '
        Me.ToolStripSeparator17.Name = "ToolStripSeparator17"
        Me.ToolStripSeparator17.Size = New System.Drawing.Size(6, 30)
        '
        'ToolStripSeparator21
        '
        Me.ToolStripSeparator21.Name = "ToolStripSeparator21"
        Me.ToolStripSeparator21.Size = New System.Drawing.Size(6, 30)
        '
        'ToolStripLabel4
        '
        Me.ToolStripLabel4.Name = "ToolStripLabel4"
        Me.ToolStripLabel4.Size = New System.Drawing.Size(0, 27)
        '
        'ToolStripLabel5
        '
        Me.ToolStripLabel5.Name = "ToolStripLabel5"
        Me.ToolStripLabel5.Size = New System.Drawing.Size(21, 27)
        Me.ToolStripLabel5.Text = "RX"
        '
        'ToolStripSeparator27
        '
        Me.ToolStripSeparator27.Name = "ToolStripSeparator27"
        Me.ToolStripSeparator27.Size = New System.Drawing.Size(6, 30)
        '
        'lblRxCntIO
        '
        Me.lblRxCntIO.Name = "lblRxCntIO"
        Me.lblRxCntIO.Size = New System.Drawing.Size(37, 27)
        Me.lblRxCntIO.Text = "00000"
        Me.lblRxCntIO.ToolTipText = "count bytes received"
        '
        'ToolStripSeparator28
        '
        Me.ToolStripSeparator28.Name = "ToolStripSeparator28"
        Me.ToolStripSeparator28.Size = New System.Drawing.Size(6, 30)
        '
        'ToolStripLabel10
        '
        Me.ToolStripLabel10.Name = "ToolStripLabel10"
        Me.ToolStripLabel10.Size = New System.Drawing.Size(21, 27)
        Me.ToolStripLabel10.Text = "TX"
        '
        'ToolStripSeparator29
        '
        Me.ToolStripSeparator29.Name = "ToolStripSeparator29"
        Me.ToolStripSeparator29.Size = New System.Drawing.Size(6, 30)
        '
        'lblTxCntIO
        '
        Me.lblTxCntIO.Name = "lblTxCntIO"
        Me.lblTxCntIO.Size = New System.Drawing.Size(37, 27)
        Me.lblTxCntIO.Text = "00000"
        Me.lblTxCntIO.ToolTipText = "count sent bytes"
        '
        'ToolStripSeparator30
        '
        Me.ToolStripSeparator30.Name = "ToolStripSeparator30"
        Me.ToolStripSeparator30.Size = New System.Drawing.Size(6, 30)
        '
        'ToolStripSeparator31
        '
        Me.ToolStripSeparator31.Name = "ToolStripSeparator31"
        Me.ToolStripSeparator31.Size = New System.Drawing.Size(6, 30)
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(23, 27)
        Me.ToolStripButton1.Text = "ToolStripButton1"
        '
        'StatusStrip4
        '
        Me.StatusStrip4.BackColor = System.Drawing.Color.Silver
        Me.StatusStrip4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StatusStrip4.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel3, Me.txtstatus2})
        Me.StatusStrip4.Location = New System.Drawing.Point(3, 115)
        Me.StatusStrip4.Name = "StatusStrip4"
        Me.StatusStrip4.Size = New System.Drawing.Size(354, 20)
        Me.StatusStrip4.TabIndex = 5
        Me.StatusStrip4.Text = "StatusStrip4"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(64, 15)
        Me.ToolStripStatusLabel3.Text = "[3]IO Port :"
        '
        'txtstatus2
        '
        Me.txtstatus2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstatus2.ForeColor = System.Drawing.Color.Blue
        Me.txtstatus2.Name = "txtstatus2"
        Me.txtstatus2.Size = New System.Drawing.Size(161, 15)
        Me.txtstatus2.Text = "-Please Click Connect button!!"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.Silver
        Me.StatusStrip1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.status0})
        Me.StatusStrip1.Location = New System.Drawing.Point(3, 3)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(354, 20)
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(89, 15)
        Me.ToolStripStatusLabel1.Text = "[1]Receive port:"
        '
        'status0
        '
        Me.status0.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.status0.ForeColor = System.Drawing.Color.Blue
        Me.status0.Name = "status0"
        Me.status0.Size = New System.Drawing.Size(161, 15)
        Me.status0.Text = "-Please Click Connect button!!"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnConnectSend, Me.ToolStripSeparator19, Me.ToolStripSeparator3, Me.ToolStripLabel6, Me.ToolStripLabel1, Me.ToolStripSeparator18, Me.lblRxCntSend, Me.ToolStripSeparator20, Me.ToolStripLabel3, Me.ToolStripSeparator13, Me.lblTxCntsend, Me.ToolStripSeparator14, Me.ToolStripSeparator15})
        Me.ToolStrip1.Location = New System.Drawing.Point(3, 82)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(354, 30)
        Me.ToolStrip1.TabIndex = 2
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btnConnectSend
        '
        Me.btnConnectSend.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btnConnectSend.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnConnectSend.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnConnectSend.Name = "btnConnectSend"
        Me.btnConnectSend.Size = New System.Drawing.Size(64, 27)
        Me.btnConnectSend.Text = "*connect*"
        '
        'ToolStripSeparator19
        '
        Me.ToolStripSeparator19.Name = "ToolStripSeparator19"
        Me.ToolStripSeparator19.Size = New System.Drawing.Size(6, 30)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 30)
        '
        'ToolStripLabel6
        '
        Me.ToolStripLabel6.Name = "ToolStripLabel6"
        Me.ToolStripLabel6.Size = New System.Drawing.Size(0, 27)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(21, 27)
        Me.ToolStripLabel1.Text = "RX"
        '
        'ToolStripSeparator18
        '
        Me.ToolStripSeparator18.Name = "ToolStripSeparator18"
        Me.ToolStripSeparator18.Size = New System.Drawing.Size(6, 30)
        '
        'lblRxCntSend
        '
        Me.lblRxCntSend.Name = "lblRxCntSend"
        Me.lblRxCntSend.Size = New System.Drawing.Size(37, 27)
        Me.lblRxCntSend.Text = "00000"
        Me.lblRxCntSend.ToolTipText = "count bytes received"
        '
        'ToolStripSeparator20
        '
        Me.ToolStripSeparator20.Name = "ToolStripSeparator20"
        Me.ToolStripSeparator20.Size = New System.Drawing.Size(6, 30)
        '
        'ToolStripLabel3
        '
        Me.ToolStripLabel3.Name = "ToolStripLabel3"
        Me.ToolStripLabel3.Size = New System.Drawing.Size(21, 27)
        Me.ToolStripLabel3.Text = "TX"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(6, 30)
        '
        'lblTxCntsend
        '
        Me.lblTxCntsend.Name = "lblTxCntsend"
        Me.lblTxCntsend.Size = New System.Drawing.Size(37, 27)
        Me.lblTxCntsend.Text = "00000"
        Me.lblTxCntsend.ToolTipText = "count sent bytes"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(6, 30)
        '
        'ToolStripSeparator15
        '
        Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
        Me.ToolStripSeparator15.Size = New System.Drawing.Size(6, 30)
        '
        'SplitContainer2
        '
        Me.SplitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.TableLayoutPanel8)
        Me.SplitContainer2.Panel1.Controls.Add(Me.lblsignal)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.TableLayoutPanel1)
        Me.SplitContainer2.Panel2.Controls.Add(Me.StatusStrip5)
        Me.SplitContainer2.Panel2.Controls.Add(Me.StatusStrip6)
        Me.SplitContainer2.Size = New System.Drawing.Size(376, 509)
        Me.SplitContainer2.SplitterDistance = 460
        Me.SplitContainer2.TabIndex = 0
        '
        'TableLayoutPanel8
        '
        Me.TableLayoutPanel8.ColumnCount = 1
        Me.TableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel8.Controls.Add(Me.TableLayoutPanel4, 0, 1)
        Me.TableLayoutPanel8.Controls.Add(Me.TableLayoutPanel9, 0, 0)
        Me.TableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel8.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel8.Name = "TableLayoutPanel8"
        Me.TableLayoutPanel8.RowCount = 2
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.331878!))
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 93.66812!))
        Me.TableLayoutPanel8.Size = New System.Drawing.Size(374, 458)
        Me.TableLayoutPanel8.TabIndex = 138
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 5
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70.15945!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 3.872437!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.96811!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.Button2, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Button4, 3, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.TableLayoutPanel5, 3, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Label7, 1, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.TableLayoutPanel6, 1, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.TableLayoutPanel7, 3, 4)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(3, 32)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 6
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.347826!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 42.75362!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.347826!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.67633!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(368, 423)
        Me.TableLayoutPanel4.TabIndex = 137
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(23, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(227, 68)
        Me.Button2.TabIndex = 129
        Me.Button2.Text = "Signal:"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.Location = New System.Drawing.Point(268, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(80, 68)
        Me.Button4.TabIndex = 134
        Me.Button4.Text = "-"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.UseVisualStyleBackColor = False
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.ColumnCount = 1
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.lblIO01, 0, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label8, 0, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.lblIO02, 0, 2)
        Me.TableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(268, 95)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 3
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(80, 171)
        Me.TableLayoutPanel5.TabIndex = 135
        '
        'lblIO01
        '
        Me.lblIO01.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblIO01.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblIO01.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblIO01.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIO01.Location = New System.Drawing.Point(3, 0)
        Me.lblIO01.Name = "lblIO01"
        Me.lblIO01.Size = New System.Drawing.Size(74, 76)
        Me.lblIO01.TabIndex = 0
        Me.lblIO01.Text = "S1"
        Me.lblIO01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 76)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 17)
        Me.Label8.TabIndex = 136
        Me.Label8.Text = "Label8"
        '
        'lblIO02
        '
        Me.lblIO02.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblIO02.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblIO02.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblIO02.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIO02.Location = New System.Drawing.Point(3, 93)
        Me.lblIO02.Name = "lblIO02"
        Me.lblIO02.Size = New System.Drawing.Size(74, 78)
        Me.lblIO02.TabIndex = 1
        Me.lblIO02.Text = "S2"
        Me.lblIO02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.LightGray
        Me.Label7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(23, 92)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(227, 177)
        Me.Label7.TabIndex = 131
        Me.Label7.Text = "Kitting Daisha"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.ColumnCount = 1
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel6.Controls.Add(Me.Label19, 0, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.ListInQueue1, 0, 2)
        Me.TableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(23, 290)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 3
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 42.14876!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.06612!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(227, 121)
        Me.TableLayoutPanel6.TabIndex = 136
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.LightGray
        Me.Label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label19.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label19.Location = New System.Drawing.Point(3, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(221, 50)
        Me.Label19.TabIndex = 121
        Me.Label19.Text = "-:-"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ListInQueue1
        '
        Me.ListInQueue1.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.ListInQueue1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListInQueue1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListInQueue1.FormattingEnabled = True
        Me.ListInQueue1.ItemHeight = 25
        Me.ListInQueue1.Location = New System.Drawing.Point(3, 60)
        Me.ListInQueue1.Name = "ListInQueue1"
        Me.ListInQueue1.Size = New System.Drawing.Size(221, 58)
        Me.ListInQueue1.TabIndex = 125
        '
        'TableLayoutPanel7
        '
        Me.TableLayoutPanel7.ColumnCount = 1
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel7.Controls.Add(Me.Button3, 0, 0)
        Me.TableLayoutPanel7.Controls.Add(Me.Button1, 0, 2)
        Me.TableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel7.Location = New System.Drawing.Point(268, 290)
        Me.TableLayoutPanel7.Name = "TableLayoutPanel7"
        Me.TableLayoutPanel7.RowCount = 3
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.0!))
        Me.TableLayoutPanel7.Size = New System.Drawing.Size(80, 121)
        Me.TableLayoutPanel7.TabIndex = 137
        '
        'Button3
        '
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button3.Location = New System.Drawing.Point(3, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(74, 50)
        Me.Button3.TabIndex = 126
        Me.Button3.Text = "CLR" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Data"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button1.Location = New System.Drawing.Point(3, 66)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(74, 52)
        Me.Button1.TabIndex = 128
        Me.Button1.Text = "Cancel" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "1st"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel9
        '
        Me.TableLayoutPanel9.ColumnCount = 4
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel9.Controls.Add(Me.CheckBox1, 0, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.CheckBox2, 1, 0)
        Me.TableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel9.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel9.Name = "TableLayoutPanel9"
        Me.TableLayoutPanel9.RowCount = 1
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel9.Size = New System.Drawing.Size(368, 23)
        Me.TableLayoutPanel9.TabIndex = 138
        '
        'CheckBox1
        '
        Me.CheckBox1.BackColor = System.Drawing.Color.Transparent
        Me.CheckBox1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CheckBox1.Location = New System.Drawing.Point(3, 3)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(86, 16)
        Me.CheckBox1.TabIndex = 132
        Me.CheckBox1.Text = "Use Check time "
        Me.CheckBox1.UseVisualStyleBackColor = False
        '
        'CheckBox2
        '
        Me.CheckBox2.BackColor = System.Drawing.Color.Transparent
        Me.CheckBox2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CheckBox2.Location = New System.Drawing.Point(95, 3)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(67, 16)
        Me.CheckBox2.TabIndex = 135
        Me.CheckBox2.Text = "Not use"
        Me.CheckBox2.UseVisualStyleBackColor = False
        '
        'lblsignal
        '
        Me.lblsignal.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblsignal.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsignal.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblsignal.Location = New System.Drawing.Point(81, -86)
        Me.lblsignal.Name = "lblsignal"
        Me.lblsignal.Size = New System.Drawing.Size(139, 58)
        Me.lblsignal.TabIndex = 120
        Me.lblsignal.Text = "Request Start"
        Me.lblsignal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.lblA5, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA6, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA7, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA8, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label13, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA1, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA2, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA3, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.lblA4, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label12, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 2, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 22)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(374, 0)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'lblA5
        '
        Me.lblA5.AutoSize = True
        Me.lblA5.Location = New System.Drawing.Point(283, 1)
        Me.lblA5.Name = "lblA5"
        Me.lblA5.Size = New System.Drawing.Size(10, 1)
        Me.lblA5.TabIndex = 12
        Me.lblA5.Text = "-"
        '
        'lblA6
        '
        Me.lblA6.AutoSize = True
        Me.lblA6.Location = New System.Drawing.Point(283, -19)
        Me.lblA6.Name = "lblA6"
        Me.lblA6.Size = New System.Drawing.Size(10, 1)
        Me.lblA6.TabIndex = 13
        Me.lblA6.Text = "-"
        '
        'lblA7
        '
        Me.lblA7.AutoSize = True
        Me.lblA7.Location = New System.Drawing.Point(283, -39)
        Me.lblA7.Name = "lblA7"
        Me.lblA7.Size = New System.Drawing.Size(10, 13)
        Me.lblA7.TabIndex = 14
        Me.lblA7.Text = "-"
        '
        'lblA8
        '
        Me.lblA8.AutoSize = True
        Me.lblA8.Location = New System.Drawing.Point(283, -18)
        Me.lblA8.Name = "lblA8"
        Me.lblA8.Size = New System.Drawing.Size(10, 13)
        Me.lblA8.TabIndex = 15
        Me.lblA8.Text = "-"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(190, -19)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(29, 1)
        Me.Label13.TabIndex = 10
        Me.Label13.Text = "RAdd"
        '
        'lblA1
        '
        Me.lblA1.AutoSize = True
        Me.lblA1.Location = New System.Drawing.Point(97, 1)
        Me.lblA1.Name = "lblA1"
        Me.lblA1.Size = New System.Drawing.Size(10, 1)
        Me.lblA1.TabIndex = 4
        Me.lblA1.Text = "-"
        '
        'lblA2
        '
        Me.lblA2.AutoSize = True
        Me.lblA2.Location = New System.Drawing.Point(97, -19)
        Me.lblA2.Name = "lblA2"
        Me.lblA2.Size = New System.Drawing.Size(10, 1)
        Me.lblA2.TabIndex = 7
        Me.lblA2.Text = "-"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 1)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 1)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "BG1,2:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, -19)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 1)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "BG3,4:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, -39)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 12)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "FST,FC:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, -18)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Card,Count:"
        '
        'lblA3
        '
        Me.lblA3.AutoSize = True
        Me.lblA3.Location = New System.Drawing.Point(97, -39)
        Me.lblA3.Name = "lblA3"
        Me.lblA3.Size = New System.Drawing.Size(10, 13)
        Me.lblA3.TabIndex = 5
        Me.lblA3.Text = "-"
        '
        'lblA4
        '
        Me.lblA4.AutoSize = True
        Me.lblA4.Location = New System.Drawing.Point(97, -18)
        Me.lblA4.Name = "lblA4"
        Me.lblA4.Size = New System.Drawing.Size(10, 13)
        Me.lblA4.TabIndex = 6
        Me.lblA4.Text = "-"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(190, -39)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(37, 12)
        Me.Label14.TabIndex = 11
        Me.Label14.Text = "224Add"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(190, -18)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(37, 12)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "217Add"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(190, 1)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(61, 1)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "AddChk/Q:"
        '
        'StatusStrip5
        '
        Me.StatusStrip5.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TstaTCPSignal, Me.ToolStripStatusLabel4})
        Me.StatusStrip5.Location = New System.Drawing.Point(0, 21)
        Me.StatusStrip5.Name = "StatusStrip5"
        Me.StatusStrip5.Size = New System.Drawing.Size(374, 22)
        Me.StatusStrip5.TabIndex = 0
        Me.StatusStrip5.Text = "StatusStrip5"
        '
        'TstaTCPSignal
        '
        Me.TstaTCPSignal.Name = "TstaTCPSignal"
        Me.TstaTCPSignal.Size = New System.Drawing.Size(67, 17)
        Me.TstaTCPSignal.Text = "Signal Rcv::"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(22, 17)
        Me.ToolStripStatusLabel4.Text = "IO:"
        '
        'StatusStrip6
        '
        Me.StatusStrip6.Dock = System.Windows.Forms.DockStyle.Top
        Me.StatusStrip6.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel5, Me.ToolStripStatusLabel6, Me.lblReceive, Me.T1, Me.T2})
        Me.StatusStrip6.Location = New System.Drawing.Point(0, 0)
        Me.StatusStrip6.Name = "StatusStrip6"
        Me.StatusStrip6.Size = New System.Drawing.Size(374, 22)
        Me.StatusStrip6.TabIndex = 130
        Me.StatusStrip6.Text = "StatusStrip6"
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(20, 17)
        Me.ToolStripStatusLabel5.Text = "T2"
        '
        'ToolStripStatusLabel6
        '
        Me.ToolStripStatusLabel6.Name = "ToolStripStatusLabel6"
        Me.ToolStripStatusLabel6.Size = New System.Drawing.Size(20, 17)
        Me.ToolStripStatusLabel6.Text = "T2"
        '
        'lblReceive
        '
        Me.lblReceive.Name = "lblReceive"
        Me.lblReceive.Size = New System.Drawing.Size(60, 17)
        Me.lblReceive.Text = "lblReceive"
        '
        'T1
        '
        Me.T1.Name = "T1"
        Me.T1.Size = New System.Drawing.Size(20, 17)
        Me.T1.Text = "T1"
        '
        'T2
        '
        Me.T2.Name = "T2"
        Me.T2.Size = New System.Drawing.Size(20, 17)
        Me.T2.Text = "T2"
        '
        'mnuTxBox
        '
        Me.mnuTxBox.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyTx, Me.PasteTx, Me.CutTx, Me.SendLine, Me.SendSelect})
        Me.mnuTxBox.Name = "MenuTxBox"
        Me.mnuTxBox.Size = New System.Drawing.Size(150, 114)
        '
        'CopyTx
        '
        Me.CopyTx.Image = Global.comTerm.My.Resources.Resources.Copy
        Me.CopyTx.Name = "CopyTx"
        Me.CopyTx.Size = New System.Drawing.Size(149, 22)
        Me.CopyTx.Text = "Copy"
        '
        'PasteTx
        '
        Me.PasteTx.Image = Global.comTerm.My.Resources.Resources.Paste
        Me.PasteTx.Name = "PasteTx"
        Me.PasteTx.Size = New System.Drawing.Size(149, 22)
        Me.PasteTx.Text = "Paste"
        '
        'CutTx
        '
        Me.CutTx.Image = Global.comTerm.My.Resources.Resources.Clipboard_Cut
        Me.CutTx.Name = "CutTx"
        Me.CutTx.Size = New System.Drawing.Size(149, 22)
        Me.CutTx.Text = "Cut"
        '
        'SendLine
        '
        Me.SendLine.Image = Global.comTerm.My.Resources.Resources.Arrow1_Right
        Me.SendLine.Name = "SendLine"
        Me.SendLine.Size = New System.Drawing.Size(149, 22)
        Me.SendLine.Text = "send line"
        '
        'SendSelect
        '
        Me.SendSelect.Image = Global.comTerm.My.Resources.Resources.Arrow2_Right
        Me.SendSelect.Name = "SendSelect"
        Me.SendSelect.Size = New System.Drawing.Size(149, 22)
        Me.SendSelect.Text = "send selection"
        '
        'BackgroundWorker1
        '
        '
        'BackgroundWorker2
        '
        '
        'BackgroundWorker4
        '
        '
        'BackgroundWorker5
        '
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 500
        '
        'FileTool
        '
        Me.FileTool.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadConfig, Me.SaveConfig, Me.ExitTool})
        Me.FileTool.Name = "FileTool"
        Me.FileTool.Size = New System.Drawing.Size(37, 20)
        Me.FileTool.Text = "File"
        '
        'LoadConfig
        '
        Me.LoadConfig.Image = Global.comTerm.My.Resources.Resources.Disk
        Me.LoadConfig.Name = "LoadConfig"
        Me.LoadConfig.Size = New System.Drawing.Size(137, 22)
        Me.LoadConfig.Text = "Load config"
        '
        'SaveConfig
        '
        Me.SaveConfig.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tcboselect, Me.cboComPort, Me.cboBaudrate, Me.cboDataBits, Me.cboParity, Me.cboStopbits, Me.cboDelay, Me.cboThreshold, Me.ToolStripMenuItem1})
        Me.SaveConfig.Image = Global.comTerm.My.Resources.Resources.Disk_download
        Me.SaveConfig.Name = "SaveConfig"
        Me.SaveConfig.Size = New System.Drawing.Size(137, 22)
        Me.SaveConfig.Text = "save config"
        '
        'Tcboselect
        '
        Me.Tcboselect.Items.AddRange(New Object() {"Receive Comport", "Send Comport"})
        Me.Tcboselect.Name = "Tcboselect"
        Me.Tcboselect.Size = New System.Drawing.Size(121, 23)
        Me.Tcboselect.Text = "<Select one>"
        '
        'cboComPort
        '
        Me.cboComPort.AutoSize = False
        Me.cboComPort.MergeAction = System.Windows.Forms.MergeAction.MatchOnly
        Me.cboComPort.Name = "cboComPort"
        Me.cboComPort.Size = New System.Drawing.Size(100, 23)
        Me.cboComPort.Text = "<Port>"
        '
        'cboBaudrate
        '
        Me.cboBaudrate.AutoSize = False
        Me.cboBaudrate.DropDownWidth = 50
        Me.cboBaudrate.Items.AddRange(New Object() {"2400", "4800", "9600", "19200", "38400", "115200"})
        Me.cboBaudrate.Name = "cboBaudrate"
        Me.cboBaudrate.Size = New System.Drawing.Size(100, 23)
        Me.cboBaudrate.Text = "<Baud>"
        '
        'cboDataBits
        '
        Me.cboDataBits.AutoSize = False
        Me.cboDataBits.Items.AddRange(New Object() {"7", "8"})
        Me.cboDataBits.Name = "cboDataBits"
        Me.cboDataBits.Size = New System.Drawing.Size(100, 23)
        Me.cboDataBits.Text = "<data>"
        '
        'cboParity
        '
        Me.cboParity.AutoSize = False
        Me.cboParity.Items.AddRange(New Object() {"None", "Even", "Mark", "Odd", "Space"})
        Me.cboParity.Name = "cboParity"
        Me.cboParity.Size = New System.Drawing.Size(100, 23)
        Me.cboParity.Text = "<Parity>"
        '
        'cboStopbits
        '
        Me.cboStopbits.AutoSize = False
        Me.cboStopbits.DropDownWidth = 50
        Me.cboStopbits.Items.AddRange(New Object() {"None", "One", "Two"})
        Me.cboStopbits.Name = "cboStopbits"
        Me.cboStopbits.Size = New System.Drawing.Size(100, 23)
        Me.cboStopbits.Text = "<Stop>"
        '
        'cboDelay
        '
        Me.cboDelay.AutoSize = False
        Me.cboDelay.Items.AddRange(New Object() {"1", "2", "5", "10", "20", "50", "100", "200", "500", "1000"})
        Me.cboDelay.Name = "cboDelay"
        Me.cboDelay.Size = New System.Drawing.Size(100, 23)
        Me.cboDelay.Text = "<Delay>"
        Me.cboDelay.ToolTipText = "Datareceived handle delay"
        '
        'cboThreshold
        '
        Me.cboThreshold.AutoSize = False
        Me.cboThreshold.Items.AddRange(New Object() {"1", "2", "5", "10", "20", "50", "100", "200", "500", "1000"})
        Me.cboThreshold.Name = "cboThreshold"
        Me.cboThreshold.Size = New System.Drawing.Size(100, 23)
        Me.cboThreshold.Text = "<thresh>"
        Me.cboThreshold.ToolTipText = ".receivedBytesThreshold property"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.BackColor = System.Drawing.Color.Silver
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(181, 22)
        Me.ToolStripMenuItem1.Text = "Save Data"
        '
        'ExitTool
        '
        Me.ExitTool.Image = Global.comTerm.My.Resources.Resources.Standby
        Me.ExitTool.Name = "ExitTool"
        Me.ExitTool.Size = New System.Drawing.Size(137, 22)
        Me.ExitTool.Text = "Exit"
        '
        'OptionsTool
        '
        Me.OptionsTool.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReceiveboxFontToolStripMenuItem, Me.OpenFormToolStripMenuItem, Me.btnSettime, Me.ToolStripMenuItem4, Me.ResetTimeToolStripMenuItem, Me.ResetValueToolStripMenuItem, Me.DelayFinalSendToolStripMenuItem, Me.DelayBeforeResendToolStripMenuItem})
        Me.OptionsTool.Name = "OptionsTool"
        Me.OptionsTool.Size = New System.Drawing.Size(61, 20)
        Me.OptionsTool.Text = "Options"
        '
        'ReceiveboxFontToolStripMenuItem
        '
        Me.ReceiveboxFontToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LargeToolStripMenuItem, Me.MediumToolStripMenuItem, Me.SmallToolStripMenuItem})
        Me.ReceiveboxFontToolStripMenuItem.Name = "ReceiveboxFontToolStripMenuItem"
        Me.ReceiveboxFontToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ReceiveboxFontToolStripMenuItem.Text = "font"
        '
        'LargeToolStripMenuItem
        '
        Me.LargeToolStripMenuItem.Name = "LargeToolStripMenuItem"
        Me.LargeToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.LargeToolStripMenuItem.Text = "Large"
        '
        'MediumToolStripMenuItem
        '
        Me.MediumToolStripMenuItem.Name = "MediumToolStripMenuItem"
        Me.MediumToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.MediumToolStripMenuItem.Text = "Medium"
        '
        'SmallToolStripMenuItem
        '
        Me.SmallToolStripMenuItem.Name = "SmallToolStripMenuItem"
        Me.SmallToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.SmallToolStripMenuItem.Text = "Small"
        '
        'OpenFormToolStripMenuItem
        '
        Me.OpenFormToolStripMenuItem.Name = "OpenFormToolStripMenuItem"
        Me.OpenFormToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.OpenFormToolStripMenuItem.Text = "open form"
        '
        'btnSettime
        '
        Me.btnSettime.Name = "btnSettime"
        Me.btnSettime.Size = New System.Drawing.Size(181, 22)
        Me.btnSettime.Text = "Set time"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(181, 22)
        Me.ToolStripMenuItem4.Text = "Set cycle time"
        '
        'ResetTimeToolStripMenuItem
        '
        Me.ResetTimeToolStripMenuItem.Name = "ResetTimeToolStripMenuItem"
        Me.ResetTimeToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ResetTimeToolStripMenuItem.Text = "Reset time"
        '
        'ResetValueToolStripMenuItem
        '
        Me.ResetValueToolStripMenuItem.Name = "ResetValueToolStripMenuItem"
        Me.ResetValueToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ResetValueToolStripMenuItem.Text = "Reset Value"
        '
        'DelayFinalSendToolStripMenuItem
        '
        Me.DelayFinalSendToolStripMenuItem.Name = "DelayFinalSendToolStripMenuItem"
        Me.DelayFinalSendToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DelayFinalSendToolStripMenuItem.Text = "Delay Final Send"
        '
        'DelayBeforeResendToolStripMenuItem
        '
        Me.DelayBeforeResendToolStripMenuItem.Name = "DelayBeforeResendToolStripMenuItem"
        Me.DelayBeforeResendToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.DelayBeforeResendToolStripMenuItem.Text = "Delay Before Resend"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(12, 20)
        '
        'Menu1
        '
        Me.Menu1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileTool, Me.OptionsTool, Me.ToolStripMenuItem3})
        Me.Menu1.Location = New System.Drawing.Point(0, 0)
        Me.Menu1.Name = "Menu1"
        Me.Menu1.Size = New System.Drawing.Size(376, 24)
        Me.Menu1.TabIndex = 2
        Me.Menu1.Text = "MenuStrip1"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label9.Font = New System.Drawing.Font("Arial Narrow", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(5, 2)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(346, 85)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "Cell  Use"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(376, 781)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.Menu1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.Menu1
        Me.MinimumSize = New System.Drawing.Size(330, 500)
        Me.Name = "frmMain"
        Me.Text = "AGV Control -"
        Me.toolstripComPort.ResumeLayout(False)
        Me.toolstripComPort.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.StatusStrip7.ResumeLayout(False)
        Me.StatusStrip7.PerformLayout()
        Me.StatusStrip3.ResumeLayout(False)
        Me.StatusStrip3.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.ToolStrip3.ResumeLayout(False)
        Me.ToolStrip3.PerformLayout()
        Me.StatusStrip2.ResumeLayout(False)
        Me.StatusStrip2.PerformLayout()
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.StatusStrip4.ResumeLayout(False)
        Me.StatusStrip4.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.Panel2.PerformLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.TableLayoutPanel8.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.TableLayoutPanel5.PerformLayout()
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.TableLayoutPanel7.ResumeLayout(False)
        Me.TableLayoutPanel9.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.StatusStrip5.ResumeLayout(False)
        Me.StatusStrip5.PerformLayout()
        Me.StatusStrip6.ResumeLayout(False)
        Me.StatusStrip6.PerformLayout()
        Me.mnuTxBox.ResumeLayout(False)
        Me.Menu1.ResumeLayout(False)
        Me.Menu1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents toolstripComPort As System.Windows.Forms.ToolStrip
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents mnuTxBox As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CopyTx As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteTx As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CutTx As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendLine As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendSelect As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents Label2 As ToolStripLabel
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents lblTxCnt As ToolStripLabel
    Friend WithEvents ToolStripSeparator7 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator12 As ToolStripSeparator
    Friend WithEvents Label1 As ToolStripLabel
    Friend WithEvents ToolStripSeparator9 As ToolStripSeparator
    Friend WithEvents lblRxCnt As ToolStripLabel
    Friend WithEvents ToolStripSeparator10 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator11 As ToolStripSeparator
    Friend WithEvents btnConnect As ToolStripButton
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btnConnectSend As ToolStripButton
    Friend WithEvents ToolStripSeparator19 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents ToolStripLabel6 As ToolStripLabel
    Friend WithEvents ToolStripSeparator18 As ToolStripSeparator
    Friend WithEvents lblRxCntSend As ToolStripLabel
    Friend WithEvents ToolStripSeparator20 As ToolStripSeparator
    Friend WithEvents ToolStripLabel3 As ToolStripLabel
    Friend WithEvents ToolStripSeparator13 As ToolStripSeparator
    Friend WithEvents lblTxCntsend As ToolStripLabel
    Friend WithEvents ToolStripSeparator14 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator15 As ToolStripSeparator
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents status0 As ToolStripStatusLabel
    Friend WithEvents StatusStrip3 As StatusStrip
    Friend WithEvents ToolStripSeparator23 As ToolStripSeparator
    Friend WithEvents lblIO03 As ToolStripLabel
    Friend WithEvents TstrCycleCount As ToolStripLabel
    Friend WithEvents StatusStrip2 As StatusStrip
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents txtstatus1 As ToolStripStatusLabel
    Friend WithEvents StatusStrip4 As StatusStrip
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents txtstatus2 As ToolStripStatusLabel
    Friend WithEvents ToolStrip2 As ToolStrip
    Friend WithEvents btnConnectIO As ToolStripButton
    Friend WithEvents ToolStripSeparator17 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator21 As ToolStripSeparator
    Friend WithEvents ToolStripLabel4 As ToolStripLabel
    Friend WithEvents ToolStripLabel5 As ToolStripLabel
    Friend WithEvents ToolStripSeparator27 As ToolStripSeparator
    Friend WithEvents lblRxCntIO As ToolStripLabel
    Friend WithEvents ToolStripSeparator28 As ToolStripSeparator
    Friend WithEvents ToolStripLabel10 As ToolStripLabel
    Friend WithEvents ToolStripSeparator29 As ToolStripSeparator
    Friend WithEvents lblTxCntIO As ToolStripLabel
    Friend WithEvents ToolStripSeparator30 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator31 As ToolStripSeparator
    Friend WithEvents lblIO02 As Label
    Friend WithEvents lblIO01 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents ListInQueue1 As ListBox
    Friend WithEvents lblsignal As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker3 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker4 As System.ComponentModel.BackgroundWorker
    Friend WithEvents StatusStrip5 As StatusStrip
    Friend WithEvents TstaTCPSignal As ToolStripStatusLabel
    Friend WithEvents BackgroundWorker5 As System.ComponentModel.BackgroundWorker
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents lblA5 As Label
    Friend WithEvents lblA6 As Label
    Friend WithEvents lblA7 As Label
    Friend WithEvents lblA8 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lblA1 As Label
    Friend WithEvents lblA2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblA3 As Label
    Friend WithEvents lblA4 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Timer2 As Timer
    Friend WithEvents ToolStripStatusLabel4 As ToolStripStatusLabel
    Friend WithEvents Button1 As Button
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents FileTool As ToolStripMenuItem
    Friend WithEvents LoadConfig As ToolStripMenuItem
    Friend WithEvents SaveConfig As ToolStripMenuItem
    Friend WithEvents Tcboselect As ToolStripComboBox
    Friend WithEvents cboComPort As ToolStripComboBox
    Friend WithEvents cboBaudrate As ToolStripComboBox
    Friend WithEvents cboDataBits As ToolStripComboBox
    Friend WithEvents cboParity As ToolStripComboBox
    Friend WithEvents cboStopbits As ToolStripComboBox
    Friend WithEvents cboDelay As ToolStripComboBox
    Friend WithEvents cboThreshold As ToolStripComboBox
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ExitTool As ToolStripMenuItem
    Friend WithEvents OptionsTool As ToolStripMenuItem
    Friend WithEvents ReceiveboxFontToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LargeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MediumToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SmallToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenFormToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents Menu1 As MenuStrip
    Friend WithEvents btnSettime As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents Button2 As Button
    Friend WithEvents ResetTimeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StatusStrip6 As StatusStrip
    Friend WithEvents lblReceive As ToolStripStatusLabel
    Friend WithEvents Label7 As Label
    Friend WithEvents ResetValueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents DelayFinalSendToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents T1 As ToolStripStatusLabel
    Friend WithEvents Button4 As Button
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents Label8 As Label
    Friend WithEvents DelayBeforeResendToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents T2 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel5 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel6 As ToolStripStatusLabel
    Private WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents TstrCell As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents TstrRCV As ToolStripLabel
    Friend WithEvents TstrSend As ToolStripLabel
    Friend WithEvents TstrIO As ToolStripLabel
    Friend WithEvents ToolStrip3 As ToolStrip
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents TstrCard As ToolStripLabel
    Friend WithEvents StatusStrip7 As StatusStrip
    Friend WithEvents ToolStripSeparator22 As ToolStripSeparator
    Friend WithEvents ToolStripLabel7 As ToolStripLabel
    Friend WithEvents ToolStripSeparator24 As ToolStripSeparator
    Friend WithEvents ToolStripLabel9 As ToolStripLabel
    Friend WithEvents ToolStripLabel13 As ToolStripLabel
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripLabel16 As ToolStripLabel
    Friend WithEvents ToolStripSeparator32 As ToolStripSeparator
    Friend WithEvents ToolStripLabel17 As ToolStripLabel
    Friend WithEvents ToolStripSeparator33 As ToolStripSeparator
    Friend WithEvents ToolStripLabel18 As ToolStripLabel
    Friend WithEvents ToolStripSeparator34 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator25 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator8 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator16 As ToolStripSeparator
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel7 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel8 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents ToolStripSeparator26 As ToolStripSeparator
End Class
