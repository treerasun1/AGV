﻿Option Strict On
Option Infer On
Imports System.ComponentModel
Imports System.IO
Imports System.IO.Ports
Imports System.Text
Imports System.Threading
''' <summary>
''' Demo Serialport terminal Ellen Ramcke 2012
''' </summary>
''' <remarks>update 2012-06-27</remarks>
Public Class frmMain
    Private WithEvents _rs232 As New RS232
    Private charsInline As Integer = 80  ' def n start
    Private isConnected As Boolean
    Private RXcount, TXcount As Integer
    Private comparams() As String = RS232.DefaultParams
    Private buffer() As Byte

    Private WithEvents _rs232Send As New RS232
    Private charsInlineSend As Integer = 80  ' def n start
    Private isConnectedSend As Boolean
    Private RXcountSend, TXcountSend As Integer
    Private comparamsSend() As String = RS232.DefaultParams
    Private bufferSend() As Byte

    Private WithEvents _rs232IO As New RS232
    Private charsInlineIO As Integer = 63  ' def n start
    Private isConnectedIO As Boolean
    Private RXcountIO, TXcountIO As Integer
    Private comparamsIO() As String = RS232.DefaultParams
    Private bufferIO() As Byte

    Public Shared socketAGVControl As New AGVTcpControl()
    ' Public Shared Master_cell, Master_process, Master_circleTime As String
    Dim logE As LogFile = New LogFile("D:/IprojectDB/AGV_Monitor_Log/Err_log", True)
    '  Dim ascT1 As New Thread(New ThreadStart(AddressOf TCPAutoStartControlTimer))
    Public Shared FlagTCP As Integer

    Dim cell, Temp_224, Temp_217 As String
    Dim status217 As Boolean
    Dim statusbox, boxstatus, strtemp, show_ADD, show_result, receiveadd As String
    Dim responsefromAGV, straddcheck, memmopoint As String
    Dim totaltime_wait_AGV, totaltime_wait_Kitting As String


    Dim AGVindex, AGVaddress, AGVline, AGVname As String()
    Dim SSS As Integer
    Dim cycletime As Integer = 60
    Dim DelayFinal As Integer = 2
    Dim DelayBefore As Integer = 5
    Dim TempA, Ssecand As Integer
    Dim tmpbinaryDigits As String
    Dim Emer, SWGreen, Sensor1, Sensor2 As Integer

    Dim colorFrm As Color
    Dim colorlabel As Color
    Dim colorFore As Color
    Dim flagcancel, flagRCVsignal, flagreset, flagNowStart, flaglooptime, flagcheckio As Boolean
    Private Comconfig As ComConfigure = New ComConfigure()
    'queue
    Dim Queue_signal As Integer
    Public obj As Queue(Of String) = New Queue(Of String)()
    Public obj2 As Queue(Of String) = New Queue(Of String)()
    Private ReadAGVSetting2 As ReadAGVSetting = New ReadAGVSetting("D:\\IprojectDB\Setting\AGV_Setting.json", True)

    'stamp time
    Dim totaltimelastedC1 As String = "2"
    Dim timenow, stamptimeC1 As Date
    Dim GetcomparetimeC1 As TimeSpan
    Dim getCycletimeC1 As String
    Dim ResultDelaytimeC1 As Integer
#Region "load and init form"
    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            '   main1()
            CheckProcess()
            ReadAGVSetting2.read()
            Me.Text &= String.Format(" Version {0}.{1:00}", My.Application.Info.Version.Major, My.Application.Info.Version.Minor)
            Update_ToolstripStaLabel("Receive Port: none", Me.status0, Color.Red, Color.White)
            Getcmbport()
            ' InputBox for start program''''''''''''''''''''
            Dim message, title, defautValue As String
            Dim myValue As Object
            message = "Enter a value cell No."
            title = "Set up cell use"
            defautValue = "D76-0"
            myValue = InputBox(message, title, defautValue, 500, 350)

            Comconfig.CellNo = myValue.ToString

            If myValue Is "" Then myValue = defautValue
            '*'''''''''''''''''''''''''''''''''''''''''''''
            Comconfig.ReadConfig(Comconfig.path & Comconfig.CellNo & ".conf")
            Update_ToolstripLabel(Comconfig.CardNo, TstrCard, Color.Thistle, Nothing)

            If _rs232.IsCheckConnect = False Then
                Me.comparams(RS232.cP.cPort) = Comconfig.cPortRcv
                Me.comparams(RS232.cP.cBaud) = Comconfig.cBaudRcv
                Me.comparams(RS232.cP.cData) = Comconfig.cDataRcv
                Me.comparams(RS232.cP.cParity) = Comconfig.cParityRcv
                Me.comparams(RS232.cP.cStop) = Comconfig.cStopRcv
                Me.comparams(RS232.cP.cDelay) = Comconfig.cDelayRcv
                Me.comparams(RS232.cP.cThreshold) = Comconfig.cThresholdRcv
                _rs232.connect(comparams)
            End If
            If _rs232Send.IsCheckConnect = False Then
                Me.comparamsSend(RS232.cP.cPort) = Comconfig.cPortSend
                Me.comparamsSend(RS232.cP.cBaud) = Comconfig.cBaudSend
                Me.comparamsSend(RS232.cP.cData) = Comconfig.cDataSend
                Me.comparamsSend(RS232.cP.cParity) = Comconfig.cParitySend
                Me.comparamsSend(RS232.cP.cStop) = Comconfig.cStopSend
                Me.comparamsSend(RS232.cP.cDelay) = Comconfig.cDelaySend
                Me.comparamsSend(RS232.cP.cThreshold) = Comconfig.cThresholdSend
                _rs232Send.connect(comparamsSend)
            End If

            If _rs232IO.IsCheckConnect = False Then
                Me.comparamsIO(RS232.cP.cPort) = Comconfig.cPortIO
                Me.comparamsIO(RS232.cP.cBaud) = Comconfig.cBaudIO
                Me.comparamsIO(RS232.cP.cData) = Comconfig.cDataIO
                Me.comparamsIO(RS232.cP.cParity) = Comconfig.cParityIO
                Me.comparamsIO(RS232.cP.cStop) = Comconfig.cStopIO
                Me.comparamsIO(RS232.cP.cDelay) = Comconfig.cDelayIO
                Me.comparamsIO(RS232.cP.cThreshold) = Comconfig.cThresholdIO
                _rs232IO.connect(comparamsIO)
            End If
            If BackgroundWorker5.IsBusy <> True Then
                BackgroundWorker5.RunWorkerAsync()
            End If
            colorlabel = DirectCast(New ColorConverter().ConvertFromString(Comconfig.colorLabel), Color)
            colorFrm = DirectCast(New ColorConverter().ConvertFromString(Comconfig.colorFrm), Color)
            Me.BackColor = colorFrm
            colorFore = DirectCast(New ColorConverter().ConvertFromString(Comconfig.ColorFront), Color)
            Emer = CInt(Comconfig.Emer)
            SWGreen = CInt(Comconfig.SWGreen)
            Sensor1 = CInt(Comconfig.Sensor1)
            Sensor2 = CInt(Comconfig.Sensor2)
            Update_label(myValue.ToString, TstrCell, Color.Black, colorFrm)
            InitialAGVStartControlThread()

        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
#End Region
    Dim P() As Process
#Region "check process AGV TCP CONTROL running"
    Private Sub CheckProcess()
        P = Process.GetProcessesByName("AGVControlServerConsole")
        If P.Count > 0 Then
            Exit Sub
        Else
            Process.Start("D:\IprojectDB\Setting\AGVControlServerConsole")
        End If
        'D:\IprojectDB\Setting\AGVControlServerConsole
    End Sub
#End Region
#Region "Tcp AGV control"
    Public Sub New()
        ' This call is required by the designer.
        InitializeComponent()
        ' Add any initialization after the InitializeComponent() call.
        'AddHandler BackgroundWorker1.DoWork, AddressOf BackgroundWorker1_DoWork
        'AddHanv  dler BackgroundWorker1.ProgressChanged, AddressOf BackgroundWorker1_ProgressChanged
        'AddHandler BackgroundWorker1.RunWorkerCompleted, AddressOf BackgroundWorker1_RunWorkerCompleted
        BackgroundWorker1.WorkerReportsProgress = True
        BackgroundWorker1.WorkerSupportsCancellation = True
        BackgroundWorker2.WorkerReportsProgress = True
        BackgroundWorker2.WorkerSupportsCancellation = True
        BackgroundWorker4.WorkerReportsProgress = True
        BackgroundWorker4.WorkerSupportsCancellation = False
        BackgroundWorker5.WorkerReportsProgress = True
        BackgroundWorker5.WorkerSupportsCancellation = False
    End Sub
    Public Sub InitialAGVStartControlThread()
        If Not socketAGVControl.isTryConnecting Then
            socketAGVControl.isTryConnecting = True
            If BackgroundWorker4.IsBusy <> True Then
                BackgroundWorker4.RunWorkerAsync()
            End If
        End If
    End Sub
    Dim log1 As LogFile = New LogFile("D:/IprojectDB/log_start_control", True)
    Private Sub TCPAVGAutoStartControl()
        Try
            Update_ToolstripStaLabel("[AGV auto start: Connecting to " & socketAGVControl.config.serverControlIP & ":" &
                          socketAGVControl.config.port2 & "...]", TstaTCPSignal, Color.LightCyan, Color.Black)
            If socketAGVControl.Connect() Then

                Update_ToolstripStaLabel("[AGV auto start: Connected to " &
                    socketAGVControl.config.serverControlIP & ":" & socketAGVControl.config.port2 & "]", TstaTCPSignal, Color.LightCyan, Color.Black)
                While True
                    Dim s As String = socketAGVControl.sr.ReadLine()
                    If s <> "200" Then
                        Try
                            Dim delimiter() As String = {"|"}
                            Dim resArray() As String = s.Split(delimiter, StringSplitOptions.None)
                            If resArray.Length = 3 Then
                                socketAGVControl.received = socketAGVControl.received + 1
                                AGVTcpControl.Master_cell = resArray(0)
                                AGVTcpControl.Master_process = resArray(1)
                                AGVTcpControl.Master_circleTime = resArray(2)
                                'test.Variable = AGVTcpControl.Master_cell
                                Update_ToolstripStaLabel(socketAGVControl.received & ": " & s, TstaTCPSignal, Color.LightCyan, Color.Black)
                                ' timesignal = Now
                                If flaglooptime = False Or CheckBox1.Checked = False Then
                                    check_XBADD_inBuffer()
                                End If
                            End If
                        Catch e As NullReferenceException
                            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 1111")
                            Me.Refresh()
                        End Try
                    End If
                End While
            End If
            socketAGVControl.isTryConnecting = False
        Catch e As InvalidOperationException
            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 2222")
            Me.Refresh()
        Catch e As IOException
            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 3333")
            Me.Refresh()
        End Try
    End Sub

    Public Sub TCPAutoStartControlTimer()
        While True
            Thread.Sleep(5000)
            If Not socketAGVControl.Ping() Then
                InitialAGVStartControlThread()
            End If
            If FlagTCP = 1 Then
                FlagTCP = 0
                socketAGVControl.isTryConnecting = False
            End If
        End While
    End Sub

    Public Sub TcpAGVAutoStartReceive()
        While True
            Try
                Dim s As String = socketAGVControl.sr.ReadLine()
                ' ToolStripStatusLabel1.Text = s
                Update_ToolstripStaLabel(s, TstaTCPSignal, Color.LightCyan, Color.Black)
            Catch e As InvalidOperationException
                log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " ERROR_ID: 9999")
            End Try


        End While
    End Sub
    Private Sub BackgroundWorker4_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker4.DoWork

        TCPAutoStartControlTimer()

    End Sub
    Private Sub BackgroundWorker5_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker5.DoWork
        TCPAVGAutoStartControl()
    End Sub

#End Region

#Region "form events Receive Port"

    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click

        Try

            If CType(sender, ToolStripButton).Text = "*connect*" Then

                Me.comparams(RS232.cP.cPort) = Comconfig.cPortRcv
                Me.comparams(RS232.cP.cBaud) = Comconfig.cBaudRcv
                Me.comparams(RS232.cP.cData) = Comconfig.cDataRcv
                Me.comparams(RS232.cP.cParity) = Comconfig.cParityRcv
                Me.comparams(RS232.cP.cStop) = Comconfig.cStopRcv
                Me.comparams(RS232.cP.cDelay) = Comconfig.cDelayRcv
                Me.comparams(RS232.cP.cThreshold) = Comconfig.cThresholdRcv
                _rs232.connect(comparams)
            Else
                _rs232.disconnect()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
    Private count As Integer

    ''' <summary>
    ''' build hex string in textbox
    ''' </summary>
    Private Sub cboEnterMessage_TextUpdate(ByVal sender As System.Object,
                                           ByVal e As System.EventArgs)
        ''  If Not Me.chkTxEnterHex.Checked Then Exit Sub
        'Dim cb As ToolStripComboBox = CType(sender, ToolStripComboBox)
        'Dim s As String = cb.Text
        'count += 1
        'If count = 2 Then
        '    cb.Text &= " "
        '    count = 0
        'End If
        'cb.SelectionStart = cb.Text.Length
    End Sub

    Private Sub sendToCom() 'Handles cbxsendToCom.KeyDown

        Dim data() As Byte = Nothing

        'With Me.cboEnterMessage
        '    If .Text.Length > 0 Then

        '        If Not Me.chkTxEnterHex.Checked Then
        '            If Me.chkAddCR.Checked Then .Text &= ControlChars.Cr
        '            If Me.chkAddLF.Checked Then .Text &= ControlChars.Lf
        '   data = Encoding.ASCII.GetBytes(.Text)
        'Else
        '     data = reconvert(.Text)
        'End If

        'send data:
        _rs232.SendData(data)

        'tx counter:
        Me.TXcount += data.Length
        '   Me.lblTxCnt.Text = String.Format("{0:D6}", TXcount)
        Update_ToolstripLabel(String.Format("{0:D6}", TXcount), lblTxCnt, Nothing, Nothing)
        'Me.statusTX.Image = My.Resources.ledGray
        '   .Text = String.Empty

        'End If
        '   End With

    End Sub
    ''' <summary>
    ''' view hex in rx box
    ''' </summary>
    Private Sub RxShowHex_CheckedChanged(ByVal sender As System.Object,
                                         ByVal e As System.EventArgs)
        '   Me.charsInline = setRuler(Me.rtbRX, Me.chkRxShowHex.Checked)
    End Sub
    ''' <summary>
    ''' view hex in tx box
    ''' </summary>
    Private Sub chkTxShowHex_CheckedChanged(ByVal sender As System.Object,
                                         ByVal e As System.EventArgs)
        '    Me.charsInline = setRuler(Me.rtbTX, Me.chkTxShowHex.Checked)
    End Sub
    ''' <summary>
    ''' save rx box to file
    ''' </summary>
    Private Sub btnSaveFileFromRxBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        SaveFileDialog1.DefaultExt = "*.TXT"
        SaveFileDialog1.Filter = "txt Files | *.TXT"
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then

            Dim fullpath As String = SaveFileDialog1.FileName()
            '  Me.rtbRX.SaveFile(fullpath, RichTextBoxStreamType.PlainText)
            MessageBox.Show(IO.Path.GetFileName(fullpath) & " written")
        Else
            MessageBox.Show("no data choosen")
        End If
    End Sub

    ''' <summary>
    ''' load file into tx box
    ''' </summary>
    Private Sub TxbtnFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        OpenFileDialog1.DefaultExt = "*.TXT"
        OpenFileDialog1.Filter = "txt Files | *.TXT"
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then

            Dim fullpath As String = OpenFileDialog1.FileName()
            '  Me.rtbTX.Clear()
            '  Me.rtbTX.LoadFile(fullpath, RichTextBoxStreamType.PlainText)
        Else
            MessageBox.Show("no data choosen")
        End If
    End Sub

    ''' <summary>
    ''' load config
    ''' </summary>
    Private Sub LoadC(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadConfig.Click
        Dim fname As String = "D:\IprojectDB\Setting\comterm.ini"
        Try
            Dim sr As New StreamReader(fname)
            Me.cboComPort.Text = sr.ReadLine()
            Me.cboBaudrate.Text = sr.ReadLine()
            Me.cboDataBits.Text = sr.ReadLine()
            Me.cboParity.Text = sr.ReadLine()
            Me.cboStopbits.Text = sr.ReadLine()
            Me.cboThreshold.Text = sr.ReadLine
            Me.cboDelay.Text = sr.ReadLine
            sr.Close()
            If sender IsNot Nothing Then MessageBox.Show(fname & " read")
        Catch ex As IOException
            MessageBox.Show(fname & " error: " & ex.Message)
        End Try

    End Sub

    ''' <summary>
    ''' save comparms
    ''' </summary>
    Private Sub SaveConfig_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveConfig.Click

    End Sub
    ''' <summary>
    '''  exit
    ''' </summary>
    Private Sub ExitTool_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitTool.Click
        Me.Close()
    End Sub

    ''' <summary>
    '''  form resize
    ''' </summary>
    Private Sub frmMain_ResizeEnd(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.ResizeEnd
        'Me.charsInline = setRuler(rtbRX, chkRxShowHex.Checked)
        'Me.charsInline = setRuler(rtbTX, chkTxShowHex.Checked)
    End Sub
#End Region
#Region "Com Port class events Receive Port"
    ''' <summary>
    '''  update boxes
    ''' </summary>
    ''' <param name="buffer">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdate(ByVal buffer() As Byte) Handles _rs232.Datareceived

        Me.RXcount += buffer.Length
        ' Me.lblRxCnt.Text = String.Format("count: {0:D3}", RXcount)
        Update_ToolstripLabel(String.Format("count: {0:D3}", RXcount), lblRxCnt, Nothing, Nothing)
        Dim s As String = Encoding.ASCII.GetString(buffer, 0, buffer.Length)
        ' Me.rtbRX.ScrollToCaret()
        'TODO
        '  Me.rtbRX.AppendText(s) ' & vbCr)
        appendBytes(buffer, Me.charsInline, False)
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendata(ByVal sendStatus As Boolean) Handles _rs232.sendOK
        If sendStatus Then
            '  Me.statusTX.Image = My.Resources.ledGreen
            '  Update_bitmap(statusTX, My.Resources.ledGreen)
        Else
            '   Me.statusTX.Image = My.Resources.ledRed
            '   Update_bitmap(statusTX, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    ''' receive successfull
    ''' </summary>
    Private Sub rdata(ByVal receiveStatus As Boolean) Handles _rs232.recOK
        If receiveStatus Then
            ' Me.statusRX.Image = My.Resources.ledGreen
            '  Update_bitmap(statusRX, My.Resources.ledGreen)
        Else
            ' Me.statusRX.Image = My.Resources.ledRed
            ' Update_bitmap(statusRX, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connection(ByVal status As Boolean) Handles _rs232.connection
        If status Then
            Me.cboParity.Enabled = False
            Me.cboStopbits.Enabled = False
            Me.cboComPort.Enabled = False
            Me.cboBaudrate.Enabled = False
            Me.cboDataBits.Enabled = False
            Me.cboDelay.Enabled = False
            Me.cboThreshold.Enabled = False
            Update_Toolstripbutton("disconnect", btnConnect, Color.Transparent, Color.Black)
            Update_ToolstripLabel("Connect:" & vbCr & "OK", TstrRCV, Color.Green, Color.White)
            Me.sLabel(comparams)
            Me.isConnected = True

        Else
            Me.cboParity.Enabled = True
            Me.cboStopbits.Enabled = True
            Me.cboComPort.Enabled = True
            Me.cboBaudrate.Enabled = True
            Me.cboDataBits.Enabled = True
            Me.cboDelay.Enabled = True
            Me.cboThreshold.Enabled = True
            Update_Toolstripbutton("*connect*", btnConnect, Color.Transparent, Color.Black)
            Update_ToolstripLabel("Connect:" & vbCr & "NG", TstrRCV, Color.Red, Color.White)
            Update_ToolstripStaLabel(" Terminal connect: none", status0, Color.Red, Color.White)
            Me.isConnected = False

        End If
    End Sub

    ''' <summary>
    ''' exception message
    ''' </summary>
    Private Sub getmessage(ByVal msg As String) Handles _rs232.errormsg
        'Me.status0.Text = msg
        MsgBox(msg)
    End Sub

#End Region
#Region "utilities  Receive Port"
    ''' <param name="data">data frame</param>
    ''' <param name="currentLenght">possible chars in box</param>
    ''' <param name="showHexAndAscii">determines whether also displaying Hex True</param>
    ''' <remarks></remarks>
    Private Sub appendBytes(ByRef data() As Byte, ByRef currentLenght As Integer, ByVal showHexAndAscii As Boolean)
        Dim HexString As String = strtemp & StringUltilities.ByteArrayToHexString(data)
        Dim CharString As String = String.Empty
        Dim s() As String = HexString.Split(New String() {" 7E"}, StringSplitOptions.RemoveEmptyEntries)
        ' Static A As Integer
        Dim objmember As Object() = Nothing
        For i = 0 To s.Length - 1
            Update_ToolstripStaLabel(s(i).ToString, lblReceive, Color.MistyRose, Color.Black)
            Dim data_S() As Byte
            Dim ADD() As Byte
            Dim Respond As Byte
            Dim card() As Byte
            Dim strb As String = Nothing
            Dim strb2 As String = Nothing
            Dim line As String
            Dim name As String
            Dim index As String
            data_S = Reconvert.convert(s(i), " ")
            If data_S.Length = 20 Then
                strtemp = ""
                ADD = {data_S(7), data_S(8), data_S(9), data_S(10)}
                strb = Hex(data_S(7)).PadLeft(2, "0"c) & " " & Hex(data_S(8)).PadLeft(2, "0"c) & " " & Hex(data_S(9)).PadLeft(2, "0"c) & " " & Hex(data_S(10)).PadLeft(2, "0"c)
                strb2 = Hex(data_S(7)).PadLeft(2, "0"c) & Hex(data_S(8)).PadLeft(2, "0"c) & Hex(data_S(9)).PadLeft(2, "0"c) & Hex(data_S(10)).PadLeft(2, "0"c)
                show_ADD = strb2
                Respond = data_S(16)
                card = {data_S(18), data_S(17), &H0, &H0}
                Dim result As Long = BitConverter.ToUInt32(card, 0)
                show_result = result.ToString

                receiveadd = strb
                If ReadAGVSetting2.dicLine.ContainsKey(strb2) Then
                    line = ReadAGVSetting2.dicLine.Item(strb2)
                End If
                If ReadAGVSetting2.dicname.ContainsKey(strb2) Then
                    name = ReadAGVSetting2.dicname.Item(strb2)
                End If
                If ReadAGVSetting2.dicindex.ContainsKey(strb2) Then
                    index = ReadAGVSetting2.dicindex.Item(strb2)
                End If
                Select Case result
                    Case CInt(Comconfig.CardNo) 'cell 3-3 
                        If strb <> straddcheck Then
                            straddcheck = strb
                            If obj.Count < 2 Then 'check add in queue >=2
                                QueueManage.Enqueue_AGV(obj, ListInQueue1, strb)
                                updateAGVQ(obj, ListInQueue1)
                                Send_Packet_to_AGV(_rs232Send, ADD, &H4F, &H4B)
                            ElseIf obj.Count >= 2 Then
                                obj.Clear()
                                QueueManage.Enqueue_AGV(obj, ListInQueue1, strb)
                                updateAGVQ(obj, ListInQueue1)
                            End If
                            show_detailAGV()
                        ElseIf strb = straddcheck And Comconfig.Concept = "Onepiece" Then
                            Send_Packet_to_AGV(_rs232Send, ADD, &H4F, &H4B)
                        ElseIf strb = straddcheck And Comconfig.Concept = "Heajunka" Then
                            'If obj.Count < 2 Then 'check add in queue >=2
                            '    QueueManage.Enqueue_AGV(obj, ListInQueue1, strb)
                            '    updateAGVQ(obj, ListInQueue1)
                            '    Send_Packet_to_AGV(_rs232Send, ADD, &H4F, &H4B)
                            'ElseIf obj.Count >= 2 Then
                            obj.Clear()
                            QueueManage.Enqueue_AGV(obj, ListInQueue1, strb)
                            updateAGVQ(obj, ListInQueue1)
                            '  End If
                            show_detailAGV()
                        End If
                    Case 19279
                        If BackgroundWorker1.IsBusy = True Or BackgroundWorker2.IsBusy = True Then
                            If flagNowStart = True Then
                                responsefromAGV = "OK" '"KO"=19279
                            End If
                        End If
                    Case 20299
                        If BackgroundWorker1.IsBusy = True Or BackgroundWorker2.IsBusy = True Then
                            If flagNowStart = True Then
                                responsefromAGV = "OK"
                            End If
                        End If
                    Case CInt(Comconfig.CardNoCancel) 'card 217
                        '  straddcheck_217 = strb
                        Dim Pac(20) As Byte
                        Dim addT(7) As Byte
                        Dim Card2(3) As Byte
                        Dim res As Byte
                        Dim strdata2 As String = Nothing

                        If flagNowStart = True Then
                            If BackgroundWorker1.IsBusy = True Then
                                status217 = True
                                'flagcancel = True
                                '* flagNowStart = CBool(0)
                            End If
                        End If

                        If obj.Count <> 0 Then
                            QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
                            If strdata2 = receiveadd Then
                                If Temp_217 <> receiveadd Then
                                    Temp_217 = receiveadd
                                    Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                                    QueueManage.deDequeue_AGV(obj, ListInQueue1)
                                    updateAGVQ(obj, ListInQueue1)
                                    show_detailAGV()
                                    SSS = 0
                                    '  strdata2 = ""
                                ElseIf Temp_217 = receiveadd And Comconfig.Concept = "Heajunka" Then
                                    Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                                    QueueManage.deDequeue_AGV(obj, ListInQueue1)
                                    updateAGVQ(obj, ListInQueue1)
                                    show_detailAGV()
                                    SSS = 0
                                End If

                            End If
                        End If
                        If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                            SSS = 0
                            BackgroundWorker2.RunWorkerAsync()
                        End If
                    Case CInt(Comconfig.CardNoCancelSignal) 'card 224
                        If AGVTcpControl.Master_cell <> "" And Temp_224 <> receiveadd Then
                            Temp_224 = receiveadd
                            ' cell = ""
                            ' Update_label(AGVTcpControl.Master_cell, lblsignal2, Color.Gray)
                            Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                            If BackgroundWorker1.IsBusy = True Then
                                '  BackgroundWorker1.CancelAsync()   
                                SSS = 0
                                flagcancel = True
                                ' flagNowStart = CBool(0)
                            End If
                            Send_Packet_to_AGV(_rs232Send, ADD, &H4F, &H4B)
                        ElseIf Temp_224 = receiveadd Then
                            Send_Packet_to_AGV(_rs232Send, ADD, &H4F, &H4B)
                        End If
                End Select
                result = 0
                card = {&H0, &H0, &H0, &H0}

            Else
                strtemp = s(s.Length - 1)
            End If
        Next
        HexString = String.Empty
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs)
        If btnConnect.Text = "disconnect" Then
            If _rs232.IsCheckConnect = False Then
                ' MessageBox.Show("please re-connect")
                Update_Toolstripbutton("*connect*", btnConnect, Color.Transparent, Color.Black)
                Update_ToolstripStaLabel("Re-connect Receive Port: ", status0, Color.Red, Color.White)
                Update_ToolstripLabel("Connect:" & vbCr & "NG", TstrRCV, Color.Red, Color.White)

            End If
        End If
        If btnConnectSend.Text = "disconnect" Then
            If _rs232Send.IsCheckConnect = False Then
                ' MessageBox.Show("please re-connect")
                btnConnectSend.Text = "*connect*"
                Update_Toolstripbutton("*connect*", btnConnectSend, Color.Transparent, Color.Black)
                Update_ToolstripStaLabel("Re-connect Send Port: ", txtstatus1, Color.Red, Color.White)
                Update_ToolstripLabel("Connect:" & vbCr & "NG", TstrSend, Color.Red, Color.White)
            End If
        End If
        If btnConnectIO.Text = "disconnect" Then
            If _rs232IO.IsCheckConnect = False Then
                ' MessageBox.Show("please re-connect")
                Update_Toolstripbutton("*connect*", btnConnectIO, Color.Transparent, Color.Black)
                Update_ToolstripStaLabel("Re-connect IO Port: ", txtstatus2, Color.Red, Color.White)
                Update_ToolstripLabel("Connect:" & vbCr & "NG", TstrIO, Color.Red, Color.White)
            End If
        End If

    End Sub

    ''' <summary>
    ''' show status of connection
    ''' </summary>
    Private Sub sLabel(ByVal comparams() As String)
        Try
            Dim Sta0 As String = ""
            For Each s As String In comparams
                Sta0 &= "-" & s
            Next
            Update_ToolstripLabel("RCV:" & Sta0, status0, Color.Green, Color.White)
        Catch ex As Exception

        End Try
    End Sub

#End Region
    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        'Dim fname As String = "D:\IprojectDB\Setting\comterm.ini"
        'If Tcboselect.Text = "Receive Comport" Then
        '    fname = "D:\IprojectDB\Setting\comtermPortReceive.ini"
        'ElseIf Tcboselect.Text = "Send Comport" Then
        '    fname = "D:\IprojectDB\Setting\comtermPortSend.ini"
        'End If
        'Dim sw As New StreamWriter(fname)
        'sw.WriteLine(Me.cboComPort.Text)
        'sw.WriteLine(Me.cboBaudrate.Text)
        'sw.WriteLine(Me.cboDataBits.Text)
        'sw.WriteLine(Me.cboParity.Text)
        'sw.WriteLine(Me.cboStopbits.Text)
        'sw.WriteLine(Me.cboThreshold.Text)
        'sw.WriteLine(Me.cboDelay.Text)
        'sw.Close()
        'MessageBox.Show(fname & " written")
    End Sub
    'End Serialport receive code
#Region "form events Send Port"

    'Private Sub btnClearReceiveBoxr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    Me.RXcountSend = 0
    '    Me.lblRxCntSend.Text = String.Format("count: {0:D6}", Me.RXcountSend)
    '    'Me.statusRXSend.Image = If(Me.isConnectedSend, My.Resources.ledOrange, My.Resources.ledGray)
    'End Sub


    'Private Sub btnClearTxBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    'Me.rtbTX.Clear()
    '    'Me.rtbTX.Text = "1"
    '    'Me.charsInline = setRuler(rtbTX, chkTxShowHex.Checked)
    '    Me.TXcountSend = 0
    '    Me.lblTxCntsend.Text = String.Format("count: {0:D3}", Me.TXcountSend)
    '    '  Me.statusTXsend.Image = If(Me.isConnectedSend, My.Resources.ledOrange, My.Resources.ledGray)
    'End Sub

    Private countsend As Integer

    'Private Sub cboEnterMessage_TextUpdate(ByVal sender As System.Object,
    '                                       ByVal e As System.EventArgs)


    '    '  If Not Me.chkTxEnterHex.Checked Then Exit Sub
    '    Dim cb As ToolStripComboBox = CType(sender, ToolStripComboBox)
    '    Dim s As String = cb.Text
    '    countsend += 1
    '    If countsend = 2 Then
    '        cb.Text &= " "
    '        countsend = 0
    '    End If
    '    cb.SelectionStart = cb.Text.Length

    'End Sub

    Private Sub sendToComSend() 'Handles cbxsendToCom.KeyDown

        Dim dataSend() As Byte = Nothing

        'With Me.cboEnterMessage
        '    If .Text.Length > 0 Then

        '        If Not Me.chkTxEnterHex.Checked Then
        '            If Me.chkAddCR.Checked Then .Text &= ControlChars.Cr
        '            If Me.chkAddLF.Checked Then .Text &= ControlChars.Lf
        '   data = Encoding.ASCII.GetBytes(.Text)
        'Else
        '     data = reconvert(.Text)
        'End If

        'send data:
        '  _rs232Send.SendData(dataSend)
        ' Send_Packet_to_AGV(_rs232Send, addT, &H1, &H0)
        'tx counter:
        Me.TXcountSend += dataSend.Length
        '   Me.lblTxCntsend.Text = String.Format("{0:D6}", TXcountSend)
        Update_ToolstripLabel(String.Format("{0:D6}", TXcountSend), lblTxCntsend, Nothing, Nothing)
        'Me.statusTXsend.Image = My.Resources.ledGray
        '   .Text = String.Empty

        'End If
        '   End With

    End Sub

    '''' <summary>
    '''' save rx box to file
    '''' </summary>
    'Private Sub btnSaveFileFromRxBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    SaveFileDialog1.DefaultExt = "*.TXT"
    '    SaveFileDialog1.Filter = "txt Files | *.TXT"
    '    If SaveFileDialog1.ShowDialog() = DialogResult.OK Then

    '        Dim fullpath As String = SaveFileDialog1.FileName()
    '        '  Me.rtbRX.SaveFile(fullpath, RichTextBoxStreamType.PlainText)
    '        MessageBox.Show(IO.Path.GetFileName(fullpath) & " written")
    '    Else
    '        MessageBox.Show("no data choosen")
    '    End If
    'End Sub

    '''' <summary>
    '''' load file into tx box
    '''' </summary>
    'Private Sub TxbtnFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    OpenFileDialog1.DefaultExt = "*.TXT"
    '    OpenFileDialog1.Filter = "txt Files | *.TXT"
    '    If OpenFileDialog1.ShowDialog() = DialogResult.OK Then

    '        Dim fullpath As String = OpenFileDialog1.FileName()
    '        '  Me.rtbTX.Clear()
    '        '  Me.rtbTX.LoadFile(fullpath, RichTextBoxStreamType.PlainText)
    '    Else
    '        MessageBox.Show("no data choosen")
    '    End If
    'End Sub

    '''' <summary>
    '''' load config
    '''' </summary>
    'Private Sub LoadC(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadConfig.Click
    '    Dim fname As String = "D:\IprojectDB\Setting\comterm.ini"
    '    Try
    '        Dim sr As New StreamReader(fname)
    '        Me.cboComPort.Text = sr.ReadLine()
    '        Me.cboBaudrate.Text = sr.ReadLine()
    '        Me.cboDataBits.Text = sr.ReadLine()
    '        Me.cboParity.Text = sr.ReadLine()
    '        Me.cboStopbits.Text = sr.ReadLine()
    '        Me.cboThreshold.Text = sr.ReadLine
    '        Me.cboDelay.Text = sr.ReadLine
    '        sr.Close()
    '        If sender IsNot Nothing Then MessageBox.Show(fname & " read")
    '    Catch ex As IOException
    '        MessageBox.Show(fname & " error: " & ex.Message)
    '    End Try

    'End Sub


#End Region
#Region "Com Port class events send Port"
    ''' <summary>
    '''  update boxes
    ''' </summary>
    ''' <param name="bufferSend">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdateSend(ByVal bufferSend() As Byte) Handles _rs232Send.Datareceived

        Me.RXcountSend += bufferSend.Length
        '  Me.lblRxCntSend.Text = String.Format("count: {0:D3}", RXcountSend)
        Update_ToolstripLabel(String.Format("count: {0:D3}", RXcountSend), lblRxCntSend, Nothing, Nothing)
        Dim sSend As String = Encoding.ASCII.GetString(bufferSend, 0, bufferSend.Length)
        ' Me.rtbRX.ScrollToCaret()
        'TODO
        '  Me.rtbRX.AppendText(s) ' & vbCr)
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendataSend(ByVal sendStatusSend As Boolean) Handles _rs232Send.sendOK
        If sendStatusSend Then
            ' Me.statusTXsend.Image = My.Resources.ledGreen
            '  Update_bitmap(statusTXsend, My.Resources.ledGreen)
        Else
            ' Me.statusTXsend.Image = My.Resources.ledRed
            '  Update_bitmap(statusTXsend, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    ''' receive successfull
    ''' </summary>
    Private Sub rdataSend(ByVal receiveStatusSend As Boolean) Handles _rs232Send.recOK
        If receiveStatusSend Then
            '  Update_bitmap(statusRXSend, My.Resources.ledGreen)
            ' Me.statusRXSend.Image = My.Resources.ledGreen
        Else
            '   Me.statusRXSend.Image = My.Resources.ledRed
            '  Update_bitmap(statusRXSend, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connectionSend(ByVal statusSend As Boolean) Handles _rs232Send.connection
        If statusSend Then
            Me.cboParity.Enabled = False
            Me.cboStopbits.Enabled = False
            Me.cboComPort.Enabled = False
            Me.cboBaudrate.Enabled = False
            Me.cboDataBits.Enabled = False
            Me.cboDelay.Enabled = False
            Me.cboThreshold.Enabled = False
            Update_Toolstripbutton("disconnect", btnConnectSend, Color.Transparent, Color.Black)
            Update_ToolstripLabel("Connect:" & vbCr & "OK", TstrSend, Color.ForestGreen, Color.White)
            Me.sLabelSend(comparamsSend)
            Me.isConnectedSend = True
        Else
            Me.cboParity.Enabled = True
            Me.cboStopbits.Enabled = True
            Me.cboComPort.Enabled = True
            Me.cboBaudrate.Enabled = True
            Me.cboDataBits.Enabled = True
            Me.cboDelay.Enabled = True
            Me.cboThreshold.Enabled = True
            Update_Toolstripbutton("*connect*", btnConnectSend, Color.Transparent, Color.Black)
            Update_ToolstripLabel("Connect:" & vbCr & "NG", TstrSend, Color.Red, Color.White)
            Update_ToolstripStaLabel(" Terminal connect: none", txtstatus1, Color.Red, Color.White)
            Me.isConnectedSend = False

        End If

    End Sub

    ''' <summary>
    ''' exception message
    ''' </summary>
    Private Sub getmessageSend(ByVal msgSend As String) Handles _rs232Send.errormsg
        'Me.status0.Text = msg
        MsgBox(msgSend)
    End Sub

#End Region
#Region "utilities  Send Port"

    Private Sub appendBytesSend(ByVal rb As RichTextBox, ByRef dataSend() As Byte, ByRef currentLenghtSend As Integer, ByVal showHexAndAsciiSend As Boolean)
        Dim HexStringSend As String = String.Empty
        Dim CharStringSend As String = String.Empty
        Dim count As Integer = 0

        For i As Integer = 0 To dataSend.Length - 1
            HexStringSend &= String.Format(" {0:X2}", dataSend(i))
            If dataSend(i) > 31 Then
                CharStringSend &= String.Format("  {0}", Chr(dataSend(i)))
            Else
                CharStringSend &= "  ."
            End If
            count += 3

            'start a new line
            'If count >= currentLenghtSend Then
            '    rbSend.ScrollToCaret()
            '    rbSend.AppendText(HexStringSend & vbCr)
            '    If showHexAndAsciiSend Then
            '        rb.ScrollToCaret()
            '        rb.AppendText(CharStringSend & vbCr)
            '    End If
            '    HexString = String.Empty
            '    CharString = String.Empty
            '    count = 0
            'End If

        Next

        'rb.ScrollToCaret()
        'rb.AppendText(HexString & vbCr)
        'If showHexAndAscii Then
        '    rb.ScrollToCaret()
        '    rb.AppendText(CharString & vbCr)
        'End If
    End Sub


    ''' <summary>
    ''' show status of connection
    ''' </summary>
    Private Sub sLabelSend(ByVal comparamsSend() As String)
        Dim sta1 As String = ""
        For Each s As String In comparamsSend
            sta1 &= "-" & s
        Next
        Update_ToolstripLabel("SND:" & sta1, txtstatus1, Color.Green, Color.White)
    End Sub

    Private Sub SplitContainer1_Panel1_Paint(sender As Object, e As PaintEventArgs) Handles SplitContainer1.Panel1.Paint
    End Sub

#End Region
    Private Sub btnConnectSend_Click(sender As Object, e As EventArgs) Handles btnConnectSend.Click
        Try

            If CType(sender, ToolStripButton).Text = "*connect*" Then
                Me.comparams(RS232.cP.cPort) = Comconfig.cPortSend
                Me.comparams(RS232.cP.cBaud) = Comconfig.cBaudSend
                Me.comparams(RS232.cP.cData) = Comconfig.cDataSend
                Me.comparams(RS232.cP.cParity) = Comconfig.cParitySend
                Me.comparams(RS232.cP.cStop) = Comconfig.cStopSend
                Me.comparams(RS232.cP.cDelay) = Comconfig.cDelaySend
                Me.comparams(RS232.cP.cThreshold) = Comconfig.cThresholdSend
                _rs232Send.connect(comparamsSend)
            Else
                _rs232Send.disconnect()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
    'End Serialport send code
#Region "form events IO Port"
    ''' <summary>
    ''' clear rx box
    ''' </summary>
    Private Sub btnClearReceiveBoxr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.RXcountIO = 0
        Update_ToolstripLabel(String.Format("count: {0:D6}", RXcountSend), lblRxCntIO, Nothing, Nothing)
    End Sub

    ''' <summary>
    ''' clear tx box
    ''' </summary>
    Private Sub btnClearTxBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Me.rtbTX.Clear()
        'Me.rtbTX.Text = "1"
        'Me.charsInline = setRuler(rtbTX, chkTxShowHex.Checked)
        Me.TXcountIO = 0
        '  Me.lblTxCntIO.Text = String.Format("count: {0:D3}", Me.TXcountIO)
        Update_ToolstripLabel(String.Format("count: {0:D3}", Me.TXcountIO), lblTxCntIO, Nothing, Nothing)
        '  Me.statusTXsend.Image = If(Me.isConnectedSend, My.Resources.ledOrange, My.Resources.ledGray)
    End Sub

    Private countIO As Integer

    'Private Sub cboEnterMessage_TextUpdate(ByVal sender As System.Object,
    '                                       ByVal e As System.EventArgs)


    '    '  If Not Me.chkTxEnterHex.Checked Then Exit Sub
    '    Dim cb As ToolStripComboBox = CType(sender, ToolStripComboBox)
    '    Dim s As String = cb.Text
    '    countsend += 1
    '    If countsend = 2 Then
    '        cb.Text &= " "
    '        countsend = 0
    '    End If
    '    cb.SelectionStart = cb.Text.Length

    'End Sub

    Private Sub sendToComIO() 'Handles cbxsendToCom.KeyDown

        Dim dataIO() As Byte = Nothing

        'With Me.cboEnterMessage
        '    If .Text.Length > 0 Then

        '        If Not Me.chkTxEnterHex.Checked Then
        '            If Me.chkAddCR.Checked Then .Text &= ControlChars.Cr
        '            If Me.chkAddLF.Checked Then .Text &= ControlChars.Lf
        '   data = Encoding.ASCII.GetBytes(.Text)
        'Else
        '     data = reconvert(.Text)
        'End If

        'send data:
        _rs232IO.SendData(dataIO)

        'tx counter:
        Me.TXcountIO += dataIO.Length
        '   Me.lblTxCntIO.Text = String.Format("{0:D6}", TXcountIO)
        Update_ToolstripLabel(String.Format("{0:D6}", TXcountIO), lblTxCntIO, Nothing, Nothing)
        'Me.statusTXsend.Image = My.Resources.ledGray
        '   .Text = String.Empty

        'End If
        '   End With

    End Sub

    '''' <summary>
    '''' save rx box to file
    '''' </summary>
    'Private Sub btnSaveFileFromRxBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    SaveFileDialog1.DefaultExt = "*.TXT"
    '    SaveFileDialog1.Filter = "txt Files | *.TXT"
    '    If SaveFileDialog1.ShowDialog() = DialogResult.OK Then

    '        Dim fullpath As String = SaveFileDialog1.FileName()
    '        '  Me.rtbRX.SaveFile(fullpath, RichTextBoxStreamType.PlainText)
    '        MessageBox.Show(IO.Path.GetFileName(fullpath) & " written")
    '    Else
    '        MessageBox.Show("no data choosen")
    '    End If
    'End Sub

    '''' <summary>
    '''' load file into tx box
    '''' </summary>
    'Private Sub TxbtnFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    OpenFileDialog1.DefaultExt = "*.TXT"
    '    OpenFileDialog1.Filter = "txt Files | *.TXT"
    '    If OpenFileDialog1.ShowDialog() = DialogResult.OK Then

    '        Dim fullpath As String = OpenFileDialog1.FileName()
    '        '  Me.rtbTX.Clear()
    '        '  Me.rtbTX.LoadFile(fullpath, RichTextBoxStreamType.PlainText)
    '    Else
    '        MessageBox.Show("no data choosen")
    '    End If
    'End Sub

    '''' <summary>
    '''' load config
    '''' </summary>
    'Private Sub LoadC(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadConfig.Click
    '    Dim fname As String = "D:\IprojectDB\Setting\comterm.ini"
    '    Try
    '        Dim sr As New StreamReader(fname)
    '        Me.cboComPort.Text = sr.ReadLine()
    '        Me.cboBaudrate.Text = sr.ReadLine()
    '        Me.cboDataBits.Text = sr.ReadLine()
    '        Me.cboParity.Text = sr.ReadLine()
    '        Me.cboStopbits.Text = sr.ReadLine()
    '        Me.cboThreshold.Text = sr.ReadLine
    '        Me.cboDelay.Text = sr.ReadLine
    '        sr.Close()
    '        If sender IsNot Nothing Then MessageBox.Show(fname & " read")
    '    Catch ex As IOException
    '        MessageBox.Show(fname & " error: " & ex.Message)
    '    End Try

    'End Sub


#End Region
#Region "Com Port class events IO Port"
    ''' <summary>
    '''  update boxes
    ''' </summary>
    ''' <param name="bufferIO">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdateIO(ByVal bufferIO() As Byte) Handles _rs232IO.Datareceived

        Me.RXcountIO += bufferIO.Length
        '   Me.lblRxCntIO.Text = String.Format("count: {0:D3}", RXcountIO)
        Update_ToolstripLabel(String.Format("count: {0:D3}", RXcountIO), lblRxCntIO, Nothing, Nothing)
        Dim sIO As String = Encoding.ASCII.GetString(bufferIO, 0, bufferIO.Length)
        ' Me.rtbRX.ScrollToCaret()
        'TODO
        '  Me.rtbRX.AppendText(s) ' & vbCr)
        appendBytesIO(bufferIO, Me.charsInlineIO, False)
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendataIO(ByVal sendStatusIO As Boolean) Handles _rs232IO.sendOK
        If sendStatusIO Then
            ' Me.statusTXsend.Image = My.Resources.ledGreen
            '  Update_bitmap(statusTXsend, My.Resources.ledGreen)
        Else
            ' Me.statusTXsend.Image = My.Resources.ledRed
            '  Update_bitmap(statusTXsend, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    ''' receive successfull
    ''' </summary>
    Private Sub rdataIO(ByVal receiveStatusIO As Boolean) Handles _rs232IO.recOK
        If receiveStatusIO Then
            '  Update_bitmap(statusRXSend, My.Resources.ledGreen)
            ' Me.statusRXSend.Image = My.Resources.ledGreen
        Else
            '   Me.statusRXSend.Image = My.Resources.ledRed
            '  Update_bitmap(statusRXSend, My.Resources.ledRed)
        End If
    End Sub
    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connectionIO(ByVal statusIO As Boolean) Handles _rs232IO.connection
        If statusIO Then
            Me.cboParity.Enabled = False
            Me.cboStopbits.Enabled = False
            Me.cboComPort.Enabled = False
            Me.cboBaudrate.Enabled = False
            Me.cboDataBits.Enabled = False
            Me.cboDelay.Enabled = False
            Me.cboThreshold.Enabled = False
            Update_Toolstripbutton("disconnect", btnConnectIO, Color.Transparent, Color.Black)
            Update_ToolstripLabel("Connect:" & vbCr & "OK", TstrIO, Color.Green, Color.White)
            Me.sLabelIO(comparamsIO)
            Me.isConnectedIO = True
        Else
            Me.cboParity.Enabled = True
            Me.cboStopbits.Enabled = True
            Me.cboComPort.Enabled = True
            Me.cboBaudrate.Enabled = True
            Me.cboDataBits.Enabled = True
            Me.cboDelay.Enabled = True
            Me.cboThreshold.Enabled = True
            Update_Toolstripbutton("*connect*", btnConnectIO, Color.Transparent, Color.Black)
            Update_ToolstripLabel("Connect:" & vbCr & "NG", TstrIO, Color.Red, Color.White)
            Update_ToolstripStaLabel(" Terminal connect: none", txtstatus2, Color.Red, Color.White)
            Me.isConnectedIO = False
        End If

    End Sub

    ''' <summary>
    ''' exception message
    ''' </summary>
    Private Sub getmessageIO(ByVal msgIO As String) Handles _rs232IO.errormsg
        'Me.status0.Text = msg
        MsgBox(msgIO)
    End Sub

#End Region

#Region "utilities IO Port"
    Dim strtempIO As String = ""
    Private Sub appendBytesIO(ByRef dataIO() As Byte, ByRef currentLenghtIO As Integer, ByVal showHexAndAsciiIO As Boolean)
        Dim HexStringIO As String = String.Empty
        Dim CharStringIO As String = String.Empty
        Dim countIO As Integer = 0
        Try
            Dim HexString As String = strtempIO & StringUltilities.ByteArrayToHexString(dataIO)
            Dim CharString As String = String.Empty
            Dim s() As String = HexString.Split(New String() {" 7E"}, StringSplitOptions.RemoveEmptyEntries)
            For i = 0 To s.Length - 1
                Dim data_S2() As Byte
                Dim ADD() As Byte
                Dim strb As String = Nothing
                Dim tempalldata As String = ""
                If s(i).Length = 63 Then
                    data_S2 = Reconvert.convert(s(i), " ")
                    strtempIO = ""
                    If tempalldata <> s(i) Then
                        tempalldata = s(i)
                        ADD = {data_S2(7), data_S2(8), data_S2(9), data_S2(10)}
                        Dim binaryDigits = ToBinary.HexStringToBinary(Hex(data_S2(19))).ToCharArray
                        tmpbinaryDigits = binaryDigits(Sensor1) & binaryDigits(Sensor1)

                        '  Label1.Text = binaryDigits
                        Update_ToolstripLabel(binaryDigits, ToolStripStatusLabel4, Color.LightGray, colorFore)
                        If flagcheckio = True Or Comconfig.boxtype = "TYPE2" Then
                            statusbox = binaryDigits(Sensor1) & binaryDigits(Sensor2)
                        End If
                        Update_ToolstripLabel(binaryDigits, ToolStripStatusLabel5, Color.LightGray, colorFore)
                        Update_ToolstripLabel(tmpbinaryDigits, ToolStripStatusLabel6, Color.LightGray, colorFore)
                        If binaryDigits(SWGreen) = "1" Then
                            Update_ToolstripLabel("Rst", lblIO03, Color.LightGray, colorFore)
                        Else
                            Update_ToolstripLabel("Rst", lblIO03, Color.OrangeRed, colorFore)
                            If Queue_signal > 0 Then
                                Queue_signal = Queue_signal - 1
                                ' Update_label(Queue_signal.ToString, Label8, Color.Gray, Color.Blue)
                                Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                            End If

                            If BackgroundWorker1.IsBusy = True Then
                                flagcancel = True
                                If Queue_signal > 0 Then
                                    Queue_signal = Queue_signal - 1
                                    ' Update_label(Queue_signal.ToString, Label8, Color.Gray, Color.Blue)
                                    Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                                End If
                                flagreset = True
                                BackgroundWorker1.CancelAsync()
                                SSS = 0
                            End If

                            If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                                BackgroundWorker2.RunWorkerAsync()
                            End If


                        End If
                        If binaryDigits(Sensor1) = "1" Then
                            Update_label("S2", lblIO02, Color.LightGray, colorFore)
                        Else
                            Update_label("S2", lblIO02, colorlabel, colorFore)
                        End If
                        If binaryDigits(Sensor2) = "1" Then
                            Update_label("S1", lblIO01, Color.LightGray, colorFore)
                        Else
                            Update_label("S1", lblIO01, colorlabel, colorFore)
                        End If
                        If binaryDigits(Sensor1) & binaryDigits(Sensor2) = Comconfig.IOValue Then
                            '    boxstatus = "OK"
                            Update_label(Nothing, Label7, colorlabel, colorFore)
                            Exit Sub
                        Else
                            Update_label(Nothing, Label7, Color.LightGray, colorFore)
                        End If

                    End If
                Else
                    strtempIO = s(s.Length - 1)
                End If

            Next
            HexString = String.Empty
        Catch ex As Exception
            '   logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        straddcheck = ""
    End Sub

    ''' <summary>
    ''' show status of connection
    ''' </summary>
    Private Sub sLabelIO(ByVal comparamsIO() As String)
        Dim sta3 As String = ""

        For Each s As String In comparamsIO
            sta3 &= "-" & s
        Next
        Update_ToolstripLabel("IO: " & sta3, txtstatus2, Color.Green, Color.White)
        Me.txtstatus2.BackColor = Color.ForestGreen
    End Sub

    Private Sub btnConnectIO_Click(sender As Object, e As EventArgs) Handles btnConnectIO.Click
        Try

            If CType(sender, ToolStripButton).Text = "*connect*" Then
                Me.comparams(RS232.cP.cPort) = Comconfig.cPortIO
                Me.comparams(RS232.cP.cBaud) = Comconfig.cBaudIO
                Me.comparams(RS232.cP.cData) = Comconfig.cDataIO
                Me.comparams(RS232.cP.cParity) = Comconfig.cParityIO
                Me.comparams(RS232.cP.cStop) = Comconfig.cStopIO
                Me.comparams(RS232.cP.cDelay) = Comconfig.cDelayIO
                Me.comparams(RS232.cP.cThreshold) = Comconfig.cThresholdIO
                _rs232IO.connect(comparamsIO)
            Else
                _rs232IO.disconnect()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
#End Region
#Region "Create function"
    Private Sub Getcmbport()
        Dim Portnames As String() = SerialPort.GetPortNames
        If Portnames.Length > 0 Then
            Me.cboComPort.Text = Portnames(0)
        Else
            Update_ToolstripLabel("no ports detected", status0, Color.Green, Color.White)
            ' Me.status0.Text = "no ports detected"
            Exit Sub
        End If
        Me.cboComPort.Items.Clear()
        Me.cboComPort.Items.AddRange(Portnames)
    End Sub

    Public Sub check_XBADD_inBuffer()
        Dim Pac(20) As Byte
        Dim addT(3) As Byte
        Dim Card(3) As Byte
        ' Dim res As Byte
        Dim strdata As String = Nothing
        '  Dim Stradd As String
        Try
            If AGVTcpControl.Master_cell = Comconfig.CellNo Then
                Queue_signal = Queue_signal + 1
                SSS = 0
                Temp_224 = ""
                Temp_217 = ""
                flagRCVsignal = True
                If flagNowStart = False Then

                    '   QueueManage.Enqueue_AGV(obj2, Nothing, AGVTcpControl.Master_cell)
                    '    Update_label(Queue_signal.ToString, Label8, Color.Gray, Color.Blue)
                    Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                    If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                        '   FlagRCVsignal = False
                        BackgroundWorker2.RunWorkerAsync()
                    End If
                    Update_button("Start" & AGVTcpControl.Master_cell, Button2, colorlabel, colorFore)
                    If BackgroundWorker1.IsBusy <> True Then
                        Delay(0.5)
                        BackgroundWorker1.RunWorkerAsync()
                    End If

                End If
            Else
                Exit Sub
            End If
        Catch ex As Exception
            logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        QueueManage.deDequeue_AGV(obj, ListInQueue1)
        updateAGVQ(obj, ListInQueue1)
        show_detailAGV()
    End Sub

    Public Sub Send_Packet_to_AGV(ByRef SerialS As RS232, ByRef addT As Byte(), ByVal CMD1 As Byte, ByVal CMD2 As Byte)
        '  Dim result As Long = BitConverter.ToUInt32(ArrCard, 0)
        '7E 00 10 10 00 00 13 A2 00 40 EA 52 B7 FF FE 00 00 01 00 09
        Dim FSUM As Integer
        '   FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + addT(4) + addT(5) + addT(6) + addT(7) + &HFF + &HFE + CMD1 + CMD2)
        FSUM = &HFFF - (&H10 + &H0 + addT(0) + addT(1) + addT(2) + addT(3) + &H0 + &H13 + &HA2 + &H0 + &HFF + &HFE + CMD1 + CMD2)
        Dim byteArray As Byte() = BitConverter.GetBytes(FSUM)
        Dim h As Integer
        h = byteArray(0)

        Dim Packet() As Byte = {&H7E, &H0, &H10, &H10, &H0, &H0, &H13, &HA2, &H0, addT(0), addT(1), addT(2), addT(3), &HFF, &HFE, &H0, &H0, CMD1, CMD2, CByte(h)}
        If SerialS.IsCheckConnect() = True Then
            SerialS.SendData(Packet)
        End If
    End Sub
    Private Sub show_detailAGV()
        Dim Pac(20) As Byte
        Dim addT(7) As Byte
        Dim Card2(3) As Byte
        Dim res As Byte
        Dim strdata2 As String = Nothing
        Dim strb3 As String = Nothing
        Dim AGVName As String = Nothing
        If obj.Count <> 0 Then
            QueueManage.Peek_1(obj, Pac, strdata2, addT, res, Card2)
            strb3 = Hex(addT(0)).PadLeft(2, "0"c) & Hex(addT(1)).PadLeft(2, "0"c) & Hex(addT(2)).PadLeft(2, "0"c) & Hex(addT(3)).PadLeft(2, "0"c)
            If ReadAGVSetting2.dicname.ContainsKey(strb3) Then
                AGVName = ReadAGVSetting2.dicname.Item(strb3)
            End If
            Update_label("NO:" & AGVName, Label19, colorlabel, colorFore)
        Else
            Update_label("Wait AGV", Label19, Color.Gray, colorFore)
        End If

    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs)
        If ColorDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.BackColor = ColorDialog1.Color
        End If

    End Sub


    Private Sub btnSettime_Click(sender As Object, e As EventArgs) Handles btnSettime.Click
        Try
            Dim myValue As Object
            myValue = InputBox("Enter a value ", "Set up Time (sec)", "60", 500, 350)
            '   Update_ToolstripLabel(myValue.ToString(), lblcycletime, Color.SeaShell, Nothing)
            cycletime = CInt(myValue.ToString())
            '  Update_ToolstripLabel("Set Time:", ToolStripLabel11, Nothing, Nothing)
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub

    Private Sub ToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem4.Click
        cycletime = CInt(AGVTcpControl.Master_circleTime)
        '  Update_ToolstripLabel(AGVTcpControl.Master_circleTime, lblcycletime, Color.SeaShell, Nothing)
        ' Update_ToolstripLabel("Cycle Time:", ToolStripLabel11, Nothing, Nothing)
    End Sub

    'Private Sub btnsettime_Click(sender As Object, e As EventArgs) Handles btnSettime.Click
    '    If ToolStripMenuItem4.Text = "Set Time" Then
    '        Dim myValue As Object
    '        myValue = InputBox("Enter a value ", "Set up Time (sec)", "60", 500, 350)
    '        Update_ToolstripLabel(myValue.ToString(), lblcycletime, Color.SeaShell)

    '    ElseIf ToolStripMenuItem4.Text = "Use Cycle Time" Then
    '        Update_ToolstripLabel(AGVTcpControl.Master_circleTime, lblcycletime, Color.SeaShell)
    '    End If
    'End Sub
#End Region
#Region "Safety up date UI form"
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            If Queue_signal > 0 Then
                Queue_signal = Queue_signal - 1
                ' Update_label(Queue_signal.ToString, Label8, Color.Gray, Color.Blue)
                Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
            End If
            If BackgroundWorker1.IsBusy = True Then
                flagcancel = True
                '   flagreset = True
                BackgroundWorker1.CancelAsync()
                SSS = 0
            End If
            If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                BackgroundWorker2.RunWorkerAsync()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub

    Private Sub ResetTimeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetTimeToolStripMenuItem.Click
        SSS = 0
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Try
            Update_label(BackgroundWorker1.IsBusy & "/" & BackgroundWorker2.IsBusy, lblA1, Nothing, Nothing)
            Update_label(BackgroundWorker3.IsBusy & "/" & BackgroundWorker4.IsBusy, lblA2, Nothing, Nothing)
            Update_label(flagNowStart & "/" & flagreset & "/" & flaglooptime, lblA3, Nothing, Nothing)
            Update_label(show_result & "/" & TempA.ToString(), lblA4, Nothing, Nothing)
            Update_label(straddcheck & "/" & obj.Count.ToString, lblA5, Nothing, Nothing)
            Update_label(receiveadd, lblA6, Nothing, Nothing)
            Update_label(Temp_224, lblA7, Nothing, Nothing)
            Update_label(Temp_217, lblA8, Nothing, Nothing)
            Update_label(statusbox & "/" & boxstatus, Label8, Nothing, Nothing)
            ' Update_label(flagNowStart & "/" & flagreset, lblA3, Nothing)
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub

    Private Sub ResetValueToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetValueToolStripMenuItem.Click
        Comconfig.ReadConfig(Comconfig.path & Comconfig.CellNo & ".conf")
        colorlabel = DirectCast(New ColorConverter().ConvertFromString(Comconfig.colorLabel), Color)
        colorFrm = DirectCast(New ColorConverter().ConvertFromString(Comconfig.colorFrm), Color)
        Me.BackColor = colorFrm
    End Sub



    Private Sub TableLayoutPanel3_Paint(sender As Object, e As PaintEventArgs) Handles TableLayoutPanel3.Paint

    End Sub



    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub

    Private Sub DelayBeforeResendToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DelayBeforeResendToolStripMenuItem.Click
        Try
            Dim myValue3 As Object
            myValue3 = InputBox("Enter a value ", "Set Delay Before resend (sec)", "5", 500, 350)
            DelayBefore = CInt(myValue3.ToString())
            Update_ToolstripLabel(DelayBefore.ToString, T2, Nothing, colorFore)
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If Queue_signal > 0 Then
            Queue_signal = Queue_signal - 1
            ' Update_label(Queue_signal.ToString, Label8, Color.Gray, Color.Blue)
            Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
        End If
    End Sub

    Private Sub DelayFinalSendToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DelayFinalSendToolStripMenuItem.Click
        Try
            Dim myValue As Object
            myValue = InputBox("Enter a value ", "Set Delay Tim Final (sec)", "15", 500, 350)
            DelayFinal = CInt(myValue.ToString())
            Update_ToolstripLabel(DelayFinal.ToString, T1, Nothing, colorFore)
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateLabel(ByVal strstatusLabel As String, ByVal lbl As Label, ByVal lblcolor As Color, ByVal lblForecolor As Color)
    Private Sub Update_label(ByVal strstatusLabel As String, ByVal lbl As Label, ByVal lblcolor As Color, ByVal lblForecolor As Color)
        Try
            If InvokeRequired Then
                If strstatusLabel = "" Then
                    Invoke(Sub() lbl.BackColor = lblcolor)
                    Invoke(Sub() lbl.ForeColor = lblForecolor)
                Else
                    Invoke(Sub() lbl.Text = strstatusLabel)
                    Invoke(Sub() lbl.BackColor = lblcolor)
                    Invoke(Sub() lbl.ForeColor = lblForecolor)
                End If
            Else
                If strstatusLabel = "" Then
                    lbl.BackColor = lblcolor
                    lbl.ForeColor = lblForecolor
                Else
                    lbl.Text = strstatusLabel
                    lbl.BackColor = lblcolor
                    lbl.ForeColor = lblForecolor
                End If
            End If

        Catch ex As Exception
            logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub
    Private Delegate Sub DelegateUpdatetextbox(ByVal strstatustextbox As String, ByVal txt As TextBox, ByVal lblcolor As Color)
    Private Sub Update_textbox(ByVal strstatustextbox As String, ByVal txt As TextBox, ByVal lblcolor As Color)
        Try
            If InvokeRequired Then
                If strstatustextbox = "" Then
                    Invoke(Sub() txt.BackColor = lblcolor)
                Else
                    Invoke(Sub() txt.Text = strstatustextbox)
                    Invoke(Sub() txt.BackColor = lblcolor)
                End If
            Else
                If strstatustextbox = "" Then
                    txt.BackColor = lblcolor
                Else
                    txt.Text = strstatustextbox
                    txt.BackColor = lblcolor
                End If
            End If

        Catch ex As Exception
            ' logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateToolstripStaLabel(ByVal strstatusToolstripStaLabel As String, ByVal ToolstripStaLabel As ToolStripStatusLabel, ByVal lblcolor As Color, ByVal forcolor As Color)
    Private Sub Update_ToolstripStaLabel(ByVal strstatusToolstripStaLabel As String, ByVal ToolstripStaLabel As ToolStripStatusLabel, ByVal lblcolor As Color, ByVal forcolor As Color)
        Try
            If InvokeRequired Then
                If strstatusToolstripStaLabel = "" Then
                    Invoke(Sub() ToolstripStaLabel.BackColor = lblcolor)
                    Invoke(Sub() ToolstripStaLabel.ForeColor = forcolor)
                Else
                    Invoke(Sub() ToolstripStaLabel.Text = strstatusToolstripStaLabel)
                    Invoke(Sub() ToolstripStaLabel.BackColor = lblcolor)
                    Invoke(Sub() ToolstripStaLabel.ForeColor = forcolor)
                End If
            Else
                If strstatusToolstripStaLabel = "" Then
                    ToolstripStaLabel.BackColor = lblcolor
                    ToolstripStaLabel.ForeColor = forcolor
                Else
                    ToolstripStaLabel.Text = strstatusToolstripStaLabel
                    ToolstripStaLabel.BackColor = lblcolor
                    ToolstripStaLabel.ForeColor = forcolor
                End If
            End If

        Catch ex As Exception
            ' logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateToolStripLabel(ByVal strstatusToolstripLabel As String, ByVal ToolstripLabel As ToolStripLabel, ByVal lblcolor As Color, ByVal Forecolor As Color)
    Private Sub Update_ToolstripLabel(ByVal strstatusToolstripLabel As String, ByVal ToolstripLabel As ToolStripLabel, ByVal lblcolor As Color, ByVal Forecolor As Color)
        Try
            If InvokeRequired Then
                If strstatusToolstripLabel = "" Then
                    Invoke(Sub() ToolstripLabel.BackColor = lblcolor)
                    Invoke(Sub() ToolstripLabel.ForeColor = Forecolor)
                Else
                    Invoke(Sub() ToolstripLabel.Text = strstatusToolstripLabel)
                    Invoke(Sub() ToolstripLabel.BackColor = lblcolor)
                    Invoke(Sub() ToolstripLabel.ForeColor = Forecolor)
                End If
            Else
                If strstatusToolstripLabel = "" Then
                    ToolstripLabel.BackColor = lblcolor
                    ToolstripLabel.ForeColor = Forecolor
                Else
                    ToolstripLabel.Text = strstatusToolstripLabel
                    ToolstripLabel.BackColor = lblcolor
                    ToolstripLabel.ForeColor = Forecolor
                End If
            End If

        Catch ex As Exception
            ' logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try

    End Sub
    Private Delegate Sub DelegateUpdateToolStripbutton(ByVal strstatusToolstripbutton As String, ByVal Toolstripbutton As ToolStripButton, ByVal lblcolor As Color, ByVal Forecolor As Color)
    Private Sub Update_Toolstripbutton(ByVal strstatusToolstripbutton As String, ByVal Toolstripbutton As ToolStripButton, ByVal lblcolor As Color, ByVal Forecolor As Color)
        Try
            If InvokeRequired Then
                If strstatusToolstripbutton = "" Then
                    Invoke(Sub() Toolstripbutton.BackColor = lblcolor)
                    Invoke(Sub() Toolstripbutton.ForeColor = Forecolor)
                Else
                    Invoke(Sub() Toolstripbutton.Text = strstatusToolstripbutton)
                    Invoke(Sub() Toolstripbutton.BackColor = lblcolor)
                    Invoke(Sub() Toolstripbutton.ForeColor = Forecolor)
                End If
            Else
                If strstatusToolstripbutton = "" Then
                    Toolstripbutton.BackColor = lblcolor
                    Toolstripbutton.ForeColor = Forecolor
                Else
                    Toolstripbutton.Text = strstatusToolstripbutton
                    Toolstripbutton.BackColor = lblcolor
                    Toolstripbutton.ForeColor = Forecolor
                End If
            End If

        Catch ex As Exception
            ' logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try

    End Sub
    Private Delegate Sub DelegateUpdatebitmap(ByVal strstatusbitmap As ToolStripLabel, ByVal bitmapp As Bitmap)
    Private Sub Update_bitmap(ByVal strstatusbitmap As ToolStripLabel, ByVal bitmapp As Bitmap)
        '  Me.statusRXSend.Image = My.Resources.ledGreen
        Try
            If InvokeRequired Then
                Invoke(Sub() strstatusbitmap.Image = bitmapp)
            Else
                strstatusbitmap.Image = bitmapp
            End If
        Catch ex As Exception
            ' logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateButton(ByVal strstatusbutton As String, ByVal btn1 As Button, ByVal colorB As Color, ByVal colorFore1 As Color)
    Private Sub Update_button(ByVal strstatusbutton As String, ByVal btn1 As Button, ByVal colorB As Color, ByVal colorFore1 As Color)
        '  Me.statusRXSend.Image = My.Resources.ledGreen
        Try
            If InvokeRequired Then

                Invoke(Sub() btn1.Text = strstatusbutton)
                Invoke(Sub() btn1.BackColor = colorB)
                Invoke(Sub() btn1.ForeColor = colorFore1)
            Else
                btn1.Text = strstatusbutton
                btn1.BackColor = colorB
                btn1.ForeColor = colorFore1
            End If

        Catch ex As Exception
            ' logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub
    Private Sub updateAGVQ(ByRef objT As Queue(Of String), ByRef ListInQueue As ListBox)
        '    Try)
        If objT.Count <> 0 Then
            Dim arr As Object()
            arr = objT.ToArray()
            UpdateStatus("", ListInQueue1)
            For i As Integer = 0 To objT.Count - 1
                UpdateStatus(arr(i).ToString, ListInQueue1)
                '  ListInQueue.Items.Add(arr(i))
            Next
        ElseIf objT.Count = 0 Then
            ' ListInQueue.Items.Clear()
            UpdateStatus("", ListInQueue1)
            '  MessageBox.Show("queue is empty")
        End If
    End Sub
    Private Delegate Sub DelegateUpdateStatus22(ByVal statusText1 As String, ByVal txt As ListBox)
    Private Sub UpdateStatus(ByVal statusText1 As String, ByVal txt As ListBox)
        Try
            If InvokeRequired Then
                If statusText1 = "" Then
                    Invoke(Sub() txt.Items.Clear())
                Else
                    Invoke(Sub() txt.Items.Add(statusText1))
                End If
            Else
                If statusText1 = "" Then
                    txt.Items.Clear()
                Else
                    txt.Items.Add(statusText1)
                End If
            End If
        Catch ex As Exception
            logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub
    Private Sub BackgroundWorker1_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        Try
resend:     Dim worker As BackgroundWorker = CType(sender, BackgroundWorker)
            Dim worker2 As BackgroundWorker = CType(sender, BackgroundWorker)
            Dim Pac(20) As Byte
            Dim addT(7) As Byte
            Dim Card(3) As Byte
            Dim res As Byte
            Dim time1 As Date
            Dim time2 As Date
            Dim time3 As Date
            Dim time4 As Date
            Dim timewaitAGV As TimeSpan
            Dim timewaitkittingdaisha As TimeSpan
            Static A As Integer = 0
            responsefromAGV = ""
            statusbox = ""
            flagcheckio = False
            '   stamptimeC1 = Now
#Region "Check AGV in Queue"
            If obj.Count = 0 Then
                time1 = Now
                While True 'check 
                    If obj.Count <> 0 Then
                        Exit While
                    End If
                    If flagcancel = True Then
                        If Queue_signal > 0 Then
                            Queue_signal = Queue_signal - 1
                            Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                        End If
                        A = 0
                        flagcancel = False
                        '*     flagNowStart = False
                        Temp_217 = "" '********30/3/17
                        time2 = Now
                        timewaitAGV = time2.Subtract(time1)
                        totaltime_wait_AGV = FormatNumber(timewaitAGV.TotalSeconds)
                        GoTo Cancel
                    End If
                End While
                time2 = Now
                timewaitAGV = time2.Subtract(time1)
                totaltime_wait_AGV = FormatNumber(timewaitAGV.TotalSeconds)
            End If

#End Region
#Region "CheckIO"
            time3 = Now
            Select Case Comconfig.boxtype
                Case "TYPE1"
                    flagcheckio = True
                Case "TYPE2"
                    statusbox = tmpbinaryDigits
            End Select

            While True
                If AGVTcpControl.Master_cell <> "" And statusbox = Comconfig.IOValue Then
                    boxstatus = "OK"
                    Update_label(Nothing, Label7, colorlabel, colorFore)
                    '    flagcheckio = False
                    Exit While
                End If
                If flagcancel = True Then
                    If Queue_signal > 0 Then
                        Queue_signal = Queue_signal - 1
                        Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                    End If
                    boxstatus = ""
                    A = 0
                    '*     flagNowStart = False
                    Temp_217 = "" '********30/3/17
                    If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                        BackgroundWorker2.RunWorkerAsync()
                    End If
                    flagcancel = False
                    GoTo Cancel
                End If
            End While
            time4 = Now
            timewaitkittingdaisha = time4.Subtract(time3)
            totaltime_wait_Kitting = FormatNumber(timewaitkittingdaisha.TotalSeconds)
#End Region
#Region "main send"
            If AGVTcpControl.Master_cell <> "" And boxstatus = "OK" And obj.Count <> 0 Then
                AGVTcpControl.Master_cell = ""
                statusbox = ""
                boxstatus = ""
                Dim strdata As String = Nothing
                QueueManage.Peek_1(obj, Pac, strdata, addT, res, Card)
                Dim result As Long = BitConverter.ToUInt32(Card, 0)
                '7E 00 10 10 01 00 13 A2 00 40 DB 4A B1 FF FE 00 00 01 00 25
                memmopoint = strdata
                flagNowStart = True
                Delay(CInt(Comconfig.DelayTimeBeforeSend))
                If CheckBox1.Checked = True Then
                    flaglooptime = True
                End If

                While True '///////////
                    If responsefromAGV = "OK" And memmopoint = receiveadd Then
                        If Queue_signal > 0 Then
                            Queue_signal = Queue_signal - 1
                            Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                        End If
                        responsefromAGV = ""
                        boxstatus = ""
                        statusbox = ""
                        AGVTcpControl.Master_cell = ""
                        Update_button("Wait Signal", Button2, Color.Gray, colorFore)
                        QueueManage.deDequeue_AGV(obj, ListInQueue1)
                        updateAGVQ(obj, ListInQueue1)
                        If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                            BackgroundWorker2.RunWorkerAsync()
                        End If
                        Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                        A = 0
                        Exit While
                    End If

                    If A = CInt(Comconfig.SendCount) Then 'defult =8
                        If Queue_signal > 0 Then
                            Queue_signal = Queue_signal - 1
                            Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                        End If
                        A = 0
                        QueueManage.deDequeue_AGV(obj, ListInQueue1)
                        updateAGVQ(obj, ListInQueue1)
                        AGVTcpControl.Master_cell = ""
                        Update_button("Wait Signal", Button2, Color.Gray, colorFore)
                        Exit While
                    End If

                    If flagcancel = True And memmopoint = receiveadd Then
                        If Queue_signal > 0 Then
                            Queue_signal = Queue_signal - 1
                            Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                        End If
                        A = 0
                        TempA = A
                        responsefromAGV = ""
                        boxstatus = ""
                        statusbox = ""
                        '* flagNowStart = False
                        Temp_217 = "" '********30/3/17
                        QueueManage.deDequeue_AGV(obj, ListInQueue1)
                        updateAGVQ(obj, ListInQueue1)
                        If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                            BackgroundWorker2.RunWorkerAsync()
                        End If
                        flagcancel = False
                        GoTo Cancel
                    End If
                    If flaglooptime = True Or CheckBox1.Checked = False Then
                        SSS = 0
                        If status217 = True And memmopoint = receiveadd Then
                            If Queue_signal > 0 Then
                                Queue_signal = Queue_signal - 1
                                Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
                            End If
                            status217 = False
                            flagNowStart = False
                            '     A = CInt(Comconfig.SendCount)
                            responsefromAGV = ""
                            boxstatus = ""
                            statusbox = ""
                            Temp_217 = "" '********30/3/17
                            GoTo Cancel
                        End If
                        Send_Packet_to_AGV(_rs232Send, addT, &H1, &H0)
                        A = A + 1
                        TempA = A
                    End If
                    If (worker.CancellationPending = True) Then
                        e.Cancel = True
                        Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                        System.Threading.Thread.Sleep(CInt(Comconfig.LoopTimeSend))
                    Else
                        System.Threading.Thread.Sleep(CInt(Comconfig.LoopTimeSend))
                        worker.ReportProgress(A)
                    End If
                End While '////////////////////////////
            End If 'end main send
#End Region
Cancel:     TempA = A
            flagNowStart = False
            If Queue_signal > 0 Then
                A = 0
                AGVTcpControl.Master_cell = "Queue"
                'timenow = Now
                'GetcomparetimeC1 = stamptimeC1.Subtract(timenow)
                'totaltimelastedC1 = FormatNumber(GetcomparetimeC1.TotalSeconds)
                'If CInt(totaltimelastedC1) <= (CInt(Comconfig.DelayTimeBeforeSend)) Then
                '    Dim Resulttime As Integer = (CInt(Comconfig.DelayTimeBeforeSend)) - CInt(totaltimelastedC1)
                '    Delay(CInt(Resulttime))
                'End If
                Delay(CInt(Comconfig.DelayTimeBeforeSend))
                Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                    Update_label(Nothing, Label7, Color.Gray, colorFore)
                    totaltime_wait_AGV = ""
                    totaltime_wait_Kitting = ""
                    show_detailAGV()
                    memmopoint = ""
                    System.Threading.Thread.Sleep(2000)
                    responsefromAGV = ""
                    boxstatus = ""
                    statusbox = ""
                    flagcancel = False
                    GoTo resend
                End If
            '    SSS = 0
        Catch ex As Exception
            logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - -- - -")
        End Try
    End Sub

    Private Sub BackgroundWorker1_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        Try

            Update_button("Wait Signal", Button2, Color.Gray, colorFore)
            Update_label(Nothing, Label7, Color.Gray, colorFore)
            totaltime_wait_AGV = ""
            totaltime_wait_Kitting = ""
            show_detailAGV()
            If BackgroundWorker2.IsBusy <> True And CheckBox1.Checked = True Then
                BackgroundWorker2.RunWorkerAsync()
            End If
            memmopoint = ""
            System.Threading.Thread.Sleep(1000)
            responsefromAGV = ""
            AGVTcpControl.Master_cell = ""
            boxstatus = ""
            statusbox = ""
            flagcancel = False
            flagNowStart = False

            If Queue_signal > 0 Then
                Queue_signal = Queue_signal - 1
                '  Update_label(Queue_signal.ToString, Label8, Color.Gray, Color.Blue)
                Update_button(Queue_signal.ToString, Button4, Color.Gray, Color.Blue)
            End If
        Catch ex As Exception
            logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub

    Private Sub BackgroundWorker1_ProgressChanged(sender As Object, e As ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged

    End Sub

    Private Sub BackgroundWorker2_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker2.DoWork

        Dim worker As BackgroundWorker = CType(sender, BackgroundWorker)
resend: While True
            If CheckBox1.Checked = False Then
                SSS = 0
                'BackgroundWorker2.CancelAsync()
                Exit Sub
            End If
            SSS = SSS + 1
            worker.ReportProgress(SSS)
            Ssecand = cycletime

            If flagreset = True Then
                flagreset = False
                '  GoTo Reset
            End If
            If SSS = Ssecand Then
                AGVTcpControl.Master_cell = "Resend"
                SSS = 0
                '    Update_label(AGVTcpControl.Master_cell, lblsignal2, Color.Gray)
                Update_button(AGVTcpControl.Master_cell, Button2, Color.Gray, colorFore)
                Ssecand = 0
                worker.ReportProgress(SSS)
                If BackgroundWorker1.IsBusy <> True Then
                    BackgroundWorker1.RunWorkerAsync()
                End If
                ' Exit While
            End If
            If SSS > DelayFinal Or CheckBox1.Checked = False Then
                flaglooptime = False

            End If
            If (worker.CancellationPending = True) Then
                e.Cancel = True
            Else
                System.Threading.Thread.Sleep(1000)
            End If

        End While
        '    Exit While
        'End If
        If (worker.CancellationPending = True) Then
            e.Cancel = True
        Else
            System.Threading.Thread.Sleep(1000)
        End If
        '* End While
    End Sub
    Private Sub BackgroundWorker2_ProgressChanged(sender As Object, e As ProgressChangedEventArgs) Handles BackgroundWorker2.ProgressChanged
        Update_ToolstripLabel(e.ProgressPercentage.ToString(), TstrCycleCount, Color.SeaShell, Nothing)
    End Sub

    Private Sub BackgroundWorker2_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker2.RunWorkerCompleted
    End Sub


#End Region

End Class
