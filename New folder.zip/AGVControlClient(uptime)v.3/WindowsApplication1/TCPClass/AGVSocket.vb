﻿Imports System.Net.Sockets
Imports System.IO
Imports System.Threading

Public Class AGVSocket

    Public client As TcpClient
    Private s As Stream
    Private sr As StreamReader
    Private sw As StreamWriter

    Public received As Integer = 0
    Public sent As Integer = 0
    Public queue As Integer = 0

    Public isTryConnecting As Boolean = False
    Public myQueue As Queue(Of String) = New Queue(Of String)()
    Public isQueueWorking As Boolean = False

    Public config As Configure = New Configure()

    Public Function Connect() As Boolean

        client = New TcpClient()

        Dim re As Boolean = False

        Try
            client.Connect(config.serverIP, config.port)

            s = client.GetStream()
            sr = New StreamReader(s)
            sw = New StreamWriter(s)
            sw.AutoFlush = True
            Dim a As String = sr.ReadLine()
            re = True

        Catch ex As Exception

        End Try

        Return re
    End Function

    Public Sub Timmer()
        Dim i As Integer = 0
        While True
            i = i + 1
            AGVUptimeClient.Text = i & ""
        End While
    End Sub

    Public Function Ping() As Boolean
        Dim b As Boolean = False
        Try
            sw.WriteLine("ping")
            sr.ReadLine()
            b = True

        Catch ex As Exception
        End Try

        Return b
    End Function

    Public Function Send(ByVal text As String) As String

        Dim t As New Thread(AddressOf SendPre)
        Dim p As New Parameters
        p.s = text
        t.IsBackground = True
        t.Start(p)
        Return ""
    End Function

    Public Function SendPre(ByVal param As Object) As String
        Dim p As Parameters = CType(param, Parameters)
        Dim name As String = p.s
        Dim r As String

        Try
            r = TCPSend(name)
        Catch ex As Exception
            r = ""
            'Connect()
            myQueue.Enqueue(name)
            queue = queue + 1
        End Try

        Return r

    End Function

    Public Function TCPSend(ByVal str As Object) As String
        sw.WriteLine(str)
        sent = sent + 1
        Return sr.ReadLine()
    End Function

    Public Function GetTime2() As String
        Dim dt As DateTime = DateTime.Now
        Dim ms = ""
        If dt.Millisecond < 10 Then
            ms = "00" & dt.Millisecond
        ElseIf dt.Millisecond < 100 Then
            ms = "0" & dt.Millisecond
        Else
            ms = "" & dt.Millisecond
        End If
        Return dt.ToString("dd-MMM-yy hh.mm.ss") & "." & ms & "000000 " & dt.ToString("tt")
    End Function

    Public Function GetStatusAll() As String
        Return "[Received = " & received & ", Sent = " & sent & ", Queue = " & myQueue.Count & "]"
    End Function
    Public Function GetStatusReceive() As String
        Return "[Received = " & received & "]"
    End Function
    Public Function GetStatusSend() As String
        Return "[ Sent = " & sent & "]"
    End Function
    Public Function GetStatusQueue() As String
        Return "[ Queue = " & myQueue.Count & "]"
    End Function
    Dim random As New Random()

    Public Function GetSamplePackage() As String
        Dim agvCode As String = "4124FFAE"
        Dim agvAction As Integer = random.Next(5)
        Dim agvCardID As Integer = random.Next(500)
        Return agvCode & "|" & agvAction & "|" & GetTime2() & "|" & agvCardID
    End Function

End Class

Class Parameters
    Public s As String
End Class