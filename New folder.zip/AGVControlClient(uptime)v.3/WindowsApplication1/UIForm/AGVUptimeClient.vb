﻿Option Strict On
Option Infer On

Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.IO
Imports System.Threading
Imports System.Net.NetworkInformation
Imports System.ComponentModel
Imports System.Collections.Generic
Imports System.Reflection.TargetInvocationException
Imports System.Reflection

Public Class AGVUptimeClient

    Public Shared socketTcp As New AGVSocket()
    Public Shared except_count As Integer = 0
    ''test rs232module
    '   Private WithEvents Serialportsend As New RS232
    Private WithEvents _rs232 As New RS232
    Private charsInline As Integer = 63  ' def n start
    Private isConnected As Boolean
    Private RXcount, TXcount As Integer
    Private comparams() As String = RS232.DefaultParams
    Private buffer() As Byte
    Dim strtemp As String
    'dic
    Dim dic As Dictionary(Of String, String) = New Dictionary(Of String, String)()
    Dim dic2 As Dictionary(Of String, String) = New Dictionary(Of String, String)()

    '  Private WithEvents bgEorker As BackgroundWorker
    Public obj As Queue(Of String) = New Queue(Of String)()
    'read data from json variable
    Private ReadAGVSetting2 As ReadAGVSetting = New ReadAGVSetting("D:\\IprojectDB\Setting\AGV_Setting.json", True)
    Private ReadRFIDDetail As ReadAGVSetting = New ReadAGVSetting("D:\\IprojectDB\Setting\RFID_Detail.json", True)
    Dim AGVindex, AGVaddress, AGVname, AGVline As String()
    Dim ID, Responsename As String()
    Dim Line As String
    Dim AA As Integer
    Dim BB As String
    Private Readconfig As Configure = New Configure()
    'Log File
    Dim logE As LogFile = New LogFile("D:/IprojectDB/AGV_Monitor_Log/Err_log" & Readconfig.cPort, True)
#Region "Sub New"
    Public Sub New()
        ' This call is required by the designer.
        InitializeComponent()
        'Add any initialization after the InitializeComponent() call.
        'AddHandler BackgroundWorker1.DoWork, AddressOf BackgroundWorker1_DoWork
        'AddHanv  dler BackgroundWorker1.ProgressChanged, AddressOf BackgroundWorker1_ProgressChanged
        'AddHandler BackgroundWorker1.RunWorkerCompleted, AddressOf BackgroundWorker1_RunWorkerCompleted
        BGWUIUpdater.WorkerReportsProgress = True
        BGWUIUpdater.WorkerSupportsCancellation = True
        BGWTCPTimer.WorkerReportsProgress = True
        BGWTCPTimer.WorkerSupportsCancellation = True
    End Sub
#End Region
    Private Sub AGVUptimeClient_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            If _rs232.IsCheckConnect = False Then
                Me.comparams(RS232.cP.cPort) = "COM7"
                Me.comparams(RS232.cP.cBaud) = Readconfig.cBaud
                Me.comparams(RS232.cP.cData) = Readconfig.cData
                Me.comparams(RS232.cP.cParity) = Readconfig.cParity
                Me.comparams(RS232.cP.cStop) = Readconfig.cStop
                Me.comparams(RS232.cP.cDelay) = Readconfig.cDelay
                Me.comparams(RS232.cP.cThreshold) = Readconfig.cThreshold
                _rs232.connect(comparams)
            End If
            '     InitialTCPThread()
            If BGWTCPTimer.IsBusy <> True Then
                BGWTCPTimer.RunWorkerAsync()
            End If
            If BGWUIUpdater.IsBusy <> True Then
                BGWUIUpdater.RunWorkerAsync()
            End If

            ' read available ports on RS232
            ReadAGVSetting2.read()
            ReadRFIDDetail.read()
        Catch ex As Exception
            logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - -- - -")
        End Try
    End Sub
#Region "RS232 Receive Port"
#Region "form events Receive Port"

    Private count As Integer

    ''' <summary>
    ''' build hex string in textbox
    ''' </summary>
    Private Sub cboEnterMessage_TextUpdate(ByVal sender As System.Object,
                                           ByVal e As System.EventArgs)
        '  If Not Me.chkTxEnterHex.Checked Then Exit Sub
        Dim cb As ToolStripComboBox = CType(sender, ToolStripComboBox)
        Dim s As String = cb.Text
        count += 1
        If count = 2 Then
            cb.Text &= " "
            count = 0
        End If
        cb.SelectionStart = cb.Text.Length
    End Sub

    Private Sub sendToCom() 'Handles cbxsendToCom.KeyDown
        Dim data() As Byte = Nothing
        _rs232.SendData(data)
        Me.TXcount += data.Length
    End Sub

    ''' <summary>
    ''' view hex in rx box
    ''' </summary>
    Private Sub RxShowHex_CheckedChanged(ByVal sender As System.Object,
                                         ByVal e As System.EventArgs)
        '   Me.charsInline = setRuler(Me.rtbRX, Me.chkRxShowHex.Checked)
    End Sub



    ''' <summary>
    ''' view hex in tx box
    ''' </summary>
    Private Sub chkTxShowHex_CheckedChanged(ByVal sender As System.Object,
                                         ByVal e As System.EventArgs)
        '    Me.charsInline = setRuler(Me.rtbTX, Me.chkTxShowHex.Checked)
    End Sub
    Private Sub frmMain_ResizeEnd(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.ResizeEnd
        'Me.charsInline = setRuler(rtbRX, chkRxShowHex.Checked)
        'Me.charsInline = setRuler(rtbTX, chkTxShowHex.Checked)
    End Sub
#End Region
#Region "Com Port class events Receive Port"
    ''' <summary>
    '''  update boxes
    ''' </summary>
    ''' <param name="buffer">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdate(ByVal buffer() As Byte) Handles _rs232.Datareceived
        Me.RXcount += buffer.Length
        ' Me.lblRxCnt.Text = String.Format("count: {0:D3}", RXcount)
        Update_label(String.Format("{0:D3}", RXcount), lblRXCount, Nothing, Nothing)
        Dim s As String = Encoding.ASCII.GetString(buffer, 0, buffer.Length)
        ' Me.rtbRX.ScrollToCaret()
        'TODO
        '  Me.rtbRX.AppendText(s) ' & vbCr)
        appendBytes(buffer, Me.charsInline, False)
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendata(ByVal sendStatus As Boolean) Handles _rs232.sendOK
        If sendStatus Then
            '  Me.statusTX.Image = My.Resources.ledGreen
            '  Update_bitmap(statusTX, My.Resources.ledGreen)
        Else
            '   Me.statusTX.Image = My.Resources.ledRed
            '   Update_bitmap(statusTX, My.Resources.ledRed)
        End If
    End Sub


    ''' <summary>
    ''' receive successfull
    ''' </summary>
    Private Sub rdata(ByVal receiveStatus As Boolean) Handles _rs232.recOK
        If receiveStatus Then
            ' Me.statusRX.Image = My.Resources.ledGreen
            '  Update_bitmap(statusRX, My.Resources.ledGreen)
        Else
            ' Me.statusRX.Image = My.Resources.ledRed
            ' Update_bitmap(statusRX, My.Resources.ledRed)
        End If
    End Sub

    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connection(ByVal status As Boolean) Handles _rs232.connection
        If status Then
            Update()
            Update_button("disconnect", btnConnectRCV, Color.ForestGreen, Color.Black)
            Update_label("Connect", status0, Color.ForestGreen, Color.Blue)
            Me.sLabel(comparams)
            Me.isConnected = True
        Else
            Update_button("*connect*", btnConnectRCV, Color.Red, Color.White)
            Update_label("none", status0, Color.Red, Color.White)
            Me.isConnected = False
            '
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        '  RemoveAt(1)
    End Sub

    ''' <summary>
    ''' exception message
    ''' </summary>
    Private Sub getmessage(ByVal msg As String) Handles _rs232.errormsg
        'Me.status0.Text = msg
        MsgBox(msg)
    End Sub




    Private Sub btnConnectRCV_Click(sender As Object, e As EventArgs) Handles btnConnectRCV.Click
        Try
            If CType(sender, Button).Text = "*connect*" Then
                Me.comparams(RS232.cP.cPort) = Readconfig.cPort
                Me.comparams(RS232.cP.cBaud) = Readconfig.cBaud
                Me.comparams(RS232.cP.cData) = Readconfig.cData
                Me.comparams(RS232.cP.cParity) = Readconfig.cParity
                Me.comparams(RS232.cP.cStop) = Readconfig.cStop
                Me.comparams(RS232.cP.cDelay) = Readconfig.cDelay
                Me.comparams(RS232.cP.cThreshold) = Readconfig.cThreshold
                _rs232.connect(comparams)
            Else
                _rs232.disconnect()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString)
        End Try
    End Sub

#End Region
#Region "utilities  Receive Port"
    ''' <param name="data">data frame</param>
    ''' <param name="currentLenght">possible chars in box</param>
    ''' <param name="showHexAndAscii">determines whether also displaying Hex True</param>
    ''' <remarks></remarks>
    Private Sub appendBytes(ByRef data() As Byte, ByRef currentLenght As Integer, ByVal showHexAndAscii As Boolean)

        Try
            Dim HexString As String = strtemp & StringUltilities.ByteArrayToHexString(data)
            Dim CharString As String = String.Empty
            Dim s() As String = HexString.Split(New String() {" 7E"}, StringSplitOptions.RemoveEmptyEntries)
            ' Static A As Integer
            Dim objmember As Object() = Nothing
            For i = 0 To s.Length - 1
                ' Update_ToolstripStaLabel(s(i).ToString, TstaTCPSignal, Color.MistyRose)
                Dim data_S() As Byte
                Dim ADD() As Byte
                Dim Respond As Byte
                Dim card() As Byte
                Dim strb As String = Nothing
                Dim strb2 As String = Nothing
                Dim Astr As String = ""
                'Dim name As String
                'Dim index As String
                data_S = Reconvert.convert(s(i), " ")
                If data_S.Length = 20 Then
                    strtemp = ""
                    ADD = {data_S(7), data_S(8), data_S(9), data_S(10)}
                    strb = Hex(data_S(7)).PadLeft(2, "0"c) & Hex(data_S(8)).PadLeft(2, "0"c) & Hex(data_S(9)).PadLeft(2, "0"c) & Hex(data_S(10)).PadLeft(2, "0"c)
                    strb2 = Hex(data_S(7)).PadLeft(2, "0"c) & Hex(data_S(8)).PadLeft(2, "0"c) & Hex(data_S(9)).PadLeft(2, "0"c) & Hex(data_S(10)).PadLeft(2, "0"c)
                    '  Show_ADD = strb2
                    Respond = data_S(16)
                    card = {data_S(18), data_S(17), &H0, &H0}
                    '  Response = Hex(data_S(17)) & Hex(data_S(18))
                    Dim result As Long = BitConverter.ToUInt32(card, 0)
                    If ReadAGVSetting2.dicLine.ContainsKey(strb) Then
                        Line = ReadAGVSetting2.dicname.Item(strb).ToString
                        TCP_Data_fillter(strb.PadLeft(8, "0"c), Respond, CInt(result), Line)
                    End If
                    ' TCP_Data_fillter(strb.PadLeft(8, "0"c), Respond, CInt(result), Line)
                Else
                    strtemp = s(s.Length - 1)
                End If
            Next
            HexString = String.Empty
        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try

    End Sub

    ''' <summary>
    ''' show status of connection
    ''' </summary>
    Private Sub sLabel(ByVal comparams() As String)
        Update_label(Readconfig.cPort, lblGetportrcv, Color.Transparent, Color.Black)
    End Sub
#End Region
#End Region
#Region "My Function"
    Dim log_card As LogFile = New LogFile("D:/IprojectDB/log_start_control", True)
    Private Sub TCP_Data_fillter(ByVal addressXB As String, ByVal response As Integer, ByVal errorvalue As Integer, ByVal agvline As String)
        Dim data1 As String = "" & response & "-" & errorvalue
        If IsAllowVehicle(addressXB) Then
            If socketTcp.config.filter = 2 Then
                If Not dic.ContainsKey(addressXB) Then
                    dic.Add(addressXB, data1)
                    TCPSend(addressXB & "|" & response & "|" & socketTcp.GetTime2() & "|" & errorvalue & "|" & agvline & "|1")
                Else
                    If dic(addressXB) <> data1 Then
                        dic(addressXB) = data1
                        TCPSend(addressXB & "|" & response & "|" & socketTcp.GetTime2() & "|" & errorvalue & "|" & agvline & "|1")
                    End If
                End If
            End If

        End If
    End Sub

    Private Function IsAllowVehicle(ByVal addressXB As String) As Boolean
        If socketTcp.config.allow = "all" Then
            Return True
        Else
            Dim ag As String() = socketTcp.config.allow.Split("|"c)
            Dim do1 As Boolean = False

            For Each item As String In ag
                If item = addressXB Then
                    do1 = True
                    Exit For
                End If
            Next
            Return do1
        End If
    End Function
#Region "Queue"
    Private Sub Enqueue_AGV(ByRef objT As Queue(Of String), ByRef ListInQueue As ListBox, ByVal strtt As String)
        ' If obj.Count <> 0 Then
        Dim str As String = String.Empty
        str = strtt
        Dim ob As Object = DirectCast(str, Object)
        objT.Enqueue(CStr(ob))
        ToArray(objT, ListInQueue)
    End Sub
    Private Sub deDequeue_AGV(ByRef objT As Queue(Of String), ByRef ListInQueue As ListBox)
        If objT.Count <> 0 Then
            Dim str As String = String.Empty
            Dim ob As Object
            ob = objT.Dequeue()
            str = DirectCast(ob, String)
            ' MessageBox.Show("value remove from queue is " & str)
            ToArray(objT, ListInQueue)
            'Lbl_Prob(lblsta1, "OK", Color.White, Color.Gray)
            ' UpdateStatus2("")
        Else
            'MessageBox.Show("queue is empty")
        End If
    End Sub



    'Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs)
    '    If ToolStripTextBox1.Text = "Http:\\ieee" Then
    '        Exit Sub
    '    End If
    '    WebBrowser1.Navigate(ToolStripTextBox1.Text)
    'End Sub

    Private Sub WebBrowser1_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs)

    End Sub


    Private Sub ToArray(ByRef objT As Queue(Of String), ByRef ListInQueue As ListBox)
        If objT.Count <> 0 Then
            Dim arr As Object()
            arr = objT.ToArray()
            'Invoke(Sub() ListBox1.Items.Clear())
            ListInQueue.Items.Clear()
            For i As Integer = 0 To objT.Count - 1
                '    UpdateStatus(arr(i).ToString)
                ListInQueue.Items.Add(arr(i))
            Next
        ElseIf objT.Count = 0 Then
            ListInQueue.Items.Clear()
            '  MessageBox.Show("queue is empty")
        End If
    End Sub

    'Private Sub Form2_MouseClick(sender As Object, e As MouseEventArgs) Handles Me.MouseClick
    '    ToolStripStatusLabel4.Text = "LOCATION[" & e.Location.ToString & "]"
    '    ToolStripStatusLabel4.Visible = True
    '    txtlocationX.Text = CStr(e.Location.X)
    '    txtlocationY.Text = CStr(e.Location.Y)
    'End Sub

    Private Sub Form2_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        _rs232.disconnect()
    End Sub
#End Region
#Region "This code section is for AGV uptime system"

    Dim log1 As LogFile = New LogFile("D:/IprojectDB/log_uptime_system", True)

    Public Sub TCPTimer()
        Dim i As Integer = 0

        While True
            Thread.Sleep(5000)
            If Not socketTcp.Ping() Then
                InitialTCPThread()
            End If
        End While
    End Sub

    Dim i As Integer = 1
    Dim d As Integer = 10
    Dim r As New Random()

    Public Sub PackageSender()

        Dim t4 As New Thread(New ThreadStart(AddressOf Timer3))
        t4.IsBackground = True
        t4.Start()

        While True

            TCPSend(socketTcp.GetSamplePackage())
            Thread.Sleep(d + (r.Next() Mod 10))

        End While
    End Sub

    Public Sub Timer3()
        Dim min As Integer = 10
        Dim max As Integer = 720
        '  ToolStripStatusLabel7.Text = d & ""

        While True

            Thread.Sleep(6000)

            d = d + (i * 10)

            If d > max Then
                d = max
                i = -1
            End If

            If d < min Then
                d = min
                i = 1
            End If

            Try
                ' ToolStripStatusLabel7.Text = d & ""
            Catch ex As Exception

            End Try

        End While
    End Sub

    Public Sub UIUpdater()
        While True
            Try
                '  ToolStripStatusLabel6.Text = socketTcp.GetStatus()
                Update_label(socketTcp.GetStatusReceive(), Label3, Color.Transparent, Color.Blue)
                Update_label(socketTcp.GetStatusSend(), Label6, Color.Transparent, Color.Green)
                Update_label(socketTcp.GetStatusQueue(), Label5, Color.Transparent, Color.Red)
                '     UpdateStatus(socketTcp.GetStatus(), ToolStripStatusLabel6)
            Catch e As InvalidOperationException
                Dim line As Integer = New StackFrame(0, True).GetFileLineNumber()
                log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " line: " & line)
            End Try
            Thread.Sleep(500)
        End While
    End Sub
    Private Delegate Sub DelegateUpdateStatus22(ByVal statusText As String)
    Private Sub UpdateStatus(ByVal statusText As String, ByVal txt As ToolStripStatusLabel)
        Try
            If InvokeRequired Then
                If statusText = "" Then
                    Invoke(Sub() txt.Text = "")
                Else
                    Invoke(Sub() txt.Text = statusText)
                End If
            Else
                If statusText = "" Then
                    txt.Text = ""
                Else
                    txt.Text = statusText
                End If
            End If
        Catch ex As Exception
            'logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
        End Try
    End Sub
    Private Sub InitialTCPThread()
        If Not socketTcp.isTryConnecting Then
            socketTcp.isTryConnecting = True
            Dim t As New Thread(New ThreadStart(AddressOf TCPStart))
            t.IsBackground = True
            t.Start()
        End If
    End Sub

    Private Sub TCPStart()
        Try
            Update_label("[Server: Connecting to " & socketTcp.config.serverIP & ":" & socketTcp.config.port & "...]", Label2, Color.Gray, Color.Blue)
            ' Label2.Text = "[Server: Connecting to " & socketTcp.config.serverIP & ":" & socketTcp.config.port & "...]"
            If socketTcp.Connect() Then
                'isTryConnecting = False
                Update_label("[Server: Connecting to " & socketTcp.config.serverIP & ":" & socketTcp.config.port & "...]", Label2, Color.Gray, Color.Blue)
                If Not socketTcp.isQueueWorking Then
                    If socketTcp.myQueue.Count > 0 Then
                        socketTcp.isQueueWorking = True
                        Dim t As New Thread(New ThreadStart(AddressOf PushQueue))
                        t.IsBackground = True
                        t.Start()
                    End If
                End If
            Else
                'ToolStripStatusLabel5.Text = "[Server: Connect failed]"
            End If
            socketTcp.isTryConnecting = False
        Catch e As InvalidOperationException
            socketTcp.isTryConnecting = False
            Dim line As Integer = New StackFrame(0, True).GetFileLineNumber()
            log1.Log(e.Message & vbTab & System.Reflection.MethodInfo.GetCurrentMethod().Name & " line: " & line)
        End Try
    End Sub

    Public Sub TCPSend(ByVal text As String)
        socketTcp.received = socketTcp.received + 1
        socketTcp.Send(text)
    End Sub

    Private Sub PushQueue()
        Dim counter As Integer = socketTcp.myQueue.Count
        If counter > 0 Then
            Dim s As String = socketTcp.myQueue.Dequeue()
            socketTcp.Send(s)

            Dim perSec As Integer = counter \ 1000

            If perSec < 4 Then
                perSec = 4
            End If

            If perSec > 20 Then
                perSec = 20
            End If

            Thread.Sleep(1000 \ perSec)
            If socketTcp.Ping() Then
                PushQueue()
            End If
        End If

        socketTcp.isQueueWorking = False
    End Sub
#End Region
    Private Sub BGWUIUpdater_DoWork(sender As Object, e As DoWorkEventArgs) Handles BGWUIUpdater.DoWork
        UIUpdater()
    End Sub

    Private Sub BGWTCPTimer_DoWork(sender As Object, e As DoWorkEventArgs) Handles BGWTCPTimer.DoWork
        TCPTimer()
    End Sub



#End Region
#Region "safety UI Update"
    Private Delegate Sub DelegateUpdateLabel(ByVal strstatusLabel As String, ByVal lbl As Label, ByVal lblcolor As Color, ByVal lblForecolor As Color)
    Private Sub Update_label(ByVal strstatusLabel As String, ByVal lbl As Label, ByVal lblcolor As Color, ByVal lblForecolor As Color)
        Try
            If InvokeRequired Then
                If strstatusLabel = "" Then
                    Invoke(Sub() lbl.Text = strstatusLabel)
                    Invoke(Sub() lbl.BackColor = lblcolor)
                    Invoke(Sub() lbl.ForeColor = lblForecolor)
                Else
                    Invoke(Sub() lbl.Text = strstatusLabel)
                    Invoke(Sub() lbl.BackColor = lblcolor)
                    Invoke(Sub() lbl.ForeColor = lblForecolor)
                End If
            Else
                If strstatusLabel = "" Then
                    lbl.Text = strstatusLabel
                    lbl.BackColor = lblcolor
                    lbl.ForeColor = lblForecolor
                Else
                    lbl.Text = strstatusLabel
                    lbl.BackColor = lblcolor
                    lbl.ForeColor = lblForecolor
                End If
            End If

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
    Private Delegate Sub DelegateUpdateLog(ByVal StrCSV1 As String)

    Private Sub btnConnect_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Update_Log(ByVal StrCSV1 As String)
        '  Me.statusRXSend.Image = My.Resources.ledGreen
        Try
            If InvokeRequired Then
                Invoke(Sub() logE.Log(vbCr & StrCSV1 & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"))
            Else
                logE.Log(vbCr & StrCSV1 & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString())
        End Try
    End Sub

    Private Delegate Sub DelegateUpdateStatus(ByVal statusText1 As String, ByVal txt As ListBox)
    Private Sub UpdateStatus(ByVal statusText1 As String, ByVal txt As ListBox)
        Try
            If InvokeRequired Then
                If statusText1 = "" Then
                    Invoke(Sub() txt.Items.Clear())
                Else
                    Invoke(Sub() txt.Items.Add(statusText1))
                End If
            Else
                If statusText1 = "" Then
                    txt.Items.Clear()
                Else
                    txt.Items.Add(statusText1)
                End If
            End If
        Catch ex As Exception
            '  logE.Log(vbCr & ex.ToString & vbCrLf & "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
            Update_Log(ex.ToString())
        End Try
    End Sub

    Private Delegate Sub DelegateUpdateButton(ByVal strstatusbutton As String, ByVal btn1 As Button, ByVal colorB As Color, ByVal colorFore1 As Color)
    Private Sub Update_button(ByVal strstatusbutton As String, ByVal btn1 As Button, ByVal colorB As Color, ByVal colorFore1 As Color)
        '  Me.statusRXSend.Image = My.Resources.ledGreen
        Try
            If InvokeRequired Then
                Invoke(Sub() btn1.Text = strstatusbutton)
                Invoke(Sub() btn1.BackColor = colorB)
                Invoke(Sub() btn1.ForeColor = colorFore1)
            Else
                btn1.Text = strstatusbutton
                btn1.BackColor = colorB
                btn1.ForeColor = colorFore1
            End If

        Catch ex As Exception
            Update_Log(ex.ToString())
        End Try
    End Sub
#End Region
End Class